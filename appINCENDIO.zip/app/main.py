from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.controllers.router import router

# =====================================================
# MQTT
# =====================================================

import threading
from app import mqtt_client

# =====================================================
# FASTAPI
# =====================================================

app = FastAPI(

    title="Detector de Incendios API",

    description="""
    API para monitoreo de incendios en tiempo real
    usando ESP32 + MQTT + FastAPI + MySQL
    """,

    version="1.0.0"

)

# =====================================================
# CORS
# =====================================================

app.add_middleware(

    CORSMiddleware,

    allow_origins=["*"],

    allow_credentials=True,

    allow_methods=["*"],

    allow_headers=["*"]

)

# =====================================================
# ROUTERS
# =====================================================

app.include_router(

    router,

    prefix="/api"

)

# =====================================================
# MQTT THREAD
# =====================================================

def start_mqtt():

    try:

        print("📡 Iniciando cliente MQTT...")

        mqtt_client.client.loop_forever()

    except Exception as e:

        print("❌ Error MQTT")
        print(e)

# =====================================================
# STARTUP EVENT
# =====================================================

@app.on_event("startup")
def startup_event():

    mqtt_thread = threading.Thread(

        target=start_mqtt

    )

    mqtt_thread.daemon = True

    mqtt_thread.start()

    print("✅ MQTT iniciado")

# =====================================================
# ROOT
# =====================================================

@app.get("/")
def root():

    return {

        "message": "🔥 API Detector de Incendios Funcionando 🔥",

        "status": "online"

    }

# =====================================================
# HEALTH CHECK
# =====================================================

@app.get("/health")
def health():

    return {

        "server": "online",

        "mqtt": "running",

        "api": "working"

    }