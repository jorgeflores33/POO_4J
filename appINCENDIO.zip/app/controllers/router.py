from fastapi import APIRouter

from app.controllers.controller import (

    # =====================================================
    # USUARIOS
    # =====================================================

    get_usuarios,
    create_usuario,
    update_usuario,
    delete_usuario,

    # =====================================================
    # TRABAJADORES
    # =====================================================

    get_trabajadores,
    create_trabajador,
    update_trabajador,
    delete_trabajador,

    # =====================================================
    # DISPOSITIVOS
    # =====================================================

    get_dispositivos,
    create_dispositivo,
    update_dispositivo,
    delete_dispositivo,

    # =====================================================
    # LECTURAS
    # =====================================================

    get_lecturas,
    create_lectura,
    update_lectura,
    delete_lectura,

    # =====================================================
    # ALERTAS
    # =====================================================

    get_alertas,
    create_alerta,
    update_alerta,
    delete_alerta,

    # =====================================================
    # NOTIFICACIONES
    # =====================================================

    get_notificaciones,
    create_notificacion,
    update_notificacion,
    delete_notificacion

)

router = APIRouter()

# =====================================================
# USUARIOS
# =====================================================

router.add_api_route(

    "/usuarios",

    get_usuarios,

    methods=["GET"],

    tags=["Usuarios"]

)

router.add_api_route(

    "/usuarios",

    create_usuario,

    methods=["POST"],

    tags=["Usuarios"]

)

router.add_api_route(

    "/usuarios/{id}",

    update_usuario,

    methods=["PUT"],

    tags=["Usuarios"]

)

router.add_api_route(

    "/usuarios/{id}",

    delete_usuario,

    methods=["DELETE"],

    tags=["Usuarios"]

)

# =====================================================
# TRABAJADORES
# =====================================================

router.add_api_route(

    "/trabajadores",

    get_trabajadores,

    methods=["GET"],

    tags=["Trabajadores"]

)

router.add_api_route(

    "/trabajadores",

    create_trabajador,

    methods=["POST"],

    tags=["Trabajadores"]

)

router.add_api_route(

    "/trabajadores/{id}",

    update_trabajador,

    methods=["PUT"],

    tags=["Trabajadores"]

)

router.add_api_route(

    "/trabajadores/{id}",

    delete_trabajador,

    methods=["DELETE"],

    tags=["Trabajadores"]

)

# =====================================================
# DISPOSITIVOS
# =====================================================

router.add_api_route(

    "/dispositivos",

    get_dispositivos,

    methods=["GET"],

    tags=["Dispositivos"]

)

router.add_api_route(

    "/dispositivos",

    create_dispositivo,

    methods=["POST"],

    tags=["Dispositivos"]

)

router.add_api_route(

    "/dispositivos/{id}",

    update_dispositivo,

    methods=["PUT"],

    tags=["Dispositivos"]

)

router.add_api_route(

    "/dispositivos/{id}",

    delete_dispositivo,

    methods=["DELETE"],

    tags=["Dispositivos"]

)

# =====================================================
# LECTURAS
# =====================================================

router.add_api_route(

    "/lecturas",

    get_lecturas,

    methods=["GET"],

    tags=["Lecturas"]

)

router.add_api_route(

    "/lecturas",

    create_lectura,

    methods=["POST"],

    tags=["Lecturas"]

)

router.add_api_route(

    "/lecturas/{id}",

    update_lectura,

    methods=["PUT"],

    tags=["Lecturas"]

)

router.add_api_route(

    "/lecturas/{id}",

    delete_lectura,

    methods=["DELETE"],

    tags=["Lecturas"]

)

# =====================================================
# ALERTAS
# =====================================================

router.add_api_route(

    "/alertas",

    get_alertas,

    methods=["GET"],

    tags=["Alertas"]

)

router.add_api_route(

    "/alertas",

    create_alerta,

    methods=["POST"],

    tags=["Alertas"]

)

router.add_api_route(

    "/alertas/{id}",

    update_alerta,

    methods=["PUT"],

    tags=["Alertas"]

)

router.add_api_route(

    "/alertas/{id}",

    delete_alerta,

    methods=["DELETE"],

    tags=["Alertas"]

)

# =====================================================
# NOTIFICACIONES
# =====================================================

router.add_api_route(

    "/notificaciones",

    get_notificaciones,

    methods=["GET"],

    tags=["Notificaciones"]

)

router.add_api_route(

    "/notificaciones",

    create_notificacion,

    methods=["POST"],

    tags=["Notificaciones"]

)

router.add_api_route(

    "/notificaciones/{id}",

    update_notificacion,

    methods=["PUT"],

    tags=["Notificaciones"]

)

router.add_api_route(

    "/notificaciones/{id}",

    delete_notificacion,

    methods=["DELETE"],

    tags=["Notificaciones"]

)