from fastapi import HTTPException

from app.models.queries import (

    # =====================================================
    # USUARIOS
    # =====================================================

    get_usuarios_query,
    create_usuario_query,
    update_usuario_query,
    delete_usuario_query,

    # =====================================================
    # TRABAJADORES
    # =====================================================

    get_trabajadores_query,
    create_trabajador_query,
    update_trabajador_query,
    delete_trabajador_query,

    # =====================================================
    # DISPOSITIVOS
    # =====================================================

    get_dispositivos_query,
    create_dispositivo_query,
    update_dispositivo_query,
    delete_dispositivo_query,

    # =====================================================
    # LECTURAS
    # =====================================================

    get_lecturas_query,
    create_lectura_query,
    update_lectura_query,
    delete_lectura_query,

    # =====================================================
    # ALERTAS
    # =====================================================

    get_alertas_query,
    create_alerta_query,
    update_alerta_query,
    delete_alerta_query,

    # =====================================================
    # NOTIFICACIONES
    # =====================================================

    get_notificaciones_query,
    create_notificacion_query,
    update_notificacion_query,
    delete_notificacion_query

)

# =====================================================
# USUARIOS
# =====================================================

def get_usuarios():

    try:

        return get_usuarios_query()

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )


def create_usuario(data: dict):

    try:

        usuario_id = create_usuario_query(data)

        return {

            "message": "Usuario creado",

            "id": usuario_id

        }

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )


def update_usuario(id: int, data: dict):

    try:

        result = update_usuario_query(id, data)

        if result == 0:

            raise HTTPException(
                status_code=404,
                detail="Usuario no encontrado"
            )

        return {

            "message": "Usuario actualizado"

        }

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )


def delete_usuario(id: int):

    try:

        result = delete_usuario_query(id)

        if result == 0:

            raise HTTPException(
                status_code=404,
                detail="Usuario no encontrado"
            )

        return {

            "message": "Usuario eliminado"

        }

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )

# =====================================================
# TRABAJADORES
# =====================================================

def get_trabajadores():

    try:

        return get_trabajadores_query()

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )


def create_trabajador(data: dict):

    try:

        trabajador_id = create_trabajador_query(data)

        return {

            "message": "Trabajador creado",

            "id": trabajador_id

        }

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )


def update_trabajador(id: int, data: dict):

    try:

        result = update_trabajador_query(id, data)

        if result == 0:

            raise HTTPException(
                status_code=404,
                detail="Trabajador no encontrado"
            )

        return {

            "message": "Trabajador actualizado"

        }

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )


def delete_trabajador(id: int):

    try:

        result = delete_trabajador_query(id)

        if result == 0:

            raise HTTPException(
                status_code=404,
                detail="Trabajador no encontrado"
            )

        return {

            "message": "Trabajador eliminado"

        }

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )

# =====================================================
# DISPOSITIVOS
# =====================================================

def get_dispositivos():

    try:

        return get_dispositivos_query()

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )


def create_dispositivo(data: dict):

    try:

        dispositivo_id = create_dispositivo_query(data)

        return {

            "message": "Dispositivo creado",

            "id": dispositivo_id

        }

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )


def update_dispositivo(id: int, data: dict):

    try:

        result = update_dispositivo_query(id, data)

        if result == 0:

            raise HTTPException(
                status_code=404,
                detail="Dispositivo no encontrado"
            )

        return {

            "message": "Dispositivo actualizado"

        }

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )


def delete_dispositivo(id: int):

    try:

        result = delete_dispositivo_query(id)

        if result == 0:

            raise HTTPException(
                status_code=404,
                detail="Dispositivo no encontrado"
            )

        return {

            "message": "Dispositivo eliminado"

        }

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )

# =====================================================
# LECTURAS
# =====================================================

def get_lecturas():

    try:

        return get_lecturas_query()

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )


def create_lectura(data: dict):

    try:

        lectura_id = create_lectura_query(data)

        return {

            "message": "Lectura creada",

            "id": lectura_id

        }

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )


def update_lectura(id: int, data: dict):

    try:

        result = update_lectura_query(id, data)

        if result == 0:

            raise HTTPException(
                status_code=404,
                detail="Lectura no encontrada"
            )

        return {

            "message": "Lectura actualizada"

        }

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )


def delete_lectura(id: int):

    try:

        result = delete_lectura_query(id)

        if result == 0:

            raise HTTPException(
                status_code=404,
                detail="Lectura no encontrada"
            )

        return {

            "message": "Lectura eliminada"

        }

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )

# =====================================================
# ALERTAS
# =====================================================

def get_alertas():

    try:

        return get_alertas_query()

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )


def create_alerta(data: dict):

    try:

        alerta_id = create_alerta_query(data)

        return {

            "message": "Alerta creada",

            "id": alerta_id

        }

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )


def update_alerta(id: int, data: dict):

    try:

        result = update_alerta_query(id, data)

        if result == 0:

            raise HTTPException(
                status_code=404,
                detail="Alerta no encontrada"
            )

        return {

            "message": "Alerta actualizada"

        }

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )


def delete_alerta(id: int):

    try:

        result = delete_alerta_query(id)

        if result == 0:

            raise HTTPException(
                status_code=404,
                detail="Alerta no encontrada"
            )

        return {

            "message": "Alerta eliminada"

        }

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )

# =====================================================
# NOTIFICACIONES
# =====================================================

def get_notificaciones():

    try:

        return get_notificaciones_query()

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )


def create_notificacion(data: dict):

    try:

        notificacion_id = create_notificacion_query(data)

        return {

            "message": "Notificación creada",

            "id": notificacion_id

        }

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )


def update_notificacion(id: int, data: dict):

    try:

        result = update_notificacion_query(id, data)

        if result == 0:

            raise HTTPException(
                status_code=404,
                detail="Notificación no encontrada"
            )

        return {

            "message": "Notificación actualizada"

        }

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )


def delete_notificacion(id: int):

    try:

        result = delete_notificacion_query(id)

        if result == 0:

            raise HTTPException(
                status_code=404,
                detail="Notificación no encontrada"
            )

        return {

            "message": "Notificación eliminada"

        }

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )