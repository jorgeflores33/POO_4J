import mysql.connector

# =====================================================
# MYSQL CONNECTION
# =====================================================

try:

    connection = mysql.connector.connect(

        host="127.0.0.1",

        port=3306,

        user="root",

        password="12345",

        database="detector_incendios"

    )

    if connection.is_connected():

        print("✅ Base de datos conectada")

except Exception as e:

    print("❌ Error conectando MySQL")
    print(e)