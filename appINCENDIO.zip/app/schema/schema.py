from pydantic import BaseModel, EmailStr, Field
from typing import Optional

# =====================================================
# USUARIOS
# =====================================================

class UsuarioSchema(BaseModel):

    nombre: str = Field(
        ...,
        min_length=3,
        max_length=100
    )

    correo: EmailStr

    password: str = Field(
        ...,
        min_length=4,
        max_length=255
    )

    rol: Optional[str] = "ADMIN"

# =====================================================
# TRABAJADORES
# =====================================================

class TrabajadorSchema(BaseModel):

    nombre: str = Field(
        ...,
        min_length=3,
        max_length=100
    )

    telefono: str = Field(
        ...,
        min_length=8,
        max_length=20
    )

    area: Optional[str] = Field(
        default=None,
        max_length=100
    )

    activo: Optional[bool] = True

# =====================================================
# DISPOSITIVOS
# =====================================================

class DispositivoSchema(BaseModel):

    nombre: str = Field(
        ...,
        min_length=2,
        max_length=100
    )

    ubicacion: Optional[str] = Field(
        default=None,
        max_length=255
    )

    estado: Optional[str] = "ACTIVO"

# =====================================================
# LECTURAS
# =====================================================

class LecturaSchema(BaseModel):

    dispositivo_id: int

    humo: int = Field(
        ...,
        ge=0,
        le=4095
    )

    fuego: int = Field(
        ...,
        ge=0,
        le=4095
    )

    temperatura: int = Field(
        ...,
        ge=-50,
        le=150
    )

# =====================================================
# ALERTAS
# =====================================================

class AlertaSchema(BaseModel):

    dispositivo_id: int

    tipo: str = Field(
        ...,
        min_length=3,
        max_length=100
    )

    mensaje: str = Field(
        ...,
        min_length=3
    )

    nivel: str = Field(
        ...,
        min_length=3,
        max_length=50
    )

# =====================================================
# NOTIFICACIONES
# =====================================================

class NotificacionSchema(BaseModel):

    alerta_id: int

    trabajador_id: int

    mensaje: str = Field(
        ...,
        min_length=3
    )

    estado: Optional[str] = "ENVIADO"