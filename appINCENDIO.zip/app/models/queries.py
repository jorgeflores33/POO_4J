from app.db.database import connection

# =====================================================
# USUARIOS
# =====================================================

def get_usuarios_query():

    cursor = connection.cursor(dictionary=True)

    try:

        cursor.execute("SELECT * FROM usuarios")

        return cursor.fetchall()

    finally:

        cursor.close()


def create_usuario_query(data):

    cursor = connection.cursor()

    try:

        sql = """
            INSERT INTO usuarios
            (nombre, correo, password, rol)
            VALUES (%s, %s, %s, %s)
        """

        values = (
            data["nombre"],
            data["correo"],
            data["password"],
            data["rol"]
        )

        cursor.execute(sql, values)

        connection.commit()

        return cursor.lastrowid

    except Exception:

        connection.rollback()

        raise

    finally:

        cursor.close()


def update_usuario_query(id, data):

    cursor = connection.cursor()

    try:

        sql = """
            UPDATE usuarios
            SET nombre=%s,
                correo=%s,
                password=%s,
                rol=%s
            WHERE id=%s
        """

        values = (
            data["nombre"],
            data["correo"],
            data["password"],
            data["rol"],
            id
        )

        cursor.execute(sql, values)

        connection.commit()

        return cursor.rowcount

    except Exception:

        connection.rollback()

        raise

    finally:

        cursor.close()


def delete_usuario_query(id):

    cursor = connection.cursor()

    try:

        cursor.execute(
            "DELETE FROM usuarios WHERE id=%s",
            (id,)
        )

        connection.commit()

        return cursor.rowcount

    except Exception:

        connection.rollback()

        raise

    finally:

        cursor.close()

# =====================================================
# TRABAJADORES
# =====================================================

def get_trabajadores_query():

    cursor = connection.cursor(dictionary=True)

    try:

        cursor.execute("SELECT * FROM trabajadores")

        return cursor.fetchall()

    finally:

        cursor.close()


def create_trabajador_query(data):

    cursor = connection.cursor()

    try:

        sql = """
            INSERT INTO trabajadores
            (nombre, telefono, area, activo)
            VALUES (%s, %s, %s, %s)
        """

        values = (
            data["nombre"],
            data["telefono"],
            data["area"],
            data["activo"]
        )

        cursor.execute(sql, values)

        connection.commit()

        return cursor.lastrowid

    except Exception:

        connection.rollback()

        raise

    finally:

        cursor.close()


def update_trabajador_query(id, data):

    cursor = connection.cursor()

    try:

        sql = """
            UPDATE trabajadores
            SET nombre=%s,
                telefono=%s,
                area=%s,
                activo=%s
            WHERE id=%s
        """

        values = (
            data["nombre"],
            data["telefono"],
            data["area"],
            data["activo"],
            id
        )

        cursor.execute(sql, values)

        connection.commit()

        return cursor.rowcount

    except Exception:

        connection.rollback()

        raise

    finally:

        cursor.close()


def delete_trabajador_query(id):

    cursor = connection.cursor()

    try:

        cursor.execute(
            "DELETE FROM trabajadores WHERE id=%s",
            (id,)
        )

        connection.commit()

        return cursor.rowcount

    except Exception:

        connection.rollback()

        raise

    finally:

        cursor.close()

# =====================================================
# DISPOSITIVOS
# =====================================================

def get_dispositivos_query():

    cursor = connection.cursor(dictionary=True)

    try:

        cursor.execute("SELECT * FROM dispositivos")

        return cursor.fetchall()

    finally:

        cursor.close()


def create_dispositivo_query(data):

    cursor = connection.cursor()

    try:

        sql = """
            INSERT INTO dispositivos
            (nombre, ubicacion, estado)
            VALUES (%s, %s, %s)
        """

        values = (
            data["nombre"],
            data["ubicacion"],
            data["estado"]
        )

        cursor.execute(sql, values)

        connection.commit()

        return cursor.lastrowid

    except Exception:

        connection.rollback()

        raise

    finally:

        cursor.close()


def update_dispositivo_query(id, data):

    cursor = connection.cursor()

    try:

        sql = """
            UPDATE dispositivos
            SET nombre=%s,
                ubicacion=%s,
                estado=%s
            WHERE id=%s
        """

        values = (
            data["nombre"],
            data["ubicacion"],
            data["estado"],
            id
        )

        cursor.execute(sql, values)

        connection.commit()

        return cursor.rowcount

    except Exception:

        connection.rollback()

        raise

    finally:

        cursor.close()


def delete_dispositivo_query(id):

    cursor = connection.cursor()

    try:

        cursor.execute(
            "DELETE FROM dispositivos WHERE id=%s",
            (id,)
        )

        connection.commit()

        return cursor.rowcount

    except Exception:

        connection.rollback()

        raise

    finally:

        cursor.close()

# =====================================================
# LECTURAS
# =====================================================

def get_lecturas_query():

    cursor = connection.cursor(dictionary=True)

    try:

        cursor.execute("SELECT * FROM lecturas")

        return cursor.fetchall()

    finally:

        cursor.close()


def create_lectura_query(data):

    cursor = connection.cursor()

    try:

        sql = """
            INSERT INTO lecturas
            (dispositivo_id, humo, fuego, temperatura)
            VALUES (%s, %s, %s, %s)
        """

        values = (
            data["dispositivo_id"],
            data["humo"],
            data["fuego"],
            data["temperatura"]
        )

        cursor.execute(sql, values)

        connection.commit()

        return cursor.lastrowid

    except Exception:

        connection.rollback()

        raise

    finally:

        cursor.close()


def update_lectura_query(id, data):

    cursor = connection.cursor()

    try:

        sql = """
            UPDATE lecturas
            SET dispositivo_id=%s,
                humo=%s,
                fuego=%s,
                temperatura=%s
            WHERE id=%s
        """

        values = (
            data["dispositivo_id"],
            data["humo"],
            data["fuego"],
            data["temperatura"],
            id
        )

        cursor.execute(sql, values)

        connection.commit()

        return cursor.rowcount

    except Exception:

        connection.rollback()

        raise

    finally:

        cursor.close()


def delete_lectura_query(id):

    cursor = connection.cursor()

    try:

        cursor.execute(
            "DELETE FROM lecturas WHERE id=%s",
            (id,)
        )

        connection.commit()

        return cursor.rowcount

    except Exception:

        connection.rollback()

        raise

    finally:

        cursor.close()

# =====================================================
# ALERTAS
# =====================================================

def get_alertas_query():

    cursor = connection.cursor(dictionary=True)

    try:

        cursor.execute("SELECT * FROM alertas")

        return cursor.fetchall()

    finally:

        cursor.close()


def create_alerta_query(data):

    cursor = connection.cursor()

    try:

        sql = """
            INSERT INTO alertas
            (dispositivo_id, tipo, mensaje, nivel)
            VALUES (%s, %s, %s, %s)
        """

        values = (
            data["dispositivo_id"],
            data["tipo"],
            data["mensaje"],
            data["nivel"]
        )

        cursor.execute(sql, values)

        connection.commit()

        return cursor.lastrowid

    except Exception:

        connection.rollback()

        raise

    finally:

        cursor.close()


def update_alerta_query(id, data):

    cursor = connection.cursor()

    try:

        sql = """
            UPDATE alertas
            SET dispositivo_id=%s,
                tipo=%s,
                mensaje=%s,
                nivel=%s
            WHERE id=%s
        """

        values = (
            data["dispositivo_id"],
            data["tipo"],
            data["mensaje"],
            data["nivel"],
            id
        )

        cursor.execute(sql, values)

        connection.commit()

        return cursor.rowcount

    except Exception:

        connection.rollback()

        raise

    finally:

        cursor.close()


def delete_alerta_query(id):

    cursor = connection.cursor()

    try:

        cursor.execute(
            "DELETE FROM alertas WHERE id=%s",
            (id,)
        )

        connection.commit()

        return cursor.rowcount

    except Exception:

        connection.rollback()

        raise

    finally:

        cursor.close()

# =====================================================
# NOTIFICACIONES
# =====================================================

def get_notificaciones_query():

    cursor = connection.cursor(dictionary=True)

    try:

        cursor.execute("SELECT * FROM notificaciones")

        return cursor.fetchall()

    finally:

        cursor.close()


def create_notificacion_query(data):

    cursor = connection.cursor()

    try:

        sql = """
            INSERT INTO notificaciones
            (alerta_id, trabajador_id, mensaje, estado)
            VALUES (%s, %s, %s, %s)
        """

        values = (
            data["alerta_id"],
            data["trabajador_id"],
            data["mensaje"],
            data["estado"]
        )

        cursor.execute(sql, values)

        connection.commit()

        return cursor.lastrowid

    except Exception:

        connection.rollback()

        raise

    finally:

        cursor.close()


def update_notificacion_query(id, data):

    cursor = connection.cursor()

    try:

        sql = """
            UPDATE notificaciones
            SET alerta_id=%s,
                trabajador_id=%s,
                mensaje=%s,
                estado=%s
            WHERE id=%s
        """

        values = (
            data["alerta_id"],
            data["trabajador_id"],
            data["mensaje"],
            data["estado"],
            id
        )

        cursor.execute(sql, values)

        connection.commit()

        return cursor.rowcount

    except Exception:

        connection.rollback()

        raise

    finally:

        cursor.close()


def delete_notificacion_query(id):

    cursor = connection.cursor()

    try:

        cursor.execute(
            "DELETE FROM notificaciones WHERE id=%s",
            (id,)
        )

        connection.commit()

        return cursor.rowcount

    except Exception:

        connection.rollback()

        raise

    finally:

        cursor.close()