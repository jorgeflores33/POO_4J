// ======================================================
// API
// ======================================================

const API_URL = "http://127.0.0.1:8000";



// ======================================================
// ELEMENTOS
// ======================================================

const tablaAutos =
    document.getElementById("tablaAutos");

const formAuto =
    document.getElementById("formAuto");

const buscarAuto =
    document.getElementById("buscarAuto");

const tituloFormulario =
    document.getElementById("tituloFormulario");



// ======================================================
// CARGAR AUTOS
// ======================================================

async function cargarAutos() {

    try {

        const response = await fetch(
            `${API_URL}/autos`
        );

        const autos = await response.json();

        tablaAutos.innerHTML = "";


        autos.forEach(auto => {

            tablaAutos.innerHTML += `

                <tr>

                    <td>${auto.id_auto}</td>

                    <td>${auto.marca}</td>

                    <td>${auto.modelo}</td>

                    <td>${auto.anio}</td>

                    <td>${auto.color}</td>

                    <td>$${auto.precio}</td>

                    <td>${auto.stock}</td>

                    <td>

                        <div class="acciones">

                            <button
                                class="btn-ver"
                                onclick="editarAuto(${auto.id_auto})">

                                <i class="fa-solid fa-pen"></i>

                            </button>


                            <button
                                class="btn-eliminar"
                                onclick="eliminarAuto(${auto.id_auto})">

                                <i class="fa-solid fa-trash"></i>

                            </button>

                        </div>

                    </td>

                </tr>

            `;

        });

    }

    catch(error) {

        console.error(error);

        alert(
            "Error al cargar autos"
        );

    }

}



// ======================================================
// REGISTRAR O EDITAR
// ======================================================

formAuto.addEventListener("submit", async (e) => {

    e.preventDefault();


    const id =
        document.getElementById("idAuto").value;


    const auto = {

        marca:
            document.getElementById("marca").value,

        modelo:
            document.getElementById("modelo").value,

        anio:
            parseInt(
                document.getElementById("anio").value
            ),

        color:
            document.getElementById("color").value,

        precio:
            parseFloat(
                document.getElementById("precio").value
            ),

        stock:
            parseInt(
                document.getElementById("stock").value
            )

    };


    try {

        // ==========================================
        // EDITAR
        // ==========================================

        if(id) {

            await fetch(

                `${API_URL}/autos/${id}`,

                {

                    method: "PUT",

                    headers: {

                        "Content-Type":
                            "application/json"

                    },

                    body: JSON.stringify(auto)

                }

            );

            alert(
                "Auto actualizado"
            );

        }


        // ==========================================
        // REGISTRAR
        // ==========================================

        else {

            await fetch(

                `${API_URL}/autos`,

                {

                    method: "POST",

                    headers: {

                        "Content-Type":
                            "application/json"

                    },

                    body: JSON.stringify(auto)

                }

            );

            alert(
                "Auto registrado"
            );

        }


        formAuto.reset();

        document.getElementById("idAuto").value = "";

        tituloFormulario.innerText =
            "Registrar Auto";


        cargarAutos();

    }

    catch(error) {

        console.error(error);

        alert(
            "Error al guardar auto"
        );

    }

});



// ======================================================
// EDITAR
// ======================================================

async function editarAuto(id) {

    try {

        const response = await fetch(
            `${API_URL}/autos`
        );

        const autos = await response.json();


        const auto =
            autos.find(
                a => a.id_auto == id
            );


        document.getElementById("idAuto").value =
            auto.id_auto;

        document.getElementById("marca").value =
            auto.marca;

        document.getElementById("modelo").value =
            auto.modelo;

        document.getElementById("anio").value =
            auto.anio;

        document.getElementById("color").value =
            auto.color;

        document.getElementById("precio").value =
            auto.precio;

        document.getElementById("stock").value =
            auto.stock;


        tituloFormulario.innerText =
            "Editar Auto";

    }

    catch(error) {

        console.error(error);

    }

}



// ======================================================
// ELIMINAR
// ======================================================

async function eliminarAuto(id) {

    const confirmar = confirm(
        "¿Deseas eliminar este auto?"
    );


    if(!confirmar) {

        return;

    }


    try {

        await fetch(

            `${API_URL}/autos/${id}`,

            {

                method: "DELETE"

            }

        );

        cargarAutos();

        alert(
            "Auto eliminado"
        );

    }

    catch(error) {

        console.error(error);

        alert(
            "Error al eliminar auto"
        );

    }

}



// ======================================================
// LIMPIAR
// ======================================================

function limpiarFormulario() {

    formAuto.reset();

    document.getElementById("idAuto").value = "";

    tituloFormulario.innerText =
        "Registrar Auto";

}



// ======================================================
// BUSCADOR
// ======================================================

buscarAuto.addEventListener("keyup", () => {

    const texto =
        buscarAuto.value.toLowerCase();


    const filas =
        tablaAutos.querySelectorAll("tr");


    filas.forEach(fila => {

        const contenido =
            fila.textContent.toLowerCase();


        if(
            contenido.includes(texto)
        ) {

            fila.style.display = "";

        }

        else {

            fila.style.display = "none";

        }

    });

});



// ======================================================
// CERRAR SESION
// ======================================================

function cerrarSesion() {

    localStorage.clear();

    window.location.href =
        "index.html";

}



// ======================================================
// VALIDAR SESION
// ======================================================

window.addEventListener("load", () => {

    const usuario =
        localStorage.getItem("usuario");


    if(!usuario) {

        window.location.href =
            "index.html";

    }


    cargarAutos();

});