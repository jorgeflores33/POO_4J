// =====================================================
// VALIDAR SESION
// =====================================================

const usuario = localStorage.getItem("usuario");

const rol = localStorage.getItem("rol");


// =====================================================
// SI NO EXISTE SESION
// =====================================================

if(!usuario || !rol){

    window.location.href = "index.html";

}



// =====================================================
// CARDS
// =====================================================

const cardAdmin =
    document.getElementById("cardAdmin");

const cardMantenimiento =
    document.getElementById("cardMantenimiento");

const cardVenta =
    document.getElementById("cardVenta");



// =====================================================
// VALIDAR PERMISOS
// =====================================================

function aplicarPermisos(){


    // =============================================
    // ADMIN
    // =============================================

    if(rol === "admin"){

        return;

    }


    // =============================================
    // MANTENIMIENTO
    // =============================================

    if(rol === "mantenimiento"){

        cardAdmin.classList.add("disabled");

        cardVenta.classList.add("disabled");

    }


    // =============================================
    // VENTA
    // =============================================

    if(rol === "venta"){

        cardAdmin.classList.add("disabled");

        cardMantenimiento.classList.add("disabled");

    }

}


aplicarPermisos();



// =====================================================
// ENTRAR MODULO
// =====================================================

function entrarModulo(ruta){

    window.location.href = ruta;

}



// =====================================================
// CERRAR SESION
// =====================================================

function cerrarSesion(){

    localStorage.clear();

    window.location.href = "index.html";

}