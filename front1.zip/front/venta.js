// ======================================================
// API
// ======================================================

const API_URL = "http://127.0.0.1:8000";



// ======================================================
// VALIDAR SESION
// ======================================================

const rol = localStorage.getItem("rol");

if (!rol) {

    window.location.href = "index.html";

}



// ======================================================
// RESTRICCIONES
// ======================================================

function validarAcceso(pagina) {

    const rolUsuario = localStorage.getItem("rol");


    // ADMIN TIENE ACCESO A TODO
    if (rolUsuario === "admin") {

        window.location.href = pagina;

        return;

    }


    // VENTA SOLO PUEDE ENTRAR A VENTA
    if (
        rolUsuario === "venta" &&
        pagina !== "venta.html"
    ) {

        alert(
            "No tienes acceso a este módulo"
        );

        return;

    }


    // MANTENIMIENTO SOLO PUEDE ENTRAR A MANTENIMIENTO
    if (
        rolUsuario === "mantenimiento" &&
        pagina !== "mantenimiento.html"
    ) {

        alert(
            "No tienes acceso a este módulo"
        );

        return;

    }


    window.location.href = pagina;

}



// ======================================================
// VARIABLES
// ======================================================

const tablaVentas =
    document.getElementById("tablaVentas");

const formVenta =
    document.getElementById("formVenta");

const tituloFormulario =
    document.getElementById("tituloFormulario");

const btnCancelar =
    document.getElementById("btnCancelar");



// ======================================================
// CARGAR VENTAS
// ======================================================

async function cargarVentas() {

    try {

        const response = await fetch(
            `${API_URL}/ventas`
        );

        const ventas =
            await response.json();


        tablaVentas.innerHTML = "";


        ventas.forEach(venta => {

            tablaVentas.innerHTML += `

                <tr>

                    <td>${venta.id_venta}</td>

                    <td>${venta.cliente}</td>

                    <td>${venta.empleado}</td>

                    <td>${venta.auto}</td>

                    <td>${venta.fecha}</td>

                    <td>$${venta.total}</td>

                    <td class="acciones">

                        <button
                            class="btn-ver"
                            onclick="editarVenta(${venta.id_venta})">

                            <i class="fa-solid fa-pen"></i>

                        </button>

                        <button
                            class="btn-eliminar"
                            onclick="eliminarVenta(${venta.id_venta})">

                            <i class="fa-solid fa-trash"></i>

                        </button>

                    </td>

                </tr>

            `;

        });

    }

    catch (error) {

        console.error(error);

        alert(
            "Error al cargar ventas"
        );

    }

}



// ======================================================
// GUARDAR VENTA
// ======================================================

formVenta.addEventListener("submit", async (e) => {

    e.preventDefault();


    const idVenta =
        document.getElementById("idVenta").value;


    const data = {

        cliente:
            document.getElementById("cliente").value,

        empleado:
            document.getElementById("empleado").value,

        auto:
            document.getElementById("auto").value,

        fecha:
            document.getElementById("fecha").value,

        total:
            parseFloat(
                document.getElementById("total").value
            )

    };


    try {

        // ======================================================
        // CREAR
        // ======================================================

        if (idVenta === "") {

            await fetch(
                `${API_URL}/ventas`,
                {

                    method: "POST",

                    headers: {

                        "Content-Type":
                            "application/json"

                    },

                    body: JSON.stringify(data)

                }
            );

        }


        // ======================================================
        // ACTUALIZAR
        // ======================================================

        else {

            await fetch(
                `${API_URL}/ventas/${idVenta}`,
                {

                    method: "PUT",

                    headers: {

                        "Content-Type":
                            "application/json"

                    },

                    body: JSON.stringify(data)

                }
            );

        }


        limpiarFormulario();

        cargarVentas();


        alert(
            "Venta guardada correctamente"
        );

    }

    catch (error) {

        console.error(error);

        alert(
            "Error al guardar venta"
        );

    }

});



// ======================================================
// EDITAR
// ======================================================

async function editarVenta(id) {

    try {

        const response =
            await fetch(
                `${API_URL}/ventas`
            );

        const ventas =
            await response.json();


        const venta =
            ventas.find(v => v.id_venta == id);


        document.getElementById("idVenta").value =
            venta.id_venta;

        document.getElementById("cliente").value =
            venta.cliente;

        document.getElementById("empleado").value =
            venta.empleado;

        document.getElementById("auto").value =
            venta.auto;

        document.getElementById("fecha").value =
            venta.fecha;

        document.getElementById("total").value =
            venta.total;


        tituloFormulario.innerText =
            "Editar Venta";

    }

    catch (error) {

        console.error(error);

    }

}



// ======================================================
// ELIMINAR
// ======================================================

async function eliminarVenta(id) {

    const confirmar = confirm(
        "¿Deseas eliminar esta venta?"
    );


    if (!confirmar) {

        return;

    }


    try {

        await fetch(
            `${API_URL}/ventas/${id}`,
            {

                method: "DELETE"

            }
        );


        cargarVentas();


        alert(
            "Venta eliminada"
        );

    }

    catch (error) {

        console.error(error);

        alert(
            "Error al eliminar venta"
        );

    }

}



// ======================================================
// LIMPIAR
// ======================================================

function limpiarFormulario() {

    formVenta.reset();

    document.getElementById("idVenta").value = "";

    tituloFormulario.innerText =
        "Registrar Venta";

}



// ======================================================
// CERRAR SESION
// ======================================================

function cerrarSesion() {

    localStorage.clear();

    window.location.href =
        "index.html";

}



// ======================================================
// INICIO
// ======================================================

cargarVentas();