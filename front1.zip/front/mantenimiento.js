// ======================================================
// API
// ======================================================

const API_URL = "http://127.0.0.1:8000";



// ======================================================
// VALIDAR SESION
// ======================================================

const rol = localStorage.getItem("rol");

if (!rol) {

    window.location.href = "index.html";

}



// ======================================================
// RESTRICCIONES
// ======================================================

function validarAcceso(pagina) {

    const rolUsuario = localStorage.getItem("rol");


    // ======================================================
    // ADMIN
    // ======================================================

    if (rolUsuario === "admin") {

        window.location.href = pagina;

        return;

    }


    // ======================================================
    // MANTENIMIENTO
    // ======================================================

    if (
        rolUsuario === "mantenimiento" &&
        pagina !== "mantenimiento.html"
    ) {

        alert(
            "No tienes acceso a este módulo"
        );

        return;

    }


    // ======================================================
    // VENTA
    // ======================================================

    if (
        rolUsuario === "venta" &&
        pagina !== "venta.html"
    ) {

        alert(
            "No tienes acceso a este módulo"
        );

        return;

    }


    window.location.href = pagina;

}



// ======================================================
// VARIABLES
// ======================================================

const tablaMantenimientos =
    document.getElementById("tablaMantenimientos");

const formMantenimiento =
    document.getElementById("formMantenimiento");

const tituloFormulario =
    document.getElementById("tituloFormulario");



// ======================================================
// CARGAR MANTENIMIENTOS
// ======================================================

async function cargarMantenimientos() {

    try {

        const response = await fetch(
            `${API_URL}/mantenimiento`
        );


        // ======================================================
        // VALIDAR RESPUESTA
        // ======================================================

        if (!response.ok) {

            throw new Error(
                `Error HTTP: ${response.status}`
            );

        }


        const mantenimientos =
            await response.json();


        tablaMantenimientos.innerHTML = "";


        mantenimientos.forEach(mantenimiento => {

            tablaMantenimientos.innerHTML += `

                <tr>

                    <td>
                        ${mantenimiento.id_mantenimiento}
                    </td>

                    <td>
                        ${mantenimiento.auto}
                    </td>

                    <td>
                        ${mantenimiento.descripcion}
                    </td>

                    <td>
                        ${mantenimiento.fecha}
                    </td>

                    <td>
                        $${mantenimiento.costo}
                    </td>

                    <td class="acciones">

                        <button
                            class="btn-editar"
                            onclick="editarMantenimiento(${mantenimiento.id_mantenimiento})">

                            <i class="fa-solid fa-pen"></i>

                        </button>


                        <button
                            class="btn-eliminar"
                            onclick="eliminarMantenimiento(${mantenimiento.id_mantenimiento})">

                            <i class="fa-solid fa-trash"></i>

                        </button>

                    </td>

                </tr>

            `;

        });

    }

    catch (error) {

        console.error(
            "Error al cargar mantenimientos:",
            error
        );

        alert(
            "Error al cargar mantenimientos"
        );

    }

}



// ======================================================
// REGISTRAR / EDITAR
// ======================================================

formMantenimiento.addEventListener("submit", async (e) => {

    e.preventDefault();


    const id =
        document.getElementById("idMantenimiento").value;


    const data = {

        auto:
            document.getElementById("auto").value,

        descripcion:
            document.getElementById("descripcion").value,

        fecha:
            document.getElementById("fecha").value,

        costo:
            parseFloat(
                document.getElementById("costo").value
            )

    };


    try {

        // ======================================================
        // REGISTRAR
        // ======================================================

        if (id === "") {

            const response = await fetch(
                `${API_URL}/mantenimiento`,
                {

                    method: "POST",

                    headers: {

                        "Content-Type":
                            "application/json"

                    },

                    body: JSON.stringify(data)

                }
            );


            if (!response.ok) {

                throw new Error(
                    `Error HTTP: ${response.status}`
                );

            }

        }


        // ======================================================
        // EDITAR
        // ======================================================

        else {

            const response = await fetch(
                `${API_URL}/mantenimiento/${id}`,
                {

                    method: "PUT",

                    headers: {

                        "Content-Type":
                            "application/json"

                    },

                    body: JSON.stringify(data)

                }
            );


            if (!response.ok) {

                throw new Error(
                    `Error HTTP: ${response.status}`
                );

            }

        }


        limpiarFormulario();

        cargarMantenimientos();


        alert(
            "Mantenimiento guardado correctamente"
        );

    }

    catch (error) {

        console.error(
            "Error al guardar mantenimiento:",
            error
        );

        alert(
            "Error al guardar mantenimiento"
        );

    }

});



// ======================================================
// EDITAR
// ======================================================

async function editarMantenimiento(id) {

    try {

        const response = await fetch(
            `${API_URL}/mantenimiento`
        );


        if (!response.ok) {

            throw new Error(
                `Error HTTP: ${response.status}`
            );

        }


        const mantenimientos =
            await response.json();


        const mantenimiento =
            mantenimientos.find(
                m => m.id_mantenimiento == id
            );


        document.getElementById("idMantenimiento").value =
            mantenimiento.id_mantenimiento;

        document.getElementById("auto").value =
            mantenimiento.auto;

        document.getElementById("descripcion").value =
            mantenimiento.descripcion;

        document.getElementById("fecha").value =
            mantenimiento.fecha;

        document.getElementById("costo").value =
            mantenimiento.costo;


        tituloFormulario.innerText =
            "Editar Mantenimiento";

    }

    catch (error) {

        console.error(
            "Error al editar mantenimiento:",
            error
        );

    }

}



// ======================================================
// ELIMINAR
// ======================================================

async function eliminarMantenimiento(id) {

    const confirmar = confirm(
        "¿Deseas eliminar este mantenimiento?"
    );


    if (!confirmar) {

        return;

    }


    try {

        const response = await fetch(
            `${API_URL}/mantenimiento/${id}`,
            {

                method: "DELETE"

            }
        );


        if (!response.ok) {

            throw new Error(
                `Error HTTP: ${response.status}`
            );

        }


        cargarMantenimientos();


        alert(
            "Mantenimiento eliminado"
        );

    }

    catch (error) {

        console.error(
            "Error al eliminar mantenimiento:",
            error
        );

        alert(
            "Error al eliminar mantenimiento"
        );

    }

}



// ======================================================
// LIMPIAR
// ======================================================

function limpiarFormulario() {

    formMantenimiento.reset();

    document.getElementById(
        "idMantenimiento"
    ).value = "";

    tituloFormulario.innerText =
        "Registrar Mantenimiento";

}



// ======================================================
// CERRAR SESION
// ======================================================

function cerrarSesion() {

    localStorage.clear();

    window.location.href =
        "index.html";

}



// ======================================================
// INICIO
// ======================================================

cargarMantenimientos();