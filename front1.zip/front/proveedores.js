// ======================================
// API
// ======================================

const API_URL =
    "http://127.0.0.1:8000";



// ======================================
// VALIDAR SESION
// ======================================

const usuario =
    localStorage.getItem("usuario");

if(!usuario){

    window.location.href =
        "index.html";

}



// ======================================
// ELEMENTOS
// ======================================

const tablaProveedores =
    document.getElementById("tablaProveedores");

const formProveedor =
    document.getElementById("formProveedor");

const buscarProveedor =
    document.getElementById("buscarProveedor");



// ======================================
// CARGAR PROVEEDORES
// ======================================

async function cargarProveedores(){

    try{

        const response =
            await fetch(
                `${API_URL}/proveedores`
            );

        const data =
            await response.json();


        tablaProveedores.innerHTML = "";


        data.forEach(proveedor => {

            tablaProveedores.innerHTML += `

                <tr>

                    <td>
                        ${proveedor.id_proveedor}
                    </td>

                    <td>
                        ${proveedor.empresa}
                    </td>

                    <td>
                        ${proveedor.telefono}
                    </td>

                    <td>
                        ${proveedor.correo}
                    </td>

                    <td>
                        ${proveedor.direccion}
                    </td>

                    <td>

                        <button
                            class="btn-accion btn-editar"
                            onclick="editarProveedor(${proveedor.id_proveedor})">

                            <i class="fa-solid fa-pen"></i>

                        </button>


                        <button
                            class="btn-accion btn-eliminar"
                            onclick="eliminarProveedor(${proveedor.id_proveedor})">

                            <i class="fa-solid fa-trash"></i>

                        </button>

                    </td>

                </tr>

            `;

        });

    }

    catch(error){

        console.error(error);

        alert(
            "Error al cargar proveedores"
        );

    }

}



// ======================================
// GUARDAR
// ======================================

formProveedor.addEventListener(
    "submit",
    async function(e){

        e.preventDefault();


        const id =
            document.getElementById("idProveedor").value;


        const proveedor = {

            empresa:
                document.getElementById("empresa").value,

            telefono:
                document.getElementById("telefono").value,

            correo:
                document.getElementById("correo").value,

            direccion:
                document.getElementById("direccion").value

        };


        try{

            // EDITAR
            if(id){

                await fetch(

                    `${API_URL}/proveedores/${id}`,

                    {

                        method: "PUT",

                        headers: {

                            "Content-Type":
                                "application/json"

                        },

                        body: JSON.stringify(proveedor)

                    }

                );

            }


            // CREAR
            else{

                await fetch(

                    `${API_URL}/proveedores`,

                    {

                        method: "POST",

                        headers: {

                            "Content-Type":
                                "application/json"

                        },

                        body: JSON.stringify(proveedor)

                    }

                );

            }


            limpiarFormulario();

            cargarProveedores();

        }

        catch(error){

            console.error(error);

            alert(
                "Error al guardar proveedor"
            );

        }

    }
);



// ======================================
// EDITAR
// ======================================

async function editarProveedor(id){

    try{

        const response =
            await fetch(
                `${API_URL}/proveedores`
            );

        const data =
            await response.json();


        const proveedor =
            data.find(p =>
                p.id_proveedor === id
            );


        document.getElementById("idProveedor").value =
            proveedor.id_proveedor;

        document.getElementById("empresa").value =
            proveedor.empresa;

        document.getElementById("telefono").value =
            proveedor.telefono;

        document.getElementById("correo").value =
            proveedor.correo;

        document.getElementById("direccion").value =
            proveedor.direccion;


        document.getElementById("tituloFormulario").innerText =
            "Editar Proveedor";

    }

    catch(error){

        console.error(error);

    }

}



// ======================================
// ELIMINAR
// ======================================

async function eliminarProveedor(id){

    const confirmar =
        confirm(
            "¿Eliminar proveedor?"
        );


    if(!confirmar){

        return;

    }


    try{

        await fetch(

            `${API_URL}/proveedores/${id}`,

            {

                method: "DELETE"

            }

        );


        cargarProveedores();

    }

    catch(error){

        console.error(error);

        alert(
            "Error al eliminar proveedor"
        );

    }

}



// ======================================
// LIMPIAR
// ======================================

function limpiarFormulario(){

    formProveedor.reset();

    document.getElementById("idProveedor").value = "";

    document.getElementById("tituloFormulario").innerText =
        "Registrar Proveedor";

}



// ======================================
// BUSCADOR
// ======================================

buscarProveedor.addEventListener(
    "keyup",
    function(){

        const texto =
            buscarProveedor.value.toLowerCase();

        const filas =
            document.querySelectorAll(
                "#tablaProveedores tr"
            );


        filas.forEach(fila => {

            const contenido =
                fila.textContent.toLowerCase();

            fila.style.display =
                contenido.includes(texto)
                ? ""
                : "none";

        });

    }
);



// ======================================
// CERRAR SESION
// ======================================

function cerrarSesion(){

    localStorage.clear();

    window.location.href =
        "index.html";

}



// ======================================
// INICIAR
// ======================================

cargarProveedores();