// ======================================
// API
// ======================================

const API_URL =
    "http://127.0.0.1:8000";



// ======================================
// VALIDAR SESION
// ======================================

const usuario =
    localStorage.getItem("usuario");

if(!usuario){

    window.location.href =
        "index.html";

}



// ======================================
// ELEMENTOS
// ======================================

const tablaTrabajadores =
    document.getElementById("tablaTrabajadores");

const formTrabajador =
    document.getElementById("formTrabajador");

const buscarTrabajador =
    document.getElementById("buscarTrabajador");



// ======================================
// CARGAR TRABAJADORES
// ======================================

async function cargarTrabajadores(){

    try{

        const response =
            await fetch(
                `${API_URL}/empleados`
            );

        const data =
            await response.json();


        tablaTrabajadores.innerHTML = "";


        data.forEach(trabajador => {

            tablaTrabajadores.innerHTML += `

                <tr>

                    <td>
                        ${trabajador.id_empleado}
                    </td>

                    <td>
                        ${trabajador.nombre}
                    </td>

                    <td>
                        ${trabajador.puesto}
                    </td>

                    <td>
                        ${trabajador.telefono}
                    </td>

                    <td>
                        $${trabajador.salario}
                    </td>

                    <td>
                        ${trabajador.usuario}
                    </td>

                    <td>
                        ${trabajador.rol}
                    </td>

                    <td>

                        <button
                            class="btn-accion btn-editar"
                            onclick="editarTrabajador(${trabajador.id_empleado})">

                            <i class="fa-solid fa-pen"></i>

                        </button>


                        <button
                            class="btn-accion btn-eliminar"
                            onclick="eliminarTrabajador(${trabajador.id_empleado})">

                            <i class="fa-solid fa-trash"></i>

                        </button>

                    </td>

                </tr>

            `;

        });

    }

    catch(error){

        console.error(error);

        alert(
            "Error al cargar trabajadores"
        );

    }

}



// ======================================
// GUARDAR
// ======================================

formTrabajador.addEventListener(
    "submit",
    async function(e){

        e.preventDefault();


        const id =
            document.getElementById("idTrabajador").value;


        const trabajador = {

            nombre:
                document.getElementById("nombre").value,

            puesto:
                document.getElementById("puesto").value,

            telefono:
                document.getElementById("telefono").value,

            salario:
                parseFloat(
                    document.getElementById("salario").value
                ),

            usuario:
                document.getElementById("usuario").value,

            contrasena:
                document.getElementById("contrasena").value,

            rol:
                document.getElementById("rol").value

        };


        try{

            // EDITAR
            if(id){

                await fetch(

                    `${API_URL}/empleados/${id}`,

                    {

                        method: "PUT",

                        headers: {

                            "Content-Type":
                                "application/json"

                        },

                        body: JSON.stringify(trabajador)

                    }

                );

            }


            // CREAR
            else{

                await fetch(

                    `${API_URL}/empleados`,

                    {

                        method: "POST",

                        headers: {

                            "Content-Type":
                                "application/json"

                        },

                        body: JSON.stringify(trabajador)

                    }

                );

            }


            limpiarFormulario();

            cargarTrabajadores();

        }

        catch(error){

            console.error(error);

            alert(
                "Error al guardar trabajador"
            );

        }

    }
);



// ======================================
// EDITAR
// ======================================

async function editarTrabajador(id){

    try{

        const response =
            await fetch(
                `${API_URL}/empleados`
            );

        const data =
            await response.json();


        const trabajador =
            data.find(t =>
                t.id_empleado === id
            );


        document.getElementById("idTrabajador").value =
            trabajador.id_empleado;

        document.getElementById("nombre").value =
            trabajador.nombre;

        document.getElementById("puesto").value =
            trabajador.puesto;

        document.getElementById("telefono").value =
            trabajador.telefono;

        document.getElementById("salario").value =
            trabajador.salario;

        document.getElementById("usuario").value =
            trabajador.usuario;

        document.getElementById("contrasena").value =
            trabajador.contrasena;

        document.getElementById("rol").value =
            trabajador.rol;


        document.getElementById("tituloFormulario").innerText =
            "Editar Trabajador";

    }

    catch(error){

        console.error(error);

    }

}



// ======================================
// ELIMINAR
// ======================================

async function eliminarTrabajador(id){

    const confirmar =
        confirm(
            "¿Eliminar trabajador?"
        );


    if(!confirmar){

        return;

    }


    try{

        await fetch(

            `${API_URL}/empleados/${id}`,

            {

                method: "DELETE"

            }

        );


        cargarTrabajadores();

    }

    catch(error){

        console.error(error);

        alert(
            "Error al eliminar trabajador"
        );

    }

}



// ======================================
// LIMPIAR
// ======================================

function limpiarFormulario(){

    formTrabajador.reset();

    document.getElementById("idTrabajador").value = "";

    document.getElementById("tituloFormulario").innerText =
        "Registrar Trabajador";

}



// ======================================
// BUSCADOR
// ======================================

buscarTrabajador.addEventListener(
    "keyup",
    function(){

        const texto =
            buscarTrabajador.value.toLowerCase();

        const filas =
            document.querySelectorAll(
                "#tablaTrabajadores tr"
            );


        filas.forEach(fila => {

            const contenido =
                fila.textContent.toLowerCase();

            fila.style.display =
                contenido.includes(texto)
                ? ""
                : "none";

        });

    }
);



// ======================================
// CERRAR SESION
// ======================================

function cerrarSesion(){

    localStorage.clear();

    window.location.href =
        "index.html";

}



// ======================================
// INICIAR
// ======================================

cargarTrabajadores();