// =====================================================
// API
// =====================================================

const API_URL =
    "http://127.0.0.1:8000";


// =====================================================
// FORM LOGIN
// =====================================================

const loginForm =
    document.getElementById("loginForm");


// =====================================================
// LOGIN
// =====================================================

loginForm.addEventListener(

    "submit",

    async function(e){

        e.preventDefault();


        // =============================================
        // INPUTS
        // =============================================

        const usuario =

            document.getElementById(
                "usuario"
            ).value;


        const contrasena =

            document.getElementById(
                "password"
            ).value;


        // =============================================
        // VALIDACION
        // =============================================

        if(
            usuario === "" ||
            contrasena === ""
        ){

            alert(
                "Completa todos los campos"
            );

            return;

        }


        try{


            // =========================================
            // FETCH LOGIN
            // =========================================

            const response = await fetch(

                `${API_URL}/login`,

                {

                    method: "POST",

                    headers: {

                        "Content-Type":
                            "application/json"

                    },

                    body: JSON.stringify({

                        usuario,
                        contrasena

                    })

                }

            );


            const data =
                await response.json();



            // =========================================
            // LOGIN CORRECTO
            // =========================================

            if(data.success){


                // =====================================
                // GUARDAR SESION
                // =====================================

                localStorage.setItem(

                    "usuario",

                    data.empleado.usuario

                );


                localStorage.setItem(

                    "nombre",

                    data.empleado.nombre

                );


                localStorage.setItem(

                    "rol",

                    data.empleado.rol

                );



                // =====================================
                // REDIRECCIONAR
                // =====================================

                window.location.href =
                    "modulos.html";

            }


            // =========================================
            // LOGIN INCORRECTO
            // =========================================

            else{

                alert(
                    data.mensaje
                );

            }

        }

        catch(error){

            console.error(error);

            alert(
                "Error al conectar con el servidor"
            );

        }

    }

);



// =====================================================
// MOSTRAR / OCULTAR PASSWORD
// =====================================================

const togglePassword =
    document.getElementById(
        "togglePassword"
    );

const passwordInput =
    document.getElementById(
        "password"
    );


togglePassword.addEventListener(

    "click",

    function(){

        const type =

            passwordInput.getAttribute(
                "type"
            ) === "password"

            ?

            "text"

            :

            "password";


        passwordInput.setAttribute(
            "type",
            type
        );


        // ICONO
        if(type === "text"){

            togglePassword.classList.remove(
                "fa-eye"
            );

            togglePassword.classList.add(
                "fa-eye-slash"
            );

        }

        else{

            togglePassword.classList.remove(
                "fa-eye-slash"
            );

            togglePassword.classList.add(
                "fa-eye"
            );

        }

    }

);
