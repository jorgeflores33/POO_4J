// =====================================================
// VALIDAR SESION
// =====================================================

const usuario =
    localStorage.getItem("usuario");

const rol =
    localStorage.getItem("rol");


// =====================================================
// SI NO EXISTE SESION
// =====================================================

if(!usuario || !rol){

    window.location.href =
        "index.html";

}



// =====================================================
// VALIDAR ROL
// =====================================================

if(rol !== "admin"){

    alert(
        "Acceso denegado"
    );

    window.location.href =
        "modulos.html";

}



// =====================================================
// CERRAR SESION
// =====================================================

function cerrarSesion(){

    localStorage.clear();

    window.location.href =
        "index.html";

}