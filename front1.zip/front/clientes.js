// ======================================
// API
// ======================================

const API_URL =
    "http://127.0.0.1:8000";



// ======================================
// VALIDAR SESION
// ======================================

const usuario =
    localStorage.getItem("usuario");

const rol =
    localStorage.getItem("rol");


if(!usuario){

    window.location.href =
        "index.html";

}



// ======================================
// ELEMENTOS
// ======================================

const tablaClientes =
    document.getElementById("tablaClientes");

const formCliente =
    document.getElementById("formCliente");

const buscarCliente =
    document.getElementById("buscarCliente");



// ======================================
// CARGAR CLIENTES
// ======================================

async function cargarClientes(){

    try{

        const response = await fetch(
            `${API_URL}/clientes`
        );

        const data =
            await response.json();


        tablaClientes.innerHTML = "";


        data.forEach(cliente => {

            tablaClientes.innerHTML += `

                <tr>

                    <td>
                        ${cliente.id_cliente}
                    </td>

                    <td>
                        ${cliente.nombre}
                    </td>

                    <td>
                        ${cliente.telefono}
                    </td>

                    <td>
                        ${cliente.correo}
                    </td>

                    <td>
                        ${cliente.direccion}
                    </td>

                    <td>

                        <button
                            class="btn-accion btn-editar"
                            onclick="editarCliente(${cliente.id_cliente})">

                            <i class="fa-solid fa-pen"></i>

                        </button>


                        <button
                            class="btn-accion btn-eliminar"
                            onclick="eliminarCliente(${cliente.id_cliente})">

                            <i class="fa-solid fa-trash"></i>

                        </button>

                    </td>

                </tr>

            `;

        });

    }

    catch(error){

        console.error(error);

        alert(
            "Error al cargar clientes"
        );

    }

}



// ======================================
// GUARDAR CLIENTE
// ======================================

formCliente.addEventListener(
    "submit",
    async function(e){

        e.preventDefault();


        const id =
            document.getElementById("idCliente").value;


        const cliente = {

            nombre:
                document.getElementById("nombre").value,

            telefono:
                document.getElementById("telefono").value,

            correo:
                document.getElementById("correo").value,

            direccion:
                document.getElementById("direccion").value

        };


        try{

            // ======================================
            // EDITAR
            // ======================================

            if(id){

                await fetch(

                    `${API_URL}/clientes/${id}`,

                    {

                        method: "PUT",

                        headers: {

                            "Content-Type":
                                "application/json"

                        },

                        body: JSON.stringify(cliente)

                    }

                );

            }


            // ======================================
            // CREAR
            // ======================================

            else{

                await fetch(

                    `${API_URL}/clientes`,

                    {

                        method: "POST",

                        headers: {

                            "Content-Type":
                                "application/json"

                        },

                        body: JSON.stringify(cliente)

                    }

                );

            }


            limpiarFormulario();

            cargarClientes();

        }

        catch(error){

            console.error(error);

            alert(
                "Error al guardar cliente"
            );

        }

    }
);



// ======================================
// EDITAR CLIENTE
// ======================================

async function editarCliente(id){

    try{

        const response = await fetch(
            `${API_URL}/clientes`
        );

        const data =
            await response.json();


        const cliente =
            data.find(c =>
                c.id_cliente === id
            );


        document.getElementById("idCliente").value =
            cliente.id_cliente;

        document.getElementById("nombre").value =
            cliente.nombre;

        document.getElementById("telefono").value =
            cliente.telefono;

        document.getElementById("correo").value =
            cliente.correo;

        document.getElementById("direccion").value =
            cliente.direccion;


        document.getElementById("tituloFormulario").innerText =
            "Editar Cliente";

    }

    catch(error){

        console.error(error);

    }

}



// ======================================
// ELIMINAR CLIENTE
// ======================================

async function eliminarCliente(id){

    const confirmar =
        confirm(
            "¿Eliminar cliente?"
        );


    if(!confirmar){

        return;

    }


    try{

        await fetch(

            `${API_URL}/clientes/${id}`,

            {

                method: "DELETE"

            }

        );


        cargarClientes();

    }

    catch(error){

        console.error(error);

        alert(
            "Error al eliminar cliente"
        );

    }

}



// ======================================
// LIMPIAR FORM
// ======================================

function limpiarFormulario(){

    formCliente.reset();

    document.getElementById("idCliente").value = "";

    document.getElementById("tituloFormulario").innerText =
        "Registrar Cliente";

}



// ======================================
// BUSCAR CLIENTE
// ======================================

buscarCliente.addEventListener(
    "keyup",
    function(){

        const texto =
            buscarCliente.value.toLowerCase();

        const filas =
            document.querySelectorAll(
                "#tablaClientes tr"
            );


        filas.forEach(fila => {

            const contenido =
                fila.textContent.toLowerCase();

            fila.style.display =
                contenido.includes(texto)
                ? ""
                : "none";

        });

    }
);



// ======================================
// CERRAR SESION
// ======================================

function cerrarSesion(){

    localStorage.clear();

    window.location.href =
        "index.html";

}



// ======================================
// INICIAR
// ======================================

cargarClientes();