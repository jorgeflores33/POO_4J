from pydantic import BaseModel
from typing import Optional
from datetime import date


# ======================================================
# CLIENTES
# ======================================================

class Cliente(BaseModel):

    nombre: str
    telefono: Optional[str] = None
    correo: Optional[str] = None
    direccion: Optional[str] = None


# ======================================================
# EMPLEADOS
# ======================================================

class Empleado(BaseModel):

    nombre: Optional[str] = None
    puesto: Optional[str] = None
    telefono: Optional[str] = None
    salario: Optional[float] = None

    usuario: str
    contrasena: str
    rol: Optional[str] = None


# ======================================================
# AUTOS
# ======================================================

class Auto(BaseModel):

    marca: str
    modelo: str
    anio: int
    color: str
    precio: float
    stock: int


# ======================================================
# VENTAS
# ======================================================

class Venta(BaseModel):

    id_cliente: int
    id_empleado: int
    id_auto: int
    fecha: date
    total: float


# ======================================================
# PROVEEDORES
# ======================================================

class Proveedor(BaseModel):

    nombre_empresa: str
    telefono: Optional[str] = None
    correo: Optional[str] = None
    direccion: Optional[str] = None


# ======================================================
# MANTENIMIENTO
# ======================================================

class Mantenimiento(BaseModel):

    id_auto: int
    descripcion: str
    fecha: date
    costo: float