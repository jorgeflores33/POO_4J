from app.db.database import conexion

# ======================================================
# CLIENTES
# ======================================================

def get_clientes():

    cursor = conexion.cursor(dictionary=True)

    cursor.execute("SELECT * FROM clientes")

    return cursor.fetchall()


def post_cliente(data):

    cursor = conexion.cursor()

    sql = """
    INSERT INTO clientes(nombre, telefono, correo, direccion)
    VALUES(%s,%s,%s,%s)
    """

    valores = (
        data.nombre,
        data.telefono,
        data.correo,
        data.direccion
    )

    cursor.execute(sql, valores)

    conexion.commit()

    return {"mensaje": "Cliente agregado"}


def put_cliente(id, data):

    cursor = conexion.cursor()

    sql = """
    UPDATE clientes
    SET nombre=%s,
        telefono=%s,
        correo=%s,
        direccion=%s
    WHERE id_cliente=%s
    """

    valores = (
        data.nombre,
        data.telefono,
        data.correo,
        data.direccion,
        id
    )

    cursor.execute(sql, valores)

    conexion.commit()

    return {"mensaje": "Cliente actualizado"}


def delete_cliente(id):

    cursor = conexion.cursor()

    cursor.execute(
        "DELETE FROM clientes WHERE id_cliente=%s",
        (id,)
    )

    conexion.commit()

    return {"mensaje": "Cliente eliminado"}


# ======================================================
# EMPLEADOS
# ======================================================

def get_empleados():

    cursor = conexion.cursor(dictionary=True)

    cursor.execute("SELECT * FROM empleados")

    return cursor.fetchall()



def post_empleado(data):

    cursor = conexion.cursor()

    sql = """
    INSERT INTO empleados(

        nombre,
        puesto,
        telefono,
        salario,
        usuario,
        contrasena,
        rol

    )
    VALUES(%s,%s,%s,%s,%s,%s,%s)
    """

    valores = (

        data.nombre,
        data.puesto,
        data.telefono,
        data.salario,
        data.usuario,
        data.contrasena,
        data.rol

    )

    cursor.execute(sql, valores)

    conexion.commit()

    return {
        "mensaje": "Empleado agregado"
    }



def put_empleado(id, data):

    cursor = conexion.cursor()

    sql = """
    UPDATE empleados
    SET

        nombre=%s,
        puesto=%s,
        telefono=%s,
        salario=%s,
        usuario=%s,
        contrasena=%s,
        rol=%s

    WHERE id_empleado=%s
    """

    valores = (

        data.nombre,
        data.puesto,
        data.telefono,
        data.salario,
        data.usuario,
        data.contrasena,
        data.rol,
        id

    )

    cursor.execute(sql, valores)

    conexion.commit()

    return {
        "mensaje": "Empleado actualizado"
    }



def delete_empleado(id):

    cursor = conexion.cursor()

    cursor.execute(
        "DELETE FROM empleados WHERE id_empleado=%s",
        (id,)
    )

    conexion.commit()

    return {
        "mensaje": "Empleado eliminado"
    }

# ======================================================
# LOGIN
# ======================================================

def login_usuario(usuario, contrasena):

    cursor = conexion.cursor(dictionary=True)

    sql = """
    SELECT *
    FROM empleados
    WHERE usuario=%s
    AND contrasena=%s
    """

    valores = (
        usuario,
        contrasena
    )

    cursor.execute(sql, valores)

    empleado = cursor.fetchone()

    return empleado

# ======================================================
# AUTOS
# ======================================================

def get_autos():

    cursor = conexion.cursor(dictionary=True)

    cursor.execute("SELECT * FROM autos")

    return cursor.fetchall()


def post_auto(data):

    cursor = conexion.cursor()

    sql = """
    INSERT INTO autos(marca, modelo, anio, color, precio, stock)
    VALUES(%s,%s,%s,%s,%s,%s)
    """

    valores = (
        data.marca,
        data.modelo,
        data.anio,
        data.color,
        data.precio,
        data.stock
    )

    cursor.execute(sql, valores)

    conexion.commit()

    return {"mensaje": "Auto agregado"}


def put_auto(id, data):

    cursor = conexion.cursor()

    sql = """
    UPDATE autos
    SET marca=%s,
        modelo=%s,
        anio=%s,
        color=%s,
        precio=%s,
        stock=%s
    WHERE id_auto=%s
    """

    valores = (
        data.marca,
        data.modelo,
        data.anio,
        data.color,
        data.precio,
        data.stock,
        id
    )

    cursor.execute(sql, valores)

    conexion.commit()

    return {"mensaje": "Auto actualizado"}


def delete_auto(id):

    cursor = conexion.cursor()

    cursor.execute(
        "DELETE FROM autos WHERE id_auto=%s",
        (id,)
    )

    conexion.commit()

    return {"mensaje": "Auto eliminado"}


# ======================================================
# VENTAS
# ======================================================

def get_ventas():

    cursor = conexion.cursor(dictionary=True)

    cursor.execute("SELECT * FROM ventas")

    return cursor.fetchall()


def post_venta(data):

    cursor = conexion.cursor()

    sql = """
    INSERT INTO ventas(id_cliente, id_empleado, id_auto, fecha, total)
    VALUES(%s,%s,%s,%s,%s)
    """

    valores = (
        data.id_cliente,
        data.id_empleado,
        data.id_auto,
        data.fecha,
        data.total
    )

    cursor.execute(sql, valores)

    conexion.commit()

    return {"mensaje": "Venta agregada"}


def put_venta(id, data):

    cursor = conexion.cursor()

    sql = """
    UPDATE ventas
    SET id_cliente=%s,
        id_empleado=%s,
        id_auto=%s,
        fecha=%s,
        total=%s
    WHERE id_venta=%s
    """

    valores = (
        data.id_cliente,
        data.id_empleado,
        data.id_auto,
        data.fecha,
        data.total,
        id
    )

    cursor.execute(sql, valores)

    conexion.commit()

    return {"mensaje": "Venta actualizada"}


def delete_venta(id):

    cursor = conexion.cursor()

    cursor.execute(
        "DELETE FROM ventas WHERE id_venta=%s",
        (id,)
    )

    conexion.commit()

    return {"mensaje": "Venta eliminada"}


# ======================================================
# PROVEEDORES
# ======================================================

def get_proveedores():

    cursor = conexion.cursor(dictionary=True)

    cursor.execute("SELECT * FROM proveedores")

    return cursor.fetchall()


def post_proveedor(data):

    cursor = conexion.cursor()

    sql = """
    INSERT INTO proveedores(nombre_empresa, telefono, correo, direccion)
    VALUES(%s,%s,%s,%s)
    """

    valores = (
        data.nombre_empresa,
        data.telefono,
        data.correo,
        data.direccion
    )

    cursor.execute(sql, valores)

    conexion.commit()

    return {"mensaje": "Proveedor agregado"}


def put_proveedor(id, data):

    cursor = conexion.cursor()

    sql = """
    UPDATE proveedores
    SET nombre_empresa=%s,
        telefono=%s,
        correo=%s,
        direccion=%s
    WHERE id_proveedor=%s
    """

    valores = (
        data.nombre_empresa,
        data.telefono,
        data.correo,
        data.direccion,
        id
    )

    cursor.execute(sql, valores)

    conexion.commit()

    return {"mensaje": "Proveedor actualizado"}


def delete_proveedor(id):

    cursor = conexion.cursor()

    cursor.execute(
        "DELETE FROM proveedores WHERE id_proveedor=%s",
        (id,)
    )

    conexion.commit()

    return {"mensaje": "Proveedor eliminado"}


# ======================================================
# MANTENIMIENTO
# ======================================================

def get_mantenimiento():

    cursor = conexion.cursor(dictionary=True)

    cursor.execute("SELECT * FROM mantenimiento")

    return cursor.fetchall()


def post_mantenimiento(data):

    cursor = conexion.cursor()

    sql = """
    INSERT INTO mantenimiento(id_auto, descripcion, fecha, costo)
    VALUES(%s,%s,%s,%s)
    """

    valores = (
        data.id_auto,
        data.descripcion,
        data.fecha,
        data.costo
    )

    cursor.execute(sql, valores)

    conexion.commit()

    return {"mensaje": "Mantenimiento agregado"}


def put_mantenimiento(id, data):

    cursor = conexion.cursor()

    sql = """
    UPDATE mantenimiento
    SET id_auto=%s,
        descripcion=%s,
        fecha=%s,
        costo=%s
    WHERE id_mantenimiento=%s
    """

    valores = (
        data.id_auto,
        data.descripcion,
        data.fecha,
        data.costo,
        id
    )

    cursor.execute(sql, valores)

    conexion.commit()

    return {"mensaje": "Mantenimiento actualizado"}


def delete_mantenimiento(id):

    cursor = conexion.cursor()

    cursor.execute(
        "DELETE FROM mantenimiento WHERE id_mantenimiento=%s",
        (id,)
    )

    conexion.commit()

    return {"mensaje": "Mantenimiento eliminado"}