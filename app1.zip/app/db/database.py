import mysql.connector


conexion = mysql.connector.connect(

    user='admin',
    password='1234',
    host='localhost',
    database='concesionaria'

)