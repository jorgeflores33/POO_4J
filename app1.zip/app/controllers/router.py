from fastapi import APIRouter
from app.controllers.controller import *
from app.schema.schema import *

router = APIRouter()


# ======================================================
# CLIENTES
# ======================================================

@router.get("/clientes")
def get_clientes_route():

    return obtener_clientes()


@router.post("/clientes")
def post_cliente_route(data: Cliente):

    return crear_cliente(data)


@router.put("/clientes/{id}")
def put_cliente_route(id: int, data: Cliente):

    return actualizar_cliente(id, data)


@router.delete("/clientes/{id}")
def delete_cliente_route(id: int):

    return eliminar_cliente(id)


# ======================================================
# EMPLEADOS
# ======================================================

@router.get("/empleados")
def get_empleados_route():

    return obtener_empleados()


@router.post("/empleados")
def post_empleado_route(data: Empleado):

    return crear_empleado(data)


@router.put("/empleados/{id}")
def put_empleado_route(id: int, data: Empleado):

    return actualizar_empleado(id, data)


@router.delete("/empleados/{id}")
def delete_empleado_route(id: int):

    return eliminar_empleado(id)

# ======================================================
# LOGIN
# ======================================================

@router.post("/login")
def login_route(data: Empleado):

    return iniciar_sesion(
        data.usuario,
        data.contrasena
    )

# ======================================================
# AUTOS
# ======================================================

@router.get("/autos")
def get_autos_route():

    return obtener_autos()


@router.post("/autos")
def post_auto_route(data: Auto):

    return crear_auto(data)


@router.put("/autos/{id}")
def put_auto_route(id: int, data: Auto):

    return actualizar_auto(id, data)


@router.delete("/autos/{id}")
def delete_auto_route(id: int):

    return eliminar_auto(id)


# ======================================================
# VENTAS
# ======================================================

@router.get("/ventas")
def get_ventas_route():

    return obtener_ventas()


@router.post("/ventas")
def post_venta_route(data: Venta):

    return crear_venta(data)


@router.put("/ventas/{id}")
def put_venta_route(id: int, data: Venta):

    return actualizar_venta(id, data)


@router.delete("/ventas/{id}")
def delete_venta_route(id: int):

    return eliminar_venta(id)


# ======================================================
# PROVEEDORES
# ======================================================

@router.get("/proveedores")
def get_proveedores_route():

    return obtener_proveedores()


@router.post("/proveedores")
def post_proveedor_route(data: Proveedor):

    return crear_proveedor(data)


@router.put("/proveedores/{id}")
def put_proveedor_route(id: int, data: Proveedor):

    return actualizar_proveedor(id, data)


@router.delete("/proveedores/{id}")
def delete_proveedor_route(id: int):

    return eliminar_proveedor(id)


# ======================================================
# MANTENIMIENTO
# ======================================================

@router.get("/mantenimiento")
def get_mantenimiento_route():

    return obtener_mantenimiento()


@router.post("/mantenimiento")
def post_mantenimiento_route(data: Mantenimiento):

    return crear_mantenimiento(data)


@router.put("/mantenimiento/{id}")
def put_mantenimiento_route(id: int, data: Mantenimiento):

    return actualizar_mantenimiento(id, data)


@router.delete("/mantenimiento/{id}")
def delete_mantenimiento_route(id: int):

    return eliminar_mantenimiento(id)