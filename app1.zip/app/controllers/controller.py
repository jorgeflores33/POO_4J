from app.models.queries import *


# ======================================================
# CLIENTES
# ======================================================

def obtener_clientes():

    return get_clientes()


def crear_cliente(data):

    return post_cliente(data)


def actualizar_cliente(id, data):

    return put_cliente(id, data)


def eliminar_cliente(id):

    return delete_cliente(id)


# ======================================================
# EMPLEADOS
# ======================================================

def obtener_empleados():

    return get_empleados()


def crear_empleado(data):

    return post_empleado(data)


def actualizar_empleado(id, data):

    return put_empleado(id, data)


def eliminar_empleado(id):

    return delete_empleado(id)

# ======================================================
# LOGIN
# ======================================================

def iniciar_sesion(usuario, contrasena):

    empleado = login_usuario(
        usuario,
        contrasena
    )

    if empleado:

        return {

            "success": True,

            "mensaje": "Login correcto",

            "empleado": {

                "nombre": empleado["nombre"],

                "usuario": empleado["usuario"],

                "rol": empleado["rol"]

            }

        }

    else:

        return {

            "success": False,

            "mensaje": "Usuario o contraseña incorrectos"

        }
        
# ======================================================
# AUTOS
# ======================================================

def obtener_autos():

    return get_autos()


def crear_auto(data):

    return post_auto(data)


def actualizar_auto(id, data):

    return put_auto(id, data)


def eliminar_auto(id):

    return delete_auto(id)


# ======================================================
# VENTAS
# ======================================================

def obtener_ventas():

    return get_ventas()


def crear_venta(data):

    return post_venta(data)


def actualizar_venta(id, data):

    return put_venta(id, data)


def eliminar_venta(id):

    return delete_venta(id)


# ======================================================
# PROVEEDORES
# ======================================================

def obtener_proveedores():

    return get_proveedores()


def crear_proveedor(data):

    return post_proveedor(data)


def actualizar_proveedor(id, data):

    return put_proveedor(id, data)


def eliminar_proveedor(id):

    return delete_proveedor(id)


# ======================================================
# MANTENIMIENTO
# ======================================================

def obtener_mantenimiento():

    return get_mantenimiento()


def crear_mantenimiento(data):

    return post_mantenimiento(data)


def actualizar_mantenimiento(id, data):

    return put_mantenimiento(id, data)


def eliminar_mantenimiento(id):

    return delete_mantenimiento(id)