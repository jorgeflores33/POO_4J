const API = "http://127.0.0.1:8000/api/trabajadores"

const tabla = document.getElementById(
    "tablaTrabajadores"
)

/* OBTENER TRABAJADORES */

async function obtenerTrabajadores(){

    const response = await fetch(API)

    const data = await response.json()

    tabla.innerHTML = ""

    data.forEach(trabajador => {

        tabla.innerHTML += `

        <tr>

            <td>${trabajador.id}</td>

            <td>${trabajador.nombre}</td>

            <td>${trabajador.telefono}</td>

            <td>${trabajador.area}</td>

            <td>

                <span class="estado">

                    Activo

                </span>

            </td>

            <td>

                <div class="actions">

                    <button class="btn-edit">

                        <i class="fa-solid fa-pen"></i>

                    </button>

                    <button
                        class="btn-delete"
                        onclick="eliminarTrabajador(${trabajador.id})"
                    >

                        <i class="fa-solid fa-trash"></i>

                    </button>

                </div>

            </td>

        </tr>

        `

    })

}

/* MODAL */

function abrirModal(){

    document.getElementById("modal")
    .style.display = "flex"

}

function cerrarModal(){

    document.getElementById("modal")
    .style.display = "none"

}

/* GUARDAR */

document
.getElementById("formTrabajador")
.addEventListener("submit", async function(e){

    e.preventDefault()

    const trabajador = {

        nombre:
        document.getElementById("nombre").value,

        telefono:
        document.getElementById("telefono").value,

        area:
        document.getElementById("area").value,

        activo: true

    }

    await fetch(API,{

        method:"POST",

        headers:{

            "Content-Type":"application/json"

        },

        body: JSON.stringify(trabajador)

    })

    cerrarModal()

    obtenerTrabajadores()

})

/* ELIMINAR */

async function eliminarTrabajador(id){

    if(confirm("¿Eliminar trabajador?")){

        await fetch(`${API}/${id}`,{

            method:"DELETE"

        })

        obtenerTrabajadores()

    }

}

/* CERRAR SESION */

function cerrarSesion(){

    localStorage.removeItem("usuario")

    window.location.href =
    "inicio.html"

}

/* INIT */

obtenerTrabajadores()