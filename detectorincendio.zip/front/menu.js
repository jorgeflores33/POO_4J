const API = "http://127.0.0.1:8000/api"

/* IR LOGIN */

function irInicio(){

    window.location.href = "inicio.html"

}

/* FECHA */

function actualizarHora(){

    const fecha = new Date()

    document.getElementById("fechaHora").innerHTML =

        fecha.toLocaleDateString() + " " +

        fecha.toLocaleTimeString()

}

setInterval(actualizarHora,1000)

actualizarHora()

/* DATOS TIEMPO REAL */

async function obtenerDatos(){

    try{

        // =========================
        // LECTURAS
        // =========================

        const response = await fetch(

            `${API}/lecturas`

        )

        const lecturas = await response.json()

        console.log(lecturas)

        if(lecturas.length > 0){

            const ultima =
                lecturas[lecturas.length - 1]

            document.getElementById("humo")
            .innerHTML = ultima.humo

            document.getElementById("fuego")
            .innerHTML = ultima.fuego

            document.getElementById("temperatura")
            .innerHTML = ultima.temperatura

            // =====================
            // ALERTA
            // =====================

            if(

                ultima.humo > 2000 ||

                ultima.fuego < 1500 ||

                ultima.temperatura > 35

            ){

                document.getElementById(
                    "estadoSistema"
                ).innerHTML = "PELIGRO"

                document.getElementById(
                    "mensajeSistema"
                ).innerHTML = "NO ENTRAR"

                document.getElementById(
                    "panelAlerta"
                ).style.display = "flex"

                document.getElementById(
                    "dangerBox"
                ).style.display = "flex"

            }else{

                document.getElementById(
                    "estadoSistema"
                ).innerHTML = "NORMAL"

                document.getElementById(
                    "mensajeSistema"
                ).innerHTML =
                "Sistema funcionando correctamente"

                document.getElementById(
                    "panelAlerta"
                ).style.display = "none"

                document.getElementById(
                    "dangerBox"
                ).style.display = "none"

            }

        }

    }catch(error){

        console.log(
            "ERROR:",
            error
        )

    }

}

/* ACTUALIZAR */

setInterval(obtenerDatos,2000)

obtenerDatos()