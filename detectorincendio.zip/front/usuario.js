const API = "http://127.0.0.1:8000/api/usuarios"

const tabla = document.getElementById(
    "tablaUsuarios"
)

/* OBTENER USUARIOS */

async function obtenerUsuarios(){

    const response = await fetch(API)

    const data = await response.json()

    tabla.innerHTML = ""

    data.forEach(usuario => {

        tabla.innerHTML += `

        <tr>

            <td>${usuario.id}</td>

            <td>${usuario.nombre}</td>

            <td>${usuario.correo}</td>

            <td>

                <span class="${
                    usuario.rol === "ADMIN"
                    ? "rol-admin"
                    : "rol-user"
                }">

                    ${usuario.rol}

                </span>

            </td>

            <td>

                <div class="actions">

                    <button class="btn-edit">

                        <i class="fa-solid fa-pen"></i>

                    </button>

                    <button
                        class="btn-delete"
                        onclick="eliminarUsuario(${usuario.id})"
                    >

                        <i class="fa-solid fa-trash"></i>

                    </button>

                </div>

            </td>

        </tr>

        `

    })

}

/* MODAL */

function abrirModal(){

    document.getElementById("modal")
    .style.display = "flex"

}

function cerrarModal(){

    document.getElementById("modal")
    .style.display = "none"

}

/* GUARDAR */

document
.getElementById("formUsuario")
.addEventListener("submit", async function(e){

    e.preventDefault()

    const usuario = {

        nombre:
        document.getElementById("nombre").value,

        correo:
        document.getElementById("correo").value,

        password:
        document.getElementById("password").value,

        rol:
        document.getElementById("rol").value

    }

    await fetch(API,{

        method:"POST",

        headers:{

            "Content-Type":"application/json"

        },

        body: JSON.stringify(usuario)

    })

    cerrarModal()

    obtenerUsuarios()

})

/* ELIMINAR */

async function eliminarUsuario(id){

    if(confirm("¿Eliminar usuario?")){

        await fetch(`${API}/${id}`,{

            method:"DELETE"

        })

        obtenerUsuarios()

    }

}

/* CERRAR SESION */

function cerrarSesion(){

    localStorage.removeItem("usuario")

    window.location.href =
    "inicio.html"

}

/* INIT */

obtenerUsuarios()