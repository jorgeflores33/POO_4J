function mostrarPassword(){

    const input = document.getElementById("password")

    if(input.type === "password"){

        input.type = "text"

    }else{

        input.type = "password"

    }

}

/* LOGIN */

document
.getElementById("loginForm")
.addEventListener("submit", async function(e){

    e.preventDefault()

    const correo = document.getElementById("correo").value

    const password = document.getElementById("password").value

    try{

        const response = await fetch(

            "http://127.0.0.1:8000/api/usuarios"

        )

        const usuarios = await response.json()

        const usuario = usuarios.find(

            u =>
            u.correo === correo &&
            u.password === password

        )

        if(usuario){

            localStorage.setItem(

                "usuario",
                JSON.stringify(usuario)

            )

            window.location.href = "secion.html"

        }else{

            document
            .getElementById("error")
            .style.display = "block"

        }

    }catch(error){

        console.log(error)

        alert("Error conectando con la API")

    }

})