const usuario = JSON.parse(

    localStorage.getItem("usuario")

)

/* NOMBRE USUARIO */

if(usuario){

    document.getElementById("nombreUsuario")
    .innerHTML = usuario.nombre

}

/* IR TRABAJADORES */

function irTrabajadores(){

    window.location.href =
    "trabajadores.html"

}

/* IR USUARIOS */

function irUsuarios(){

    window.location.href =
    "usuario.html"

}

/* CERRAR SESION */

function cerrarSesion(){

    localStorage.removeItem("usuario")

    window.location.href =
    "inicio.html"

}