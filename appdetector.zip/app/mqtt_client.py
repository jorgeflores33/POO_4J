import json
import paho.mqtt.client as mqtt
from app.twilio_client import enviar_whatsapp
from app.db.database import connection

from app.models.queries import (

    create_lectura_query,
    create_alerta_query

)

# =====================================================
# CONFIG MQTT
# =====================================================

BROKER = "127.0.0.1"

PORT = 1883

TOPIC = "detector/incendio"

# =====================================================
# MQTT CONNECT
# =====================================================

def on_connect(client, userdata, flags, rc):

    try:

        if rc == 0:

            print("✅ MQTT conectado correctamente")

            client.subscribe(TOPIC)

            print(f"📡 Escuchando topic: {TOPIC}")

        else:

            print("❌ Error conexión MQTT")
            print("Código:", rc)

    except Exception as e:

        print("❌ Error on_connect")
        print(e)

# =====================================================
# MQTT MESSAGE
# =====================================================

def on_message(client, userdata, msg):

    try:

        # =================================================
        # DECODIFICAR JSON
        # =================================================

        payload = msg.payload.decode("utf-8")

        print("📩 Mensaje recibido MQTT")
        print(payload)

        data = json.loads(payload)

        # =================================================
        # DATOS ESP32
        # =================================================

        dispositivo_id = data.get("dispositivo_id", 1)

        humo = data.get("humo", 0)

        fuego = data.get("fuego", 0)

        temperatura = data.get("temperatura", 0)

        tipo = data.get("tipo", "NORMAL")

        # =================================================
        # GUARDAR LECTURA
        # =================================================

        lectura = {

            "dispositivo_id": dispositivo_id,

            "humo": humo,

            "fuego": fuego,

            "temperatura": temperatura

        }

        create_lectura_query(lectura)

        print("✅ Lectura guardada")

        # =================================================
        # ALERTAS
        # =================================================

        if tipo != "NORMAL":

            alerta = {

                "dispositivo_id": dispositivo_id,

                "tipo": tipo,

                "mensaje": f"🚨 ALERTA {tipo} DETECTADA",

                "nivel": "ALTO"

            }

            create_alerta_query(alerta)

            print("🚨 ALERTA GUARDADA")

            # =========================================
            # ENVIAR WHATSAPP A TRABAJADORES
            # =========================================

            try:

                cursor = connection.cursor(dictionary=True)

                sql = """
                SELECT telefono
                FROM trabajadores
                WHERE activo = TRUE
                """

                cursor.execute(sql)

                trabajadores = cursor.fetchall()

                for trabajador in trabajadores:

                    numero = trabajador["telefono"]

                    # =============================
                    # AGREGAR +52 SI NO EXISTE
                    # =============================

                    if not numero.startswith("+52"):

                        numero = "+52" + numero

                    enviar_whatsapp(numero)

                    print(f"📲 WhatsApp enviado a {numero}")

            except Exception as e:

                print("❌ Error enviando WhatsApp")

                print(e)

        else:

            print("✅ Sistema normal")

    except json.JSONDecodeError:

        print("❌ JSON inválido")

    except Exception as e:

        print("❌ Error MQTT")
        print(e)

# =====================================================
# CLIENTE MQTT
# =====================================================

client = mqtt.Client()

client.on_connect = on_connect

client.on_message = on_message

# =====================================================
# CONECTAR MQTT
# =====================================================

try:

    print("📡 Conectando broker MQTT...")

    client.connect(

        BROKER,
        PORT,
        60

    )

    print("✅ Broker MQTT conectado")

except Exception as e:

    print("❌ Error conectando MQTT")
    print(e)