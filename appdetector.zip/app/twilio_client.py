from twilio.rest import Client

# =========================================
# TWILIO
# =========================================

ACCOUNT_SID = "ACafc8039d91c36e287084736fad5d3709"

AUTH_TOKEN = "243c538f7d87460bd3f7db7eeddad48a"

TWILIO_NUMBER = "whatsapp:+14155238886"

# =====================================
# CLIENTE
# =====================================

client = Client(

    ACCOUNT_SID,

    AUTH_TOKEN

)

# =====================================
# ENVIAR WHATSAPP
# =====================================

def enviar_whatsapp(numero):

    try:

        mensaje = """
🚨 ALERTA DE INCENDIO O HUMO 🚨

POR FAVOR EVACUA EL LUGAR.

⚠️ Riesgo detectado por el sistema.

Si deseas ver la actividad del incendio entra a:

LINK_AQUI
"""

        message = client.messages.create(

            from_=TWILIO_NUMBER,

            body=mensaje,

            to=f"whatsapp:{numero}"

        )

        print("✅ WhatsApp enviado")
        print(message.sid)

    except Exception as e:

        print("❌ Error enviando WhatsApp")
        print(e)