from app.services.sucursales_service import (
    get_sucursales,
    get_sucursal_by_id,
    create_sucursal,
    update_sucursal,
    delete_sucursal
)

# ============================
# GET
# ============================

def obtener_sucursales(db):
    return get_sucursales(db)


def obtener_sucursal(db, id_sucursal):
    return get_sucursal_by_id(db, id_sucursal)


# ============================
# POST
# ============================

def crear_sucursal(db, data):
    return create_sucursal(db, data)


# ============================
# PUT
# ============================

def actualizar_sucursal(db, id_sucursal, data):
    return update_sucursal(db, id_sucursal, data)


# ============================
# DELETE
# ============================

def eliminar_sucursal(db, id_sucursal):
    return delete_sucursal(db, id_sucursal)