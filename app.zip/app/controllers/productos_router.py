from fastapi import APIRouter

from app.schemas.productos_schema import (
    ProductoCreate,
    ProductoUpdate
)

from app.db.database import get_connection

from app.controllers.productos_controller import (
    obtener_productos,
    obtener_producto,
    crear_producto,
    actualizar_producto,
    eliminar_producto
)

router = APIRouter(
    prefix="/productos",
    tags=["Productos"]
)

# ============================
# GET ALL
# ============================

@router.get("/")
def get_all():
    db = get_connection()

    return obtener_productos(db)


# ============================
# GET BY ID
# ============================

@router.get("/{id_producto}")
def get_by_id(id_producto: int):
    db = get_connection()

    return obtener_producto(
        db,
        id_producto
    )


# ============================
# POST
# ============================

@router.post("/")
def create(data: ProductoCreate):
    db = get_connection()

    return crear_producto(
        db,
        data.dict()
    )


# ============================
# PUT
# ============================

@router.put("/{id_producto}")
def update(
    id_producto: int,
    data: ProductoUpdate
):
    db = get_connection()

    return actualizar_producto(
        db,
        id_producto,
        data.dict()
    )


# ============================
# DELETE
# ============================

@router.delete("/{id_producto}")
def delete(id_producto: int):
    db = get_connection()

    return eliminar_producto(
        db,
        id_producto
    )