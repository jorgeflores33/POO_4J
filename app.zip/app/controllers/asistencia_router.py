from fastapi import APIRouter

from app.schemas.asistencia_schema import (
    AsistenciaCreate,
    AsistenciaUpdate
)

from app.db.database import get_connection

from app.controllers.asistencia_controller import (
    obtener_asistencias,
    obtener_asistencia,
    crear_asistencia,
    actualizar_asistencia,
    eliminar_asistencia
)

router = APIRouter(
    prefix="/asistencia",
    tags=["Asistencia"]
)

# ============================
# GET ALL
# ============================

@router.get("/")
def get_all():
    db = get_connection()

    return obtener_asistencias(db)


# ============================
# GET BY ID
# ============================

@router.get("/{id_asistencia}")
def get_by_id(id_asistencia: int):
    db = get_connection()

    return obtener_asistencia(
        db,
        id_asistencia
    )


# ============================
# POST
# ============================

@router.post("/")
def create(data: AsistenciaCreate):
    db = get_connection()

    return crear_asistencia(
        db,
        data.dict()
    )


# ============================
# PUT
# ============================

@router.put("/{id_asistencia}")
def update(
    id_asistencia: int,
    data: AsistenciaUpdate
):
    db = get_connection()

    return actualizar_asistencia(
        db,
        id_asistencia,
        data.dict()
    )


# ============================
# DELETE
# ============================

@router.delete("/{id_asistencia}")
def delete(id_asistencia: int):
    db = get_connection()

    return eliminar_asistencia(
        db,
        id_asistencia
    )