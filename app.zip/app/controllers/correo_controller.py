from app.services.correo_service import enviar_correo

async def enviar_factura_correo(
    correo_cliente: str,
    ruta_pdf: str
):

    return await enviar_correo(
        correo_cliente,
        ruta_pdf
    )