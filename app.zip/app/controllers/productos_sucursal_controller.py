from app.services.productos_sucursal_service import (

    get_productos_sucursal,

    get_producto_sucursal,

    create_producto_sucursal,

    update_producto_sucursal,

    delete_producto_sucursal,

    validar_producto_sucursal,

    get_productos_usuario_service
)


# ============================
# GET
# ============================

def obtener_productos_sucursal(
    db
):

    return get_productos_sucursal(
        db
    )


def obtener_producto_sucursal(

    db,

    id_producto,

    id_sucursal
):

    return get_producto_sucursal(

        db,

        id_producto,

        id_sucursal
    )


# ============================
# GET PRODUCTOS USUARIO
# ============================

def obtener_productos_usuario_controller(

    db,

    usuario
):

    return get_productos_usuario_service(

        db,

        usuario
    )


# ============================
# POST
# ============================

def crear_producto_sucursal(
    db,
    data
):

    return create_producto_sucursal(
        db,
        data
    )


# ============================
# PUT
# ============================

def actualizar_producto_sucursal(

    db,

    id_producto,

    id_sucursal,

    data
):

    return update_producto_sucursal(

        db,

        id_producto,

        id_sucursal,

        data
    )


# ============================
# DELETE
# ============================

def eliminar_producto_sucursal(

    db,

    id_producto,

    id_sucursal
):

    return delete_producto_sucursal(

        db,

        id_producto,

        id_sucursal
    )


# ============================
# VALIDAR PRODUCTO SUCURSAL
# ============================

def validar_producto_usuario_controller(

    usuario,

    id_producto
):

    return validar_producto_sucursal(

        usuario,

        id_producto
    )

