from app.services.inventarios_service import (
    get_inventarios,
    get_inventario_by_id,
    create_inventario,
    update_inventario,
    delete_inventario
)

# ============================
# GET
# ============================

def obtener_inventarios(db):
    return get_inventarios(db)


def obtener_inventario(db, id_inventario):
    return get_inventario_by_id(db, id_inventario)


# ============================
# POST
# ============================

def crear_inventario(db, data):
    return create_inventario(db, data)


# ============================
# PUT
# ============================

def actualizar_inventario(db, id_inventario, data):
    return update_inventario(db, id_inventario, data)


# ============================
# DELETE
# ============================

def eliminar_inventario(db, id_inventario):
    return delete_inventario(db, id_inventario)