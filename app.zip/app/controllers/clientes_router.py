from fastapi import APIRouter

from app.schemas.clientes_schema import (
    ClienteCreate,
    ClienteUpdate
)

from app.db.database import get_connection

from app.controllers.clientes_controller import (
    obtener_clientes,
    obtener_cliente,
    crear_cliente,
    actualizar_cliente,
    eliminar_cliente
)

router = APIRouter(
    prefix="/clientes",
    tags=["Clientes"]
)

# ============================
# GET ALL
# ============================

@router.get("/")
def get_all():
    db = get_connection()

    return obtener_clientes(db)


# ============================
# GET BY ID
# ============================

@router.get("/{id_cliente}")
def get_by_id(id_cliente: int):
    db = get_connection()

    return obtener_cliente(
        db,
        id_cliente
    )


# ============================
# POST
# ============================

@router.post("/")
def create(data: ClienteCreate):
    db = get_connection()

    return crear_cliente(
        db,
        data.dict()
    )


# ============================
# PUT
# ============================

@router.put("/{id_cliente}")
def update(
    id_cliente: int,
    data: ClienteUpdate
):
    db = get_connection()

    return actualizar_cliente(
        db,
        id_cliente,
        data.dict()
    )


# ============================
# DELETE
# ============================

@router.delete("/{id_cliente}")
def delete(id_cliente: int):
    db = get_connection()

    return eliminar_cliente(
        db,
        id_cliente
    )