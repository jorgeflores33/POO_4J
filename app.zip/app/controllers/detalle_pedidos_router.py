from fastapi import APIRouter

from app.schemas.detalle_pedidos_schema import (
    DetallePedidoCreate,
    DetallePedidoUpdate
)

from app.db.database import get_connection

from app.controllers.detalle_pedidos_controller import (
    obtener_detalles_pedidos,
    obtener_detalle_pedido,
    crear_detalle_pedido,
    actualizar_detalle_pedido,
    eliminar_detalle_pedido
)

router = APIRouter(
    prefix="/detalle-pedidos",
    tags=["Detalle Pedidos"]
)

# ============================
# GET ALL
# ============================

@router.get("/")
def get_all():
    db = get_connection()

    return obtener_detalles_pedidos(db)


# ============================
# GET BY ID
# ============================

@router.get("/{id_detalle}")
def get_by_id(id_detalle: int):
    db = get_connection()

    return obtener_detalle_pedido(
        db,
        id_detalle
    )


# ============================
# POST
# ============================

@router.post("/")
def create(data: DetallePedidoCreate):
    db = get_connection()

    return crear_detalle_pedido(
        db,
        data.dict()
    )


# ============================
# PUT
# ============================

@router.put("/{id_detalle}")
def update(
    id_detalle: int,
    data: DetallePedidoUpdate
):
    db = get_connection()

    return actualizar_detalle_pedido(
        db,
        id_detalle,
        data.dict()
    )


# ============================
# DELETE
# ============================

@router.delete("/{id_detalle}")
def delete(id_detalle: int):
    db = get_connection()

    return eliminar_detalle_pedido(
        db,
        id_detalle
    )