from fastapi import APIRouter

from app.schemas.detalle_inventarios_schema import (

    DetalleInventarioCreate,

    DetalleInventarioUpdate
)

from app.db.database import get_connection

from app.controllers.detalle_inventarios_controller import (

    obtener_detalles_inventarios,

    obtener_detalle_inventario,

    obtener_detalles_por_inventario,

    crear_detalle_inventario,

    actualizar_detalle_inventario,

    eliminar_detalle_inventario
)


router = APIRouter(

    prefix="/detalle-inventarios",

    tags=["Detalle Inventarios"]
)



# ============================
# GET ALL
# ============================

@router.get("/")
def get_all():

    db = get_connection()

    return obtener_detalles_inventarios(
        db
    )



# ============================
# GET BY ID
# ============================

@router.get("/{id_detalle}")
def get_by_id(
    id_detalle: int
):

    db = get_connection()

    return obtener_detalle_inventario(

        db,

        id_detalle
    )



# ============================
# GET BY INVENTARIO
# ============================

@router.get("/inventario/{id_inventario}")
def get_by_inventario(
    id_inventario: int
):

    db = get_connection()

    return obtener_detalles_por_inventario(

        db,

        id_inventario
    )



# ============================
# POST
# ============================

@router.post("/")
def create(
    data: DetalleInventarioCreate
):

    db = get_connection()

    return crear_detalle_inventario(

        db,

        data.dict()
    )



# ============================
# PUT
# ============================

@router.put("/{id_detalle}")
def update(

    id_detalle: int,

    data: DetalleInventarioUpdate
):

    db = get_connection()

    return actualizar_detalle_inventario(

        db,

        id_detalle,

        data.dict()
    )



# ============================
# DELETE
# ============================

@router.delete("/{id_detalle}")
def delete(
    id_detalle: int
):

    db = get_connection()

    return eliminar_detalle_inventario(

        db,

        id_detalle
    )