from app.services.detalle_facturas_proveedores_service import (
    get_detalles_factura_proveedor,
    get_detalle_by_id,
    create_detalle_factura_proveedor,
    update_detalle_factura_proveedor,
    delete_detalle_factura_proveedor
)

# ============================
# GET
# ============================

def obtener_detalles_facturas_proveedores(db):
    return get_detalles_factura_proveedor(db)


def obtener_detalle_factura_proveedor(db, id_detalle):
    return get_detalle_by_id(db, id_detalle)


# ============================
# POST
# ============================

def crear_detalle_factura_proveedor(db, data):
    return create_detalle_factura_proveedor(db, data)


# ============================
# PUT
# ============================

def actualizar_detalle_factura_proveedor(db, id_detalle, data):
    return update_detalle_factura_proveedor(db, id_detalle, data)


# ============================
# DELETE
# ============================

def eliminar_detalle_factura_proveedor(db, id_detalle):
    return delete_detalle_factura_proveedor(db, id_detalle)