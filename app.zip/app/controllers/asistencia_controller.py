from app.services.asistencia_service import (
    get_asistencias,
    get_asistencia_by_id,
    create_asistencia,
    update_asistencia,
    delete_asistencia
)

# ============================
# GET
# ============================

def obtener_asistencias(db):
    return get_asistencias(db)


def obtener_asistencia(db, id_asistencia):
    return get_asistencia_by_id(db, id_asistencia)


# ============================
# POST
# ============================

def crear_asistencia(db, data):
    return create_asistencia(db, data)


# ============================
# PUT
# ============================

def actualizar_asistencia(db, id_asistencia, data):
    return update_asistencia(db, id_asistencia, data)


# ============================
# DELETE
# ============================

def eliminar_asistencia(db, id_asistencia):
    return delete_asistencia(db, id_asistencia)