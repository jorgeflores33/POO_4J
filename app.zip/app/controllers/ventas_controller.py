from app.services.ventas_service import (
    get_ventas,
    get_venta_by_id,
    create_venta,
    update_venta,
    delete_venta
)

# ============================
# GET
# ============================

def obtener_ventas(db):
    return get_ventas(db)


def obtener_venta(db, id_venta):
    return get_venta_by_id(db, id_venta)


# ============================
# POST
# ============================

def crear_venta(db, data):
    return create_venta(db, data)


# ============================
# PUT
# ============================

def actualizar_venta(db, id_venta, data):
    return update_venta(db, id_venta, data)


# ============================
# DELETE
# ============================

def eliminar_venta(db, id_venta):
    return delete_venta(db, id_venta)