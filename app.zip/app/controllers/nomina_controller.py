from app.services.nomina_service import (
    get_nominas,
    get_nomina_by_id,
    create_nomina,
    update_nomina,
    delete_nomina
)

# ============================
# GET
# ============================

def obtener_nominas(db):
    return get_nominas(db)


def obtener_nomina(db, id_nomina):
    return get_nomina_by_id(db, id_nomina)


# ============================
# POST
# ============================

def crear_nomina(db, data):
    return create_nomina(db, data)


# ============================
# PUT
# ============================

def actualizar_nomina(db, id_nomina, data):
    return update_nomina(db, id_nomina, data)


# ============================
# DELETE
# ============================

def eliminar_nomina(db, id_nomina):
    return delete_nomina(db, id_nomina)