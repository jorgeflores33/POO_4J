from fastapi import APIRouter
from pydantic import BaseModel
from fastapi import APIRouter
from pydantic import BaseModel
from typing import List

from app.schemas.facturas_clientes_schema import (
    FacturaClienteCreate,
    FacturaClienteUpdate
)

from app.db.database import get_connection

from app.controllers.facturas_clientes_controller import (
    obtener_facturas_clientes,
    obtener_factura_cliente,
    crear_factura_cliente,
    actualizar_factura_cliente,
    eliminar_factura_cliente
)

router = APIRouter(
    prefix="/facturas-clientes",
    tags=["Facturas Clientes"]
)

from app.services.factura_pdf_service import (
    generar_factura_pdf
)

from app.schemas.facturas_clientes_schema import (
    FacturaClienteCreate,
    FacturaClienteUpdate,
    FacturaPDFSchema
)

# ============================
# GET ALL
# ============================

@router.get("/")
def get_all():

    db = get_connection()

    return obtener_facturas_clientes(db)


# ============================
# GET BY ID
# ============================

@router.get("/{id_factura}")
def get_by_id(id_factura: int):

    db = get_connection()

    return obtener_factura_cliente(
        db,
        id_factura
    )


# ============================
# POST
# ============================

@router.post("/")
async def create(data: FacturaClienteCreate):

    db = get_connection()

    return await crear_factura_cliente(
        db,
        data.dict()
    )


# ============================
# PUT
# ============================

@router.put("/{id_factura}")
def update(
    id_factura: int,
    data: FacturaClienteUpdate
):

    db = get_connection()

    return actualizar_factura_cliente(
        db,
        id_factura,
        data.dict()
    )


# ============================
# DELETE
# ============================

@router.delete("/{id_factura}")
def delete(id_factura: int):

    db = get_connection()

    return eliminar_factura_cliente(
        db,
        id_factura
    )


# ==========================================
# GENERAR PDF FACTURA
# ==========================================

@router.post("/pdf")

def generar_pdf_factura(
    data: FacturaPDFSchema
):

    return generar_factura_pdf(
        data.dict()
    )