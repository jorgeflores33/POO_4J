from fastapi import APIRouter

from app.schemas.detalle_traspasos_schema import (
    DetalleTraspasoCreate,
    DetalleTraspasoUpdate
)

from app.db.database import get_connection

from app.controllers.detalle_traspasos_controller import (
    obtener_detalles_traspasos,
    obtener_detalle_traspaso,
    crear_detalle_traspaso,
    actualizar_detalle_traspaso,
    eliminar_detalle_traspaso
)

router = APIRouter(
    prefix="/detalle-traspasos",
    tags=["Detalle Traspasos"]
)

# ============================
# GET ALL
# ============================

@router.get("/")
def get_all():
    db = get_connection()

    return obtener_detalles_traspasos(db)


# ============================
# GET BY ID
# ============================

@router.get("/{id_detalle}")
def get_by_id(id_detalle: int):
    db = get_connection()

    return obtener_detalle_traspaso(
        db,
        id_detalle
    )


# ============================
# POST
# ============================

@router.post("/")
def create(data: DetalleTraspasoCreate):
    db = get_connection()

    return crear_detalle_traspaso(
        db,
        data.dict()
    )


# ============================
# PUT
# ============================

@router.put("/{id_detalle}")
def update(
    id_detalle: int,
    data: DetalleTraspasoUpdate
):
    db = get_connection()

    return actualizar_detalle_traspaso(
        db,
        id_detalle,
        data.dict()
    )


# ============================
# DELETE
# ============================

@router.delete("/{id_detalle}")
def delete(id_detalle: int):
    db = get_connection()

    return eliminar_detalle_traspaso(
        db,
        id_detalle
    )