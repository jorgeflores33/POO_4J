from fastapi import APIRouter

from app.schemas.nomina_schema import (
    NominaCreate,
    NominaUpdate
)

from app.db.database import get_connection

from app.controllers.nomina_controller import (
    obtener_nominas,
    obtener_nomina,
    crear_nomina,
    actualizar_nomina,
    eliminar_nomina
)

router = APIRouter(
    prefix="/nomina",
    tags=["Nomina"]
)

# ============================
# GET ALL
# ============================

@router.get("/")
def get_all():
    db = get_connection()

    return obtener_nominas(db)


# ============================
# GET BY ID
# ============================

@router.get("/{id_nomina}")
def get_by_id(id_nomina: int):
    db = get_connection()

    return obtener_nomina(
        db,
        id_nomina
    )


# ============================
# POST
# ============================

@router.post("/")
def create(data: NominaCreate):
    db = get_connection()

    return crear_nomina(
        db,
        data.dict()
    )


# ============================
# PUT
# ============================

@router.put("/{id_nomina}")
def update(
    id_nomina: int,
    data: NominaUpdate
):
    db = get_connection()

    return actualizar_nomina(
        db,
        id_nomina,
        data.dict()
    )


# ============================
# DELETE
# ============================

@router.delete("/{id_nomina}")
def delete(id_nomina: int):
    db = get_connection()

    return eliminar_nomina(
        db,
        id_nomina
    )