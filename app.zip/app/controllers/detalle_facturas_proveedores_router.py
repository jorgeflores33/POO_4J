from fastapi import APIRouter

from app.schemas.detalle_facturas_proveedores_schema import (
    DetalleFacturaProveedorCreate,
    DetalleFacturaProveedorUpdate
)

from app.db.database import get_connection

from app.controllers.detalle_facturas_proveedores_controller import (
    obtener_detalles_facturas_proveedores,
    obtener_detalle_factura_proveedor,
    crear_detalle_factura_proveedor,
    actualizar_detalle_factura_proveedor,
    eliminar_detalle_factura_proveedor
)

router = APIRouter(
    prefix="/detalle-facturas-proveedores",
    tags=["Detalle Facturas Proveedores"]
)

# ============================
# GET ALL
# ============================

@router.get("/")
def get_all():
    db = get_connection()

    return obtener_detalles_facturas_proveedores(db)


# ============================
# GET BY ID
# ============================

@router.get("/{id_detalle}")
def get_by_id(id_detalle: int):
    db = get_connection()

    return obtener_detalle_factura_proveedor(
        db,
        id_detalle
    )


# ============================
# POST
# ============================

@router.post("/")
def create(data: DetalleFacturaProveedorCreate):
    db = get_connection()

    return crear_detalle_factura_proveedor(
        db,
        data.dict()
    )


# ============================
# PUT
# ============================

@router.put("/{id_detalle}")
def update(
    id_detalle: int,
    data: DetalleFacturaProveedorUpdate
):
    db = get_connection()

    return actualizar_detalle_factura_proveedor(
        db,
        id_detalle,
        data.dict()
    )


# ============================
# DELETE
# ============================

@router.delete("/{id_detalle}")
def delete(id_detalle: int):
    db = get_connection()

    return eliminar_detalle_factura_proveedor(
        db,
        id_detalle
    )