from fastapi import APIRouter

from app.schemas.traspasos_schema import (
    TraspasoCreate,
    TraspasoUpdate
)

from app.db.database import get_connection

from app.controllers.traspasos_controller import (
    obtener_traspasos,
    obtener_traspaso,
    crear_traspaso,
    actualizar_traspaso,
    eliminar_traspaso
)

router = APIRouter(
    prefix="/traspasos",
    tags=["Traspasos"]
)

# ============================
# GET ALL
# ============================

@router.get("/")
def get_all():
    db = get_connection()

    return obtener_traspasos(db)


# ============================
# GET BY ID
# ============================

@router.get("/{id_traspaso}")
def get_by_id(id_traspaso: int):
    db = get_connection()

    return obtener_traspaso(
        db,
        id_traspaso
    )


# ============================
# POST
# ============================

@router.post("/")
def create(data: TraspasoCreate):
    db = get_connection()

    return crear_traspaso(
        db,
        data.dict()
    )


# ============================
# PUT
# ============================

@router.put("/{id_traspaso}")
def update(
    id_traspaso: int,
    data: TraspasoUpdate
):
    db = get_connection()

    return actualizar_traspaso(
        db,
        id_traspaso,
        data.dict()
    )


# ============================
# DELETE
# ============================

@router.delete("/{id_traspaso}")
def delete(id_traspaso: int):
    db = get_connection()

    return eliminar_traspaso(
        db,
        id_traspaso
    )