from fastapi import APIRouter

from app.schemas.categorias_schema import (
    CategoriaCreate,
    CategoriaUpdate
)

from app.db.database import get_connection

from app.controllers.categorias_controller import (
    obtener_categorias,
    obtener_categoria,
    crear_categoria,
    actualizar_categoria,
    eliminar_categoria
)

router = APIRouter(
    prefix="/categorias",
    tags=["Categorias"]
)

# ============================
# GET ALL
# ============================

@router.get("/")
def get_all():
    db = get_connection()

    return obtener_categorias(db)


# ============================
# GET BY ID
# ============================

@router.get("/{id_categoria}")
def get_by_id(id_categoria: int):
    db = get_connection()

    return obtener_categoria(
        db,
        id_categoria
    )


# ============================
# POST
# ============================

@router.post("/")
def create(data: CategoriaCreate):
    db = get_connection()

    return crear_categoria(
        db,
        data.dict()
    )


# ============================
# PUT
# ============================

@router.put("/{id_categoria}")
def update(
    id_categoria: int,
    data: CategoriaUpdate
):
    db = get_connection()

    return actualizar_categoria(
        db,
        id_categoria,
        data.dict()
    )


# ============================
# DELETE
# ============================

@router.delete("/{id_categoria}")
def delete(id_categoria: int):
    db = get_connection()

    return eliminar_categoria(
        db,
        id_categoria
    )