from fastapi import APIRouter

from app.schemas.corte_caja_schema import (
    CorteCajaCreate,
    CorteCajaUpdate
)

from app.db.database import get_connection

from app.controllers.corte_caja_controller import (
    obtener_cortes,
    obtener_corte,
    crear_corte,
    actualizar_corte,
    eliminar_corte
)

router = APIRouter(
    prefix="/corte-caja",
    tags=["Corte Caja"]
)

# ============================
# GET ALL
# ============================

@router.get("/")
def get_all():
    db = get_connection()

    return obtener_cortes(db)


# ============================
# GET BY ID
# ============================

@router.get("/{id_corte}")
def get_by_id(id_corte: int):
    db = get_connection()

    return obtener_corte(
        db,
        id_corte
    )


# ============================
# POST
# ============================

@router.post("/")
def create(data: CorteCajaCreate):
    db = get_connection()

    return crear_corte(
        db,
        data.dict()
    )


# ============================
# PUT
# ============================

@router.put("/{id_corte}")
def update(
    id_corte: int,
    data: CorteCajaUpdate
):
    db = get_connection()

    return actualizar_corte(
        db,
        id_corte,
        data.dict()
    )


# ============================
# DELETE
# ============================

@router.delete("/{id_corte}")
def delete(id_corte: int):
    db = get_connection()

    return eliminar_corte(
        db,
        id_corte
    )