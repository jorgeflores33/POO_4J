from fastapi import APIRouter
from fastapi import APIRouter
from pydantic import BaseModel

from app.schemas.usuarios_schema import (
    UsuarioCreate,
    UsuarioUpdate
)

from app.db.database import get_connection

from app.controllers.usuarios_controller import (
    obtener_usuarios,
    obtener_usuario,
    crear_usuario,
    actualizar_usuario,
    eliminar_usuario,
    login_usuario
)

router = APIRouter(
    prefix="/usuarios",
    tags=["Usuarios"]
)
# ============================
# SCHEMA LOGIN
# ============================

class LoginSchema(BaseModel):
    usuario: str
    password: str
# ============================
# LOGIN
# ============================

@router.post("/login")
def login(data: LoginSchema):

    db = get_connection()

    return login_usuario(
        db,
        data.dict()
    )

# ============================
# GET ALL
# ============================

@router.get("/")
def get_all():

    db = get_connection()

    return obtener_usuarios(db)


# ============================
# GET BY ID
# ============================

@router.get("/{id_usuario}")
def get_by_id(id_usuario: int):

    db = get_connection()

    return obtener_usuario(
        db,
        id_usuario
    )


# ============================
# POST
# ============================

@router.post("/")
def create(data: UsuarioCreate):

    db = get_connection()

    return crear_usuario(
        db,
        data.dict()
    )


# ============================
# PUT
# ============================

@router.put("/{id_usuario}")
def update(
    id_usuario: int,
    data: UsuarioUpdate
):

    db = get_connection()

    return actualizar_usuario(
        db,
        id_usuario,
        data.dict()
    )


# ============================
# DELETE
# ============================

@router.delete("/{id_usuario}")
def delete(id_usuario: int):

    db = get_connection()

    return eliminar_usuario(
        db,
        id_usuario
    )