from fastapi import APIRouter

from app.schemas.inventarios_schema import (
    InventarioCreate,
    InventarioUpdate
)

from app.db.database import get_connection

from app.controllers.inventarios_controller import (
    obtener_inventarios,
    obtener_inventario,
    crear_inventario,
    actualizar_inventario,
    eliminar_inventario
)

router = APIRouter(
    prefix="/inventarios",
    tags=["Inventarios"]
)

# ============================
# GET ALL
# ============================

@router.get("/")
def get_all():
    db = get_connection()

    return obtener_inventarios(db)


# ============================
# GET BY ID
# ============================

@router.get("/{id_inventario}")
def get_by_id(id_inventario: int):
    db = get_connection()

    return obtener_inventario(
        db,
        id_inventario
    )


# ============================
# POST
# ============================

@router.post("/")
def create(data: InventarioCreate):
    db = get_connection()

    return crear_inventario(
        db,
        data.dict()
    )


# ============================
# PUT
# ============================

@router.put("/{id_inventario}")
def update(
    id_inventario: int,
    data: InventarioUpdate
):
    db = get_connection()

    return actualizar_inventario(
        db,
        id_inventario,
        data.dict()
    )


# ============================
# DELETE
# ============================

@router.delete("/{id_inventario}")
def delete(id_inventario: int):
    db = get_connection()

    return eliminar_inventario(
        db,
        id_inventario
    )