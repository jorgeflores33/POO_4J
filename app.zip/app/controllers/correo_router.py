from fastapi import APIRouter
from pydantic import BaseModel

from app.controllers.correo_controller import (
    enviar_factura_correo
)

router = APIRouter(
    prefix="/correo",
    tags=["Correo"]
)


# ==========================================
# SCHEMA
# ==========================================

class CorreoSchema(BaseModel):

    correo: str

    ruta_pdf: str


# ==========================================
# ENVIAR FACTURA
# ==========================================

@router.post("/enviar")

async def enviar_correo_route(
    data: CorreoSchema
):

    return await enviar_factura_correo(

        data.correo,

        data.ruta_pdf
    )