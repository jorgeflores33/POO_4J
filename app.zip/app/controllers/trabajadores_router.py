from fastapi import APIRouter
from app.schemas.trabajadores_schema import (
    TrabajadorCreate,
    TrabajadorUpdate
)

from app.controllers.trabajadores_controller import (
    get_all_trabajadores,
    get_trabajador,
    crear_trabajador,
    actualizar_trabajador,
    eliminar_trabajador
)

router = APIRouter(
    prefix="/trabajadores",
    tags=["Trabajadores"]
)

# 🔍 GET ALL
@router.get("/")
def obtener_todos():
    return get_all_trabajadores()

# 🔍 GET BY ID
@router.get("/{id_trabajador}")
def obtener_uno(id_trabajador: int):
    return get_trabajador(id_trabajador)

# ➕ POST
@router.post("/")
def create(data: TrabajadorCreate):
    return crear_trabajador(data)

# ✏️ PUT
@router.put("/{id_trabajador}")
def update(id_trabajador: int, data: TrabajadorUpdate):
    return actualizar_trabajador(id_trabajador, data)

# ❌ DELETE
@router.delete("/{id_trabajador}")
def delete(id_trabajador: int):
    return eliminar_trabajador(id_trabajador)