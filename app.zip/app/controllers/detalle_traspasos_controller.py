from app.services.detalle_traspasos_service import (
    get_detalles_traspasos,
    get_detalle_by_id,
    create_detalle_traspaso,
    update_detalle_traspaso,
    delete_detalle_traspaso
)

# ============================
# GET
# ============================

def obtener_detalles_traspasos(db):
    return get_detalles_traspasos(db)


def obtener_detalle_traspaso(db, id_detalle):
    return get_detalle_by_id(db, id_detalle)


# ============================
# POST
# ============================

def crear_detalle_traspaso(db, data):
    return create_detalle_traspaso(db, data)


# ============================
# PUT
# ============================

def actualizar_detalle_traspaso(db, id_detalle, data):
    return update_detalle_traspaso(db, id_detalle, data)


# ============================
# DELETE
# ============================

def eliminar_detalle_traspaso(db, id_detalle):
    return delete_detalle_traspaso(db, id_detalle)