from fastapi import APIRouter

from app.schemas.cotizaciones_schema import (
    CotizacionCreate,
    CotizacionUpdate
)

from app.db.database import get_connection

from app.controllers.cotizaciones_controller import (
    obtener_cotizaciones,
    obtener_cotizacion,
    crear_cotizacion,
    actualizar_cotizacion,
    eliminar_cotizacion
)

router = APIRouter(
    prefix="/cotizaciones",
    tags=["Cotizaciones"]
)

# ============================
# GET ALL
# ============================

@router.get("/")
def get_all():
    db = get_connection()

    return obtener_cotizaciones(db)


# ============================
# GET BY ID
# ============================

@router.get("/{id_cotizacion}")
def get_by_id(id_cotizacion: int):
    db = get_connection()

    return obtener_cotizacion(
        db,
        id_cotizacion
    )


# ============================
# POST
# ============================

@router.post("/")
def create(data: CotizacionCreate):
    db = get_connection()

    return crear_cotizacion(
        db,
        data.dict()
    )


# ============================
# PUT
# ============================

@router.put("/{id_cotizacion}")
def update(
    id_cotizacion: int,
    data: CotizacionUpdate
):
    db = get_connection()

    return actualizar_cotizacion(
        db,
        id_cotizacion,
        data.dict()
    )


# ============================
# DELETE
# ============================

@router.delete("/{id_cotizacion}")
def delete(id_cotizacion: int):
    db = get_connection()

    return eliminar_cotizacion(
        db,
        id_cotizacion
    )