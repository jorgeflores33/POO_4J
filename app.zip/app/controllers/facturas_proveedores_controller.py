from app.services.facturas_proveedores_service import (
    get_facturas_proveedores,
    get_factura_proveedor_by_id,
    create_factura_proveedor,
    update_factura_proveedor,
    delete_factura_proveedor
)

# ============================
# GET
# ============================

def obtener_facturas_proveedores(db):
    return get_facturas_proveedores(db)


def obtener_factura_proveedor(db, id_factura):
    return get_factura_proveedor_by_id(db, id_factura)


# ============================
# POST
# ============================

def crear_factura_proveedor(db, data):
    return create_factura_proveedor(db, data)


# ============================
# PUT
# ============================

def actualizar_factura_proveedor(db, id_factura, data):
    return update_factura_proveedor(db, id_factura, data)


# ============================
# DELETE
# ============================

def eliminar_factura_proveedor(db, id_factura):
    return delete_factura_proveedor(db, id_factura)