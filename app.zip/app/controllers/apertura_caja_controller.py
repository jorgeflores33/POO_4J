from app.services.apertura_caja_service import (

    get_aperturas,

    get_apertura_by_id,

    create_apertura,

    update_apertura,

    cerrar_caja,

    delete_apertura
)


# ============================
# GET
# ============================

def obtener_aperturas(db):

    return get_aperturas(db)


def obtener_apertura(
    db,
    id_apertura
):

    return get_apertura_by_id(
        db,
        id_apertura
    )


# ============================
# POST
# ============================

def crear_apertura(
    db,
    data
):

    return create_apertura(
        db,
        data
    )


# ============================
# PUT
# ============================

def actualizar_apertura(
    db,
    id_apertura,
    data
):

    return update_apertura(
        db,
        id_apertura,
        data
    )


# ============================
# CERRAR CAJA
# ============================

def cerrar_apertura(
    db,
    id_apertura
):

    return cerrar_caja(
        db,
        id_apertura
    )


# ============================
# DELETE
# ============================

def eliminar_apertura(
    db,
    id_apertura
):

    return delete_apertura(
        db,
        id_apertura
    )