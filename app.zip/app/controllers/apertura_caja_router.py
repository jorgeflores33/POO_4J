from fastapi import APIRouter

from app.schemas.apertura_caja_schema import (

    AperturaCajaCreate,

    AperturaCajaUpdate
)

from app.db.database import get_connection

from app.controllers.apertura_caja_controller import (

    obtener_aperturas,

    obtener_apertura,

    crear_apertura,

    actualizar_apertura,

    cerrar_apertura,

    eliminar_apertura
)


router = APIRouter(

    prefix="/apertura-caja",

    tags=["Apertura Caja"]
)


# ============================
# GET ALL
# ============================

@router.get("/")

def get_all():

    db = get_connection()

    return obtener_aperturas(db)


# ============================
# GET BY ID
# ============================

@router.get("/{id_apertura}")

def get_by_id(
    id_apertura: int
):

    db = get_connection()

    return obtener_apertura(
        db,
        id_apertura
    )


# ============================
# POST
# ============================

@router.post("/")

def create(
    data: AperturaCajaCreate
):

    db = get_connection()

    return crear_apertura(

        db,

        data.dict()
    )


# ============================
# PUT
# ============================

@router.put("/{id_apertura}")

def update(

    id_apertura: int,

    data: AperturaCajaUpdate
):

    db = get_connection()

    return actualizar_apertura(

        db,

        id_apertura,

        data.dict()
    )


# ============================
# CERRAR CAJA
# ============================

@router.put("/cerrar/{id_apertura}")

def cerrar(
    id_apertura: int
):

    db = get_connection()

    return cerrar_apertura(
        db,
        id_apertura
    )


# ============================
# DELETE
# ============================

@router.delete("/{id_apertura}")

def delete(
    id_apertura: int
):

    db = get_connection()

    return eliminar_apertura(

        db,

        id_apertura
    )