from app.services.traspasos_service import (
    get_traspasos,
    get_traspaso_by_id,
    create_traspaso,
    update_traspaso,
    delete_traspaso
)

# ============================
# GET
# ============================

def obtener_traspasos(db):
    return get_traspasos(db)


def obtener_traspaso(db, id_traspaso):
    return get_traspaso_by_id(db, id_traspaso)


# ============================
# POST
# ============================

def crear_traspaso(db, data):
    return create_traspaso(db, data)


# ============================
# PUT
# ============================

def actualizar_traspaso(db, id_traspaso, data):
    return update_traspaso(db, id_traspaso, data)


# ============================
# DELETE
# ============================

def eliminar_traspaso(db, id_traspaso):
    return delete_traspaso(db, id_traspaso)