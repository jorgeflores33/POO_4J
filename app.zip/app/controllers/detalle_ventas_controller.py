from app.services.detalle_ventas_service import (

    get_detalle_ventas,

    get_detalle_by_id,

    create_detalle_venta,

    update_detalle_venta,

    delete_detalle_venta,

    get_detalle_by_venta,

    delete_detalles_by_venta
)
# ============================
# GET
# ============================

def obtener_detalles_ventas(db):
    return get_detalle_ventas(db)


def obtener_detalle_venta(db, id_detalle):
    return get_detalle_by_id(db, id_detalle)

# ==============================================
# GET → detalle por venta
# ==============================================

def obtener_detalle_by_venta(
    db,
    id_venta
):

    return get_detalle_by_venta(
        db,
        id_venta
    )

# ============================
# POST
# ============================

def crear_detalle_venta(db, data):
    return create_detalle_venta(db, data)


# ============================
# PUT
# ============================

def actualizar_detalle_venta(db, id_detalle, data):
    return update_detalle_venta(db, id_detalle, data)

# =========================================
# DELETE POR VENTA
# =========================================

def eliminar_detalles_by_venta(
    db,
    id_venta
):

    return delete_detalles_by_venta(
        db,
        id_venta
    )
# ============================
# DELETE
# ============================

def eliminar_detalle_venta(db, id_detalle):
    return delete_detalle_venta(db, id_detalle)