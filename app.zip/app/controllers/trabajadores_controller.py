from app.services.trabajadores_service import (
    get_trabajadores,
    get_trabajador_by_id,
    create_trabajador,
    update_trabajador,
    delete_trabajador
)

# 🔍 Obtener todos
def get_all_trabajadores():
    return get_trabajadores()

# 🔍 Obtener uno
def get_trabajador(id_trabajador: int):
    return get_trabajador_by_id(id_trabajador)

# ➕ Crear
def crear_trabajador(data):
    return create_trabajador(data.dict())

# ✏️ Actualizar
def actualizar_trabajador(id_trabajador: int, data):
    return update_trabajador(
        id_trabajador,
        data.dict()
    )

# ❌ Eliminar
def eliminar_trabajador(id_trabajador: int):
    return delete_trabajador(id_trabajador)