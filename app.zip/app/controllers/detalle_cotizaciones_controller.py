from app.services.detalle_cotizaciones_service import (
    get_detalles_cotizacion,
    get_detalle_by_id,
    create_detalle_cotizacion,
    update_detalle_cotizacion,
    delete_detalle_cotizacion
)

# ============================
# GET
# ============================

def obtener_detalles_cotizaciones(db):
    return get_detalles_cotizacion(db)


def obtener_detalle_cotizacion(db, id_detalle):
    return get_detalle_by_id(db, id_detalle)


# ============================
# POST
# ============================

def crear_detalle_cotizacion(db, data):
    return create_detalle_cotizacion(db, data)


# ============================
# PUT
# ============================

def actualizar_detalle_cotizacion(db, id_detalle, data):
    return update_detalle_cotizacion(db, id_detalle, data)


# ============================
# DELETE
# ============================

def eliminar_detalle_cotizacion(db, id_detalle):
    return delete_detalle_cotizacion(db, id_detalle)