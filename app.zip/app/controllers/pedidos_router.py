from fastapi import APIRouter

from app.schemas.pedidos_schema import (
    PedidoCreate,
    PedidoUpdate
)

from app.db.database import get_connection

from app.controllers.pedidos_controller import (
    obtener_pedidos,
    obtener_pedido,
    crear_pedido,
    actualizar_pedido,
    eliminar_pedido
)

router = APIRouter(
    prefix="/pedidos",
    tags=["Pedidos"]
)

# ============================
# GET ALL
# ============================

@router.get("/")
def get_all():
    db = get_connection()

    return obtener_pedidos(db)


# ============================
# GET BY ID
# ============================

@router.get("/{id_pedido}")
def get_by_id(id_pedido: int):
    db = get_connection()

    return obtener_pedido(
        db,
        id_pedido
    )


# ============================
# POST
# ============================

@router.post("/")
def create(data: PedidoCreate):
    db = get_connection()

    return crear_pedido(
        db,
        data.dict()
    )


# ============================
# PUT
# ============================

@router.put("/{id_pedido}")
def update(
    id_pedido: int,
    data: PedidoUpdate
):
    db = get_connection()

    return actualizar_pedido(
        db,
        id_pedido,
        data.dict()
    )


# ============================
# DELETE
# ============================

@router.delete("/{id_pedido}")
def delete(id_pedido: int):
    db = get_connection()

    return eliminar_pedido(
        db,
        id_pedido
    )