from fastapi import APIRouter

from app.schemas.ventas_schema import (
    VentaCreate,
    VentaUpdate
)

from app.db.database import get_connection

from app.controllers.ventas_controller import (
    obtener_ventas,
    obtener_venta,
    crear_venta,
    actualizar_venta,
    eliminar_venta
)

router = APIRouter(
    prefix="/ventas",
    tags=["Ventas"]
)

# ============================
# GET ALL
# ============================

@router.get("/")
def get_all():
    db = get_connection()

    return obtener_ventas(db)


# ============================
# GET BY ID
# ============================

@router.get("/{id_venta}")
def get_by_id(id_venta: int):
    db = get_connection()

    return obtener_venta(
        db,
        id_venta
    )


# ============================
# POST
# ============================

@router.post("/")
def create(data: VentaCreate):
    db = get_connection()

    return crear_venta(
        db,
        data.dict()
    )


# ============================
# PUT
# ============================

@router.put("/{id_venta}")
def update(
    id_venta: int,
    data: VentaUpdate
):
    db = get_connection()

    return actualizar_venta(
        db,
        id_venta,
        data.dict()
    )


# ============================
# DELETE
# ============================

@router.delete("/{id_venta}")
def delete(id_venta: int):
    db = get_connection()

    return eliminar_venta(
        db,
        id_venta
    )