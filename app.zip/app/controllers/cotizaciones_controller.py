from app.services.cotizaciones_service import (
    get_cotizaciones,
    get_cotizacion_by_id,
    create_cotizacion,
    update_cotizacion,
    delete_cotizacion
)

# ============================
# GET
# ============================

def obtener_cotizaciones(db):
    return get_cotizaciones(db)


def obtener_cotizacion(db, id_cotizacion):
    return get_cotizacion_by_id(db, id_cotizacion)


# ============================
# POST
# ============================

def crear_cotizacion(db, data):
    return create_cotizacion(db, data)


# ============================
# PUT
# ============================

def actualizar_cotizacion(db, id_cotizacion, data):
    return update_cotizacion(db, id_cotizacion, data)


# ============================
# DELETE
# ============================

def eliminar_cotizacion(db, id_cotizacion):
    return delete_cotizacion(db, id_cotizacion)