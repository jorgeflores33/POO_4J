from fastapi import APIRouter

from app.schemas.facturas_proveedores_schema import (
    FacturaProveedorCreate,
    FacturaProveedorUpdate
)

from app.db.database import get_connection

from app.controllers.facturas_proveedores_controller import (
    obtener_facturas_proveedores,
    obtener_factura_proveedor,
    crear_factura_proveedor,
    actualizar_factura_proveedor,
    eliminar_factura_proveedor
)

router = APIRouter(
    prefix="/facturas-proveedores",
    tags=["Facturas Proveedores"]
)

# ============================
# GET ALL
# ============================

@router.get("/")
def get_all():
    db = get_connection()

    return obtener_facturas_proveedores(db)


# ============================
# GET BY ID
# ============================

@router.get("/{id_factura}")
def get_by_id(id_factura: int):
    db = get_connection()

    return obtener_factura_proveedor(
        db,
        id_factura
    )


# ============================
# POST
# ============================

@router.post("/")
def create(data: FacturaProveedorCreate):
    db = get_connection()

    return crear_factura_proveedor(
        db,
        data.dict()
    )


# ============================
# PUT
# ============================

@router.put("/{id_factura}")
def update(
    id_factura: int,
    data: FacturaProveedorUpdate
):
    db = get_connection()

    return actualizar_factura_proveedor(
        db,
        id_factura,
        data.dict()
    )


# ============================
# DELETE
# ============================

@router.delete("/{id_factura}")
def delete(id_factura: int):
    db = get_connection()

    return eliminar_factura_proveedor(
        db,
        id_factura
    )