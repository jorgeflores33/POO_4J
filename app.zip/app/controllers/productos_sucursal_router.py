from fastapi import APIRouter

from app.schemas.productos_sucursal_schema import (
    ProductoSucursalCreate,
    ProductoSucursalUpdate
)

from app.db.database import get_connection

from app.controllers.productos_sucursal_controller import (

    obtener_productos_sucursal,

    obtener_producto_sucursal,

    crear_producto_sucursal,

    actualizar_producto_sucursal,

    eliminar_producto_sucursal,

    validar_producto_usuario_controller,

    obtener_productos_usuario_controller
)

router = APIRouter(

    prefix="/productos-sucursal",

    tags=["Productos Sucursal"]
)


# ============================
# GET ALL
# ============================

@router.get("/")
def get_all():

    db = get_connection()

    return obtener_productos_sucursal(
        db
    )


# ============================
# GET PRODUCTOS USUARIO
# ============================

@router.get(
    "/usuario/{usuario}"
)
def get_productos_usuario(
    usuario: str
):

    db = get_connection()

    return obtener_productos_usuario_controller(

        db,

        usuario
    )


# ============================
# GET ONE
# PK COMPUESTA
# ============================

@router.get(
    "/{id_producto}/{id_sucursal}"
)
def get_by_id(

    id_producto: int,

    id_sucursal: int
):

    db = get_connection()

    return obtener_producto_sucursal(

        db,

        id_producto,

        id_sucursal
    )


# ============================
# POST
# ============================

@router.post("/")
def create(
    data: ProductoSucursalCreate
):

    db = get_connection()

    return crear_producto_sucursal(

        db,

        data.dict()
    )


# ============================
# PUT
# ============================

@router.put(
    "/{id_producto}/{id_sucursal}"
)
def update(

    id_producto: int,

    id_sucursal: int,

    data: ProductoSucursalUpdate
):

    db = get_connection()

    return actualizar_producto_sucursal(

        db,

        id_producto,

        id_sucursal,

        data.dict()
    )


# ============================
# DELETE
# ============================

@router.delete(
    "/{id_producto}/{id_sucursal}"
)
def delete(

    id_producto: int,

    id_sucursal: int
):

    db = get_connection()

    return eliminar_producto_sucursal(

        db,

        id_producto,

        id_sucursal
    )


# ============================
# VALIDAR PRODUCTO SUCURSAL
# ============================

@router.get(
    "/validar/{usuario}/{id_producto}"
)
def validar_producto(

    usuario: str,

    id_producto: int
):

    return validar_producto_usuario_controller(

        usuario,

        id_producto
    )
