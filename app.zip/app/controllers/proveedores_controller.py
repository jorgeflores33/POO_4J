from app.services.proveedores_service import (
    get_proveedores,
    get_proveedor_by_id,
    create_proveedor,
    update_proveedor,
    delete_proveedor
)

# ============================
# GET
# ============================

def obtener_proveedores(db):
    return get_proveedores(db)


def obtener_proveedor(db, id_proveedor):
    return get_proveedor_by_id(db, id_proveedor)


# ============================
# POST
# ============================

def crear_proveedor(db, data):
    return create_proveedor(db, data)


# ============================
# PUT
# ============================

def actualizar_proveedor(db, id_proveedor, data):
    return update_proveedor(db, id_proveedor, data)


# ============================
# DELETE
# ============================

def eliminar_proveedor(db, id_proveedor):
    return delete_proveedor(db, id_proveedor)