from app.services.pedidos_service import (
    get_pedidos,
    get_pedido_by_id,
    create_pedido,
    update_pedido,
    delete_pedido
)

# ============================
# GET
# ============================

def obtener_pedidos(db):
    return get_pedidos(db)


def obtener_pedido(db, id_pedido):
    return get_pedido_by_id(db, id_pedido)


# ============================
# POST
# ============================

def crear_pedido(db, data):
    return create_pedido(db, data)


# ============================
# PUT
# ============================

def actualizar_pedido(db, id_pedido, data):
    return update_pedido(db, id_pedido, data)


# ============================
# DELETE
# ============================

def eliminar_pedido(db, id_pedido):
    return delete_pedido(db, id_pedido)