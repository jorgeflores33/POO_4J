from fastapi import APIRouter

from app.schemas.sucursales_schema import (
    SucursalCreate,
    SucursalUpdate
)

from app.db.database import get_connection

from app.controllers.sucursales_controller import (
    obtener_sucursales,
    obtener_sucursal,
    crear_sucursal,
    actualizar_sucursal,
    eliminar_sucursal
)

router = APIRouter(
    prefix="/sucursales",
    tags=["Sucursales"]
)

# ============================
# GET ALL
# ============================

@router.get("/")
def get_all():
    db = get_connection()

    return obtener_sucursales(db)


# ============================
# GET BY ID
# ============================

@router.get("/{id_sucursal}")
def get_by_id(id_sucursal: int):
    db = get_connection()

    return obtener_sucursal(
        db,
        id_sucursal
    )


# ============================
# POST
# ============================

@router.post("/")
def create(data: SucursalCreate):
    db = get_connection()

    return crear_sucursal(
        db,
        data.dict()
    )


# ============================
# PUT
# ============================

@router.put("/{id_sucursal}")
def update(
    id_sucursal: int,
    data: SucursalUpdate
):
    db = get_connection()

    return actualizar_sucursal(
        db,
        id_sucursal,
        data.dict()
    )


# ============================
# DELETE
# ============================

@router.delete("/{id_sucursal}")
def delete(id_sucursal: int):
    db = get_connection()

    return eliminar_sucursal(
        db,
        id_sucursal
    )