from app.services.corte_caja_service import (
    get_cortes,
    get_corte_by_id,
    create_corte,
    update_corte,
    delete_corte
)

# ============================
# GET
# ============================

def obtener_cortes(db):
    return get_cortes(db)


def obtener_corte(db, id_corte):
    return get_corte_by_id(db, id_corte)


# ============================
# POST
# ============================

def crear_corte(db, data):
    return create_corte(db, data)


# ============================
# PUT
# ============================

def actualizar_corte(db, id_corte, data):
    return update_corte(db, id_corte, data)


# ============================
# DELETE
# ============================

def eliminar_corte(db, id_corte):
    return delete_corte(db, id_corte)