from app.services.clientes_service import (
    get_clientes,
    get_cliente_by_id,
    create_cliente,
    update_cliente,
    delete_cliente
)

# ============================
# GET
# ============================

def obtener_clientes(db):
    return get_clientes(db)


def obtener_cliente(db, id_cliente):
    return get_cliente_by_id(db, id_cliente)


# ============================
# POST
# ============================

def crear_cliente(db, data):
    return create_cliente(db, data)


# ============================
# PUT
# ============================

def actualizar_cliente(db, id_cliente, data):
    return update_cliente(db, id_cliente, data)


# ============================
# DELETE
# ============================

def eliminar_cliente(db, id_cliente):
    return delete_cliente(db, id_cliente)