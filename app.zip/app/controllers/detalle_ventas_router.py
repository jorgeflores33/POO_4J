from fastapi import APIRouter

from app.schemas.detalle_ventas_schema import (
    DetalleVentaCreate,
    DetalleVentaUpdate
)

from app.db.database import get_connection

from app.controllers.detalle_ventas_controller import (

    obtener_detalles_ventas,

    obtener_detalle_venta,

    crear_detalle_venta,

    actualizar_detalle_venta,

    eliminar_detalle_venta,

    obtener_detalle_by_venta,

    eliminar_detalles_by_venta
)
router = APIRouter(
    prefix="/detalle-ventas",
    tags=["Detalle Ventas"]
)

# ============================
# GET ALL
# ============================

@router.get("/")
def get_all():
    db = get_connection()

    return obtener_detalles_ventas(db)

# ==============================================
# GET → detalle por venta
# ==============================================

@router.get("/venta/{id_venta}")
def get_by_venta(id_venta: int):

    db = get_connection()

    return obtener_detalle_by_venta(
        db,
        id_venta
    )

# ============================
# GET BY ID
# ============================

@router.get("/{id_detalle}")
def get_by_id(id_detalle: int):
    db = get_connection()

    return obtener_detalle_venta(
        db,
        id_detalle
    )



# ============================
# POST
# ============================

@router.post("/")
def create(data: DetalleVentaCreate):
    db = get_connection()

    return crear_detalle_venta(
        db,
        data.dict()
    )


# ============================
# PUT
# ============================

@router.put("/{id_detalle}")
def update(
    id_detalle: int,
    data: DetalleVentaUpdate
):
    db = get_connection()

    return actualizar_detalle_venta(
        db,
        id_detalle,
        data.dict()
    )
# =========================================
# DELETE POR VENTA
# =========================================

@router.delete("/venta/{id_venta}")
def delete_by_venta(id_venta: int):

    db = get_connection()

    return eliminar_detalles_by_venta(
        db,
        id_venta
    )

# ============================
# DELETE
# ============================

@router.delete("/{id_detalle}")
def delete(id_detalle: int):
    db = get_connection()

    return eliminar_detalle_venta(
        db,
        id_detalle
    )
