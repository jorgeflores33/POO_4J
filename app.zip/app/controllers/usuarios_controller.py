from app.services.usuarios_service import (
    get_usuarios,
    get_usuario_by_id,
    create_usuario,
    update_usuario,
    delete_usuario,
    login_usuario
)


# ============================
# GET ALL
# ============================

def obtener_usuarios(db):
    return get_usuarios(db)


# ============================
# GET BY ID
# ============================

def obtener_usuario(db, id_usuario):
    return get_usuario_by_id(
        db,
        id_usuario
    )


# ============================
# POST
# ============================

def crear_usuario(db, data):
    return create_usuario(
        db,
        data
    )


# ============================
# PUT
# ============================

def actualizar_usuario(
    db,
    id_usuario,
    data
):
    return update_usuario(
        db,
        id_usuario,
        data
    )


# ============================
# DELETE
# ============================

def eliminar_usuario(
    db,
    id_usuario
):
    return delete_usuario(
        db,
        id_usuario
    )


# ============================
# LOGIN
# ============================

def login_usuario_controller(
    db,
    data
):
    return login_usuario(
        db,
        data
    )