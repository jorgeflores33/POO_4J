from app.services.detalle_inventarios_service import (

    get_detalles_inventario,

    get_detalle_by_id,

    get_detalles_por_inventario,

    create_detalle_inventario,

    update_detalle_inventario,

    delete_detalle_inventario
)


# ============================
# GET
# ============================

def obtener_detalles_inventarios(db):

    return get_detalles_inventario(db)



def obtener_detalle_inventario(
    db,
    id_detalle
):

    return get_detalle_by_id(
        db,
        id_detalle
    )



# ============================
# GET BY INVENTARIO
# ============================

def obtener_detalles_por_inventario(
    db,
    id_inventario
):

    return get_detalles_por_inventario(
        db,
        id_inventario
    )



# ============================
# POST
# ============================

def crear_detalle_inventario(
    db,
    data
):

    return create_detalle_inventario(
        db,
        data
    )



# ============================
# PUT
# ============================

def actualizar_detalle_inventario(
    db,
    id_detalle,
    data
):

    return update_detalle_inventario(

        db,

        id_detalle,

        data
    )



# ============================
# DELETE
# ============================

def eliminar_detalle_inventario(
    db,
    id_detalle
):

    return delete_detalle_inventario(

        db,

        id_detalle
    )