from app.services.productos_service import (
    get_productos,
    get_producto_by_id,
    create_producto,
    update_producto,
    delete_producto
)

# ============================
# GET
# ============================

def obtener_productos(db):
    return get_productos(db)


def obtener_producto(db, id_producto):
    return get_producto_by_id(db, id_producto)


# ============================
# POST
# ============================

def crear_producto(db, data):
    return create_producto(db, data)


# ============================
# PUT
# ============================

def actualizar_producto(db, id_producto, data):
    return update_producto(db, id_producto, data)


# ============================
# DELETE
# ============================

def eliminar_producto(db, id_producto):
    return delete_producto(db, id_producto)