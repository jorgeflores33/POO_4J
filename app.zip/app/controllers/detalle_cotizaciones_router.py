from fastapi import APIRouter

from app.schemas.detalle_cotizaciones_schema import (
    DetalleCotizacionCreate,
    DetalleCotizacionUpdate
)

from app.db.database import get_connection

from app.controllers.detalle_cotizaciones_controller import (
    obtener_detalles_cotizaciones,
    obtener_detalle_cotizacion,
    crear_detalle_cotizacion,
    actualizar_detalle_cotizacion,
    eliminar_detalle_cotizacion
)

router = APIRouter(
    prefix="/detalle-cotizaciones",
    tags=["Detalle Cotizaciones"]
)

# ============================
# GET ALL
# ============================

@router.get("/")
def get_all():
    db = get_connection()

    return obtener_detalles_cotizaciones(db)


# ============================
# GET BY ID
# ============================

@router.get("/{id_detalle}")
def get_by_id(id_detalle: int):
    db = get_connection()

    return obtener_detalle_cotizacion(
        db,
        id_detalle
    )


# ============================
# POST
# ============================

@router.post("/")
def create(data: DetalleCotizacionCreate):
    db = get_connection()

    return crear_detalle_cotizacion(
        db,
        data.dict()
    )


# ============================
# PUT
# ============================

@router.put("/{id_detalle}")
def update(
    id_detalle: int,
    data: DetalleCotizacionUpdate
):
    db = get_connection()

    return actualizar_detalle_cotizacion(
        db,
        id_detalle,
        data.dict()
    )


# ============================
# DELETE
# ============================

@router.delete("/{id_detalle}")
def delete(id_detalle: int):
    db = get_connection()

    return eliminar_detalle_cotizacion(
        db,
        id_detalle
    )