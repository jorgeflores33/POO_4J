from app.services.facturas_clientes_service import (
    get_facturas,
    get_factura_by_id,
    create_factura,
    update_factura,
    delete_factura
)

from app.controllers.correo_controller import (
    enviar_factura_correo
)


# ============================
# GET
# ============================

def obtener_facturas_clientes(db):

    return get_facturas(db)


def obtener_factura_cliente(
    db,
    id_factura
):

    return get_factura_by_id(
        db,
        id_factura
    )


# ============================
# POST
# ============================

async def crear_factura_cliente(
    db,
    data
):

    # crear factura
    factura = create_factura(
        db,
        data
    )

    # ruta PDF
    ruta_pdf = (

        f"facturas/factura_"

        f"{factura['id_factura']}.pdf"
    )

    # correo cliente
    correo_cliente = data.get(
        "correo"
    )

    # enviar correo
    if correo_cliente:

        await enviar_factura_correo(

            correo_cliente,

            ruta_pdf
        )

    return {

        "ok": True,

        "mensaje":
        "Factura creada y enviada",

        "factura":
        factura
    }


# ============================
# PUT
# ============================

def actualizar_factura_cliente(
    db,
    id_factura,
    data
):

    return update_factura(
        db,
        id_factura,
        data
    )


# ============================
# DELETE
# ============================

def eliminar_factura_cliente(
    db,
    id_factura
):

    return delete_factura(
        db,
        id_factura
    )