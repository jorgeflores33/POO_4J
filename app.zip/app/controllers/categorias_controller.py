from app.services.categorias_service import (
    get_categorias,
    get_categoria_by_id,
    create_categoria,
    update_categoria,
    delete_categoria
)

# ============================
# GET
# ============================

def obtener_categorias(db):
    return get_categorias(db)


def obtener_categoria(db, id_categoria):
    return get_categoria_by_id(db, id_categoria)


# ============================
# POST
# ============================

def crear_categoria(db, data):
    return create_categoria(db, data)


# ============================
# PUT
# ============================

def actualizar_categoria(db, id_categoria, data):
    return update_categoria(db, id_categoria, data)


# ============================
# DELETE
# ============================

def eliminar_categoria(db, id_categoria):
    return delete_categoria(db, id_categoria)