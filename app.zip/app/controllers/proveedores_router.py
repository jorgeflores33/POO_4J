from fastapi import APIRouter

from app.schemas.proveedores_schema import (
    ProveedorCreate,
    ProveedorUpdate
)

from app.db.database import get_connection

from app.controllers.proveedores_controller import (
    obtener_proveedores,
    obtener_proveedor,
    crear_proveedor,
    actualizar_proveedor,
    eliminar_proveedor
)

router = APIRouter(
    prefix="/proveedores",
    tags=["Proveedores"]
)

# ============================
# GET ALL
# ============================

@router.get("/")
def get_all():
    db = get_connection()

    return obtener_proveedores(db)


# ============================
# GET BY ID
# ============================

@router.get("/{id_proveedor}")
def get_by_id(id_proveedor: int):
    db = get_connection()

    return obtener_proveedor(
        db,
        id_proveedor
    )


# ============================
# POST
# ============================

@router.post("/")
def create(data: ProveedorCreate):
    db = get_connection()

    return crear_proveedor(
        db,
        data.dict()
    )


# ============================
# PUT
# ============================

@router.put("/{id_proveedor}")
def update(
    id_proveedor: int,
    data: ProveedorUpdate
):
    db = get_connection()

    return actualizar_proveedor(
        db,
        id_proveedor,
        data.dict()
    )


# ============================
# DELETE
# ============================

@router.delete("/{id_proveedor}")
def delete(id_proveedor: int):
    db = get_connection()

    return eliminar_proveedor(
        db,
        id_proveedor
    )