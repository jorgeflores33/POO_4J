import mysql.connector

def get_connection():
    config = {
        'user': 'admin',
        'password': '1234',
        'host': 'localhost',
        'database': 'papeleria'
    }

    return mysql.connector.connect(**config)