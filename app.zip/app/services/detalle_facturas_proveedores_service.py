# app/services/detalle_facturas_proveedores_service.py

from app.models import detalle_facturas_proveedores_queries


# ============================
# GET
# ============================

def get_detalles_factura_proveedor(db):

    return detalle_facturas_proveedores_queries.get_all()


def get_detalle_by_id(
    db,
    id_detalle
):

    detalle = detalle_facturas_proveedores_queries.get_by_id(
        id_detalle
    )

    if not detalle:

        raise ValueError(
            "Detalle no encontrado"
        )

    return detalle


# ============================
# POST
# ============================

def create_detalle_factura_proveedor(
    db,
    data
):

    # Validar factura
    if not data.get("id_factura"):

        raise ValueError(
            "El id_factura es obligatorio"
        )

    # Validar producto
    if not data.get("codigo_producto"):

        raise ValueError(
            "El codigo_producto es obligatorio"
        )

    # Validar cantidad
    cantidad = data.get("cantidad")

    if (
        not cantidad
        or
        cantidad <= 0
    ):

        raise ValueError(
            "La cantidad debe ser mayor a 0"
        )

    # Validar precio
    precio = data.get(
        "precio_unitario"
    )

    if (
        precio is None
        or
        float(precio) <= 0
    ):

        raise ValueError(
            "El precio unitario debe ser mayor a 0"
        )

    # Calcular subtotal
    data["subtotal"] = (
        float(precio)
        *
        int(cantidad)
    )

    return detalle_facturas_proveedores_queries.insert(
        data
    )


# ============================
# PUT
# ============================

def update_detalle_factura_proveedor(
    db,
    id_detalle,
    data
):

    detalle = detalle_facturas_proveedores_queries.get_by_id(
        id_detalle
    )

    if not detalle:

        raise ValueError(
            "El detalle no existe"
        )

    cantidad = data.get(
        "cantidad",
        detalle["cantidad"]
    )

    precio = data.get(
        "precio_unitario",
        detalle["precio_unitario"]
    )

    if cantidad <= 0:

        raise ValueError(
            "La cantidad debe ser mayor a 0"
        )

    if float(precio) <= 0:

        raise ValueError(
            "El precio debe ser mayor a 0"
        )

    # recalcular subtotal
    data["subtotal"] = (
        float(precio)
        *
        int(cantidad)
    )

    return detalle_facturas_proveedores_queries.update(
        id_detalle,
        data
    )


# ============================
# DELETE
# ============================

def delete_detalle_factura_proveedor(
    db,
    id_detalle
):

    detalle = detalle_facturas_proveedores_queries.get_by_id(
        id_detalle
    )

    if not detalle:

        raise ValueError(
            "El detalle no existe"
        )

    return detalle_facturas_proveedores_queries.delete(
        id_detalle
    )