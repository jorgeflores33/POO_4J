# app/services/traspasos_service.py

from app.models import traspasos_queries
from app.models import sucursales_queries


# ============================
# GET
# ============================

def get_traspasos(db):

    return traspasos_queries.get_all()


def get_traspaso_by_id(
    db,
    id_traspaso
):

    traspaso = traspasos_queries.get_by_id(
        id_traspaso
    )

    if not traspaso:

        raise ValueError(
            "Traspaso no encontrado"
        )

    return traspaso


# ============================
# POST
# ============================

def create_traspaso(
    db,
    data
):

    id_origen = data.get(
        "id_sucursal_origen"
    )

    id_destino = data.get(
        "id_sucursal_destino"
    )

    # Validar origen
    origen = sucursales_queries.get_by_id(
        id_origen
    )

    if not origen:

        raise ValueError(
            "La sucursal origen no existe"
        )

    # Validar destino
    destino = sucursales_queries.get_by_id(
        id_destino
    )

    if not destino:

        raise ValueError(
            "La sucursal destino no existe"
        )

    # No permitir iguales
    if id_origen == id_destino:

        raise ValueError(
            "Origen y destino no pueden ser iguales"
        )

    return traspasos_queries.insert(
        data
    )


# ============================
# PUT
# ============================

def update_traspaso(
    db,
    id_traspaso,
    data
):

    traspaso = traspasos_queries.get_by_id(
        id_traspaso
    )

    if not traspaso:

        raise ValueError(
            "El traspaso no existe"
        )

    origen = data.get(
        "id_sucursal_origen",
        traspaso["id_sucursal_origen"]
    )

    destino = data.get(
        "id_sucursal_destino",
        traspaso["id_sucursal_destino"]
    )

    if origen == destino:

        raise ValueError(
            "Origen y destino no pueden ser iguales"
        )

    return traspasos_queries.update(
        id_traspaso,
        data
    )


# ============================
# DELETE
# ============================

def delete_traspaso(
    db,
    id_traspaso
):

    traspaso = traspasos_queries.get_by_id(
        id_traspaso
    )

    if not traspaso:

        raise ValueError(
            "El traspaso no existe"
        )

    return traspasos_queries.delete(
        id_traspaso
    )