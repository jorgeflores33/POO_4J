# app/services/facturas_clientes_service.py

from app.models import facturas_clientes_queries
from app.models import clientes_queries
from app.models import ventas_queries


IVA_PORCENTAJE = 0.16


# ============================
# GET
# ============================

def get_facturas(db):

    return facturas_clientes_queries.get_all()


def get_factura_by_id(
    db,
    id_factura
):

    factura = facturas_clientes_queries.get_by_id(
        id_factura
    )

    if not factura:

        raise ValueError(
            "Factura no encontrada"
        )

    return factura


# ============================
# POST
# ============================

def create_factura(
    db,
    data
):

    # ============================
    # VALIDAR CLIENTE
    # ============================

    id_cliente = data.get(
        "id_cliente"
    )

    if not id_cliente:

        raise ValueError(
            "El id_cliente es obligatorio"
        )

    cliente = clientes_queries.get_by_id(
        id_cliente
    )

    if not cliente:

        raise ValueError(
            "El cliente no existe"
        )


    # ============================
    # VALIDAR VENTA
    # ============================

    id_venta = data.get(
        "id_venta"
    )

    if not id_venta:

        raise ValueError(
            "El id_venta es obligatorio"
        )

    venta = ventas_queries.get_by_id(
        id_venta
    )

    if not venta:

        raise ValueError(
            "La venta no existe"
        )


    # ============================
    # VALIDAR USO CFDI
    # ============================

    if not data.get("uso_cfdi"):

        raise ValueError(
            "El uso CFDI es obligatorio"
        )


    # ============================
    # VALIDAR SUBTOTAL
    # ============================

    subtotal = data.get(
        "subtotal"
    )

    if subtotal is None:

        raise ValueError(
            "El subtotal es obligatorio"
        )

    subtotal = float(subtotal)

    if subtotal <= 0:

        raise ValueError(
            "El subtotal debe ser mayor a 0"
        )


    # ============================
    # CALCULAR IVA
    # ============================

    iva = round(
        subtotal * IVA_PORCENTAJE,
        2
    )


    # ============================
    # CALCULAR TOTAL
    # ============================

    total = round(
        subtotal + iva,
        2
    )


    data["iva"] = iva

    data["total"] = total


    # ============================
    # GENERAR FOLIO
    # ============================

    if not data.get("folio"):

        data["folio"] = (

            f"FAC-"

            f"{id_cliente}-"

            f"{id_venta}"
        )


    # ============================
    # VALIDAR CORREO
    # ============================

    correo = data.get(
        "correo"
    )

    if correo:

        if "@" not in correo:

            raise ValueError(
                "Correo inválido"
            )


    # ============================
    # INSERT
    # ============================

    return facturas_clientes_queries.insert(
        data
    )


# ============================
# PUT
# ============================

def update_factura(
    db,
    id_factura,
    data
):

    factura = facturas_clientes_queries.get_by_id(
        id_factura
    )

    if not factura:

        raise ValueError(
            "La factura no existe"
        )


    # ============================
    # SUBTOTAL
    # ============================

    subtotal = float(

        data.get(

            "subtotal",

            factura["subtotal"]
        )
    )


    if subtotal <= 0:

        raise ValueError(
            "El subtotal debe ser mayor a 0"
        )


    # ============================
    # RECALCULAR IVA
    # ============================

    iva = round(
        subtotal * IVA_PORCENTAJE,
        2
    )


    # ============================
    # RECALCULAR TOTAL
    # ============================

    total = round(
        subtotal + iva,
        2
    )


    data["iva"] = iva

    data["total"] = total


    # ============================
    # VALIDAR CORREO
    # ============================

    correo = data.get(
        "correo"
    )

    if correo:

        if "@" not in correo:

            raise ValueError(
                "Correo inválido"
            )


    # ============================
    # UPDATE
    # ============================

    return facturas_clientes_queries.update(
        id_factura,
        data
    )


# ============================
# DELETE
# ============================

def delete_factura(
    db,
    id_factura
):

    factura = facturas_clientes_queries.get_by_id(
        id_factura
    )

    if not factura:

        raise ValueError(
            "La factura no existe"
        )

    return facturas_clientes_queries.delete(
        id_factura
    )
