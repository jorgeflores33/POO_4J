# app/services/apertura_caja_service.py

from app.models import apertura_caja_queries


# ============================
# ESTADOS
# ============================

ESTADO_ABIERTA = "ABIERTA"

ESTADO_CERRADA = "CERRADA"


# ============================
# GET
# ============================

def get_aperturas(db):

    return apertura_caja_queries.get_all()


def get_apertura_by_id(
    db,
    id_apertura
):

    apertura = apertura_caja_queries.get_by_id(
        id_apertura
    )

    if not apertura:

        raise ValueError(
            "Apertura no encontrada"
        )

    return apertura


# ============================
# POST
# ============================

def create_apertura(
    db,
    data
):

    # =========================
    # VALIDAR USUARIO
    # =========================

    if not data.get("id_usuario"):

        raise ValueError(
            "El id_usuario es obligatorio"
        )


    # =========================
    # VALIDAR TRABAJADOR
    # =========================

    if not data.get("id_trabajador"):

        raise ValueError(
            "El id_trabajador es obligatorio"
        )


    # =========================
    # VALIDAR SUCURSAL
    # =========================

    if not data.get("id_sucursal"):

        raise ValueError(
            "El id_sucursal es obligatorio"
        )


    # =========================
    # VALIDAR CAJA ABIERTA
    # =========================

    aperturas = apertura_caja_queries.get_all()


    caja_abierta = next(

        (

            a for a in aperturas

            if

            a["id_usuario"]
            ==
            data["id_usuario"]

            and

            a.get("estado")
            ==
            ESTADO_ABIERTA
        ),

        None
    )


    if caja_abierta:

        raise ValueError(
            "Ya tienes una caja abierta"
        )


    # =========================
    # ESTADO
    # =========================

    data["estado"] = (
        ESTADO_ABIERTA
    )


    # =========================
    # INSERT
    # =========================

    return apertura_caja_queries.insert(
        data
    )


# ============================
# PUT
# ============================

def update_apertura(
    db,
    id_apertura,
    data
):

    apertura = apertura_caja_queries.get_by_id(
        id_apertura
    )

    if not apertura:

        raise ValueError(
            "La apertura no existe"
        )

    return apertura_caja_queries.update(
        id_apertura,
        data
    )


# ============================
# CERRAR CAJA
# ============================

def cerrar_caja(
    db,
    id_apertura
):

    apertura = apertura_caja_queries.get_by_id(
        id_apertura
    )


    if not apertura:

        raise ValueError(
            "La apertura no existe"
        )


    if (

        apertura.get("estado")
        ==
        ESTADO_CERRADA

    ):

        raise ValueError(
            "La caja ya está cerrada"
        )


    return apertura_caja_queries.cerrar_caja(
        id_apertura
    )


# ============================
# DELETE
# ============================

def delete_apertura(
    db,
    id_apertura
):

    apertura = apertura_caja_queries.get_by_id(
        id_apertura
    )

    if not apertura:

        raise ValueError(
            "La apertura no existe"
        )

    return apertura_caja_queries.delete(
        id_apertura
    )