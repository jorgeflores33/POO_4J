# app/services/inventarios_service.py

from app.models import inventarios_queries


# ============================
# GET
# ============================

def get_inventarios(db):

    return inventarios_queries.get_all()


def get_inventario_by_id(
    db,
    id_inventario
):

    inventario = inventarios_queries.get_by_id(
        id_inventario
    )

    if not inventario:

        raise ValueError(
            "Inventario no encontrado"
        )

    return inventario


# ============================
# POST
# ============================

def create_inventario(
    db,
    data
):

    # Validar sucursal
    if not data.get("id_sucursal"):

        raise ValueError(
            "El id_sucursal es obligatorio"
        )

    # Generar folio automático
    if not data.get("folio"):

        data["folio"] = (
            f"INV-{data['id_sucursal']}"
        )

    return inventarios_queries.insert(
        data
    )


# ============================
# PUT
# ============================

def update_inventario(
    db,
    id_inventario,
    data
):

    inventario = inventarios_queries.get_by_id(
        id_inventario
    )

    if not inventario:

        raise ValueError(
            "El inventario no existe"
        )

    return inventarios_queries.update(
        id_inventario,
        data
    )


# ============================
# DELETE
# ============================

def delete_inventario(
    db,
    id_inventario
):

    inventario = inventarios_queries.get_by_id(
        id_inventario
    )

    if not inventario:

        raise ValueError(
            "El inventario no existe"
        )

    return inventarios_queries.delete(
        id_inventario
    )