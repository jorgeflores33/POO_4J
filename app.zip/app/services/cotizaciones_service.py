# app/services/cotizaciones_service.py

from app.models import cotizaciones_queries
from app.models import clientes_queries


# ============================
# GET
# ============================

def get_cotizaciones(db):
    return cotizaciones_queries.get_all_cotizaciones(db)


def get_cotizacion_by_id(db, id_cotizacion):
    cotizacion = cotizaciones_queries.get_cotizacion_by_id(db, id_cotizacion)
    
    if not cotizacion:
        raise ValueError("Cotización no encontrada")
    
    return cotizacion


# ============================
# POST
# ============================

def create_cotizacion(db, data):
    id_cliente = data.get("id_cliente")

    # Validar cliente
    if id_cliente:
        cliente = clientes_queries.get_cliente_by_id(db, id_cliente)
        if not cliente:
            raise ValueError("El cliente no existe")

    # Generar folio automático
    if not data.get("folio"):
        data["folio"] = f"COT-{id_cliente if id_cliente else 'GEN'}"

    return cotizaciones_queries.create_cotizacion(db, data)


# ============================
# PUT
# ============================

def update_cotizacion(db, id_cotizacion, data):
    cotizacion = cotizaciones_queries.get_cotizacion_by_id(db, id_cotizacion)
    
    if not cotizacion:
        raise ValueError("La cotización no existe")

    return cotizaciones_queries.update_cotizacion(db, id_cotizacion, data)


# ============================
# DELETE
# ============================

def delete_cotizacion(db, id_cotizacion):
    cotizacion = cotizaciones_queries.get_cotizacion_by_id(db, id_cotizacion)
    
    if not cotizacion:
        raise ValueError("La cotización no existe")
    
    return cotizaciones_queries.delete_cotizacion(db, id_cotizacion)


# ============================
# 🔥 MÉTODO PRO
# ============================

def generar_cotizacion(db, id_cliente=None):
    # Validar cliente si existe
    if id_cliente:
        cliente = clientes_queries.get_cliente_by_id(db, id_cliente)
        if not cliente:
            raise ValueError("El cliente no existe")

    data = {
        "id_cliente": id_cliente,
        "folio": f"COT-{id_cliente if id_cliente else 'GEN'}"
    }

    return cotizaciones_queries.create_cotizacion(db, data)