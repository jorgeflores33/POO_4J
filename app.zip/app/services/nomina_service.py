# app/services/nomina_service.py

from app.models import nomina_queries


# ============================
# GET
# ============================

def get_nominas(db):

    return nomina_queries.get_all()


def get_nomina_by_id(
    db,
    id_nomina
):

    nomina = nomina_queries.get_by_id(
        id_nomina
    )

    if not nomina:

        raise ValueError(
            "Nómina no encontrada"
        )

    return nomina


# ============================
# POST
# ============================

def create_nomina(
    db,
    data
):

    # Validar trabajador
    if not data.get("id_trabajador"):

        raise ValueError(
            "El id_trabajador es obligatorio"
        )

    # Validar asistencia
    if not data.get("id_asistencia"):

        raise ValueError(
            "El id_asistencia es obligatorio"
        )

    # Validar sueldo
    sueldo_base = data.get(
        "sueldo_base"
    )

    if (
        sueldo_base is None
        or
        float(sueldo_base) < 0
    ):

        raise ValueError(
            "El sueldo base es inválido"
        )

    # Validar días
    dias_trabajados = data.get(
        "dias_trabajados"
    )

    if (
        dias_trabajados is None
        or
        int(dias_trabajados) <= 0
    ):

        raise ValueError(
            "Los días trabajados son inválidos"
        )

    # calcular total
    total_pago = (
        float(sueldo_base)
        *
        int(dias_trabajados)
    )

    data["total_pago"] = total_pago

    return nomina_queries.insert(
        data
    )


# ============================
# PUT
# ============================

def update_nomina(
    db,
    id_nomina,
    data
):

    nomina = nomina_queries.get_by_id(
        id_nomina
    )

    if not nomina:

        raise ValueError(
            "La nómina no existe"
        )

    sueldo_base = float(
        data.get(
            "sueldo_base",
            nomina["sueldo_base"]
        )
    )

    dias_trabajados = int(
        data.get(
            "dias_trabajados",
            nomina["dias_trabajados"]
        )
    )

    if sueldo_base < 0:

        raise ValueError(
            "El sueldo base no puede ser negativo"
        )

    if dias_trabajados <= 0:

        raise ValueError(
            "Los días trabajados deben ser mayores a 0"
        )

    # recalcular total
    data["total_pago"] = (
        sueldo_base
        *
        dias_trabajados
    )

    return nomina_queries.update(
        id_nomina,
        data
    )


# ============================
# DELETE
# ============================

def delete_nomina(
    db,
    id_nomina
):

    nomina = nomina_queries.get_by_id(
        id_nomina
    )

    if not nomina:

        raise ValueError(
            "La nómina no existe"
        )

    return nomina_queries.delete(
        id_nomina
    )