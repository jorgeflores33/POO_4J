# ==========================================
# app/services/factura_pdf_service.py
# ==========================================

from reportlab.platypus import (

    SimpleDocTemplate,

    Table,

    TableStyle,

    Paragraph,

    Spacer
)

from reportlab.lib import colors

from reportlab.lib.styles import getSampleStyleSheet

from reportlab.lib.pagesizes import letter

from reportlab.platypus.flowables import HRFlowable

from reportlab.pdfbase import pdfmetrics

from reportlab.pdfbase.ttfonts import TTFont

from datetime import datetime

import os


# ==========================================
# GENERAR PDF FACTURA
# ==========================================

def generar_factura_pdf(data):

    try:

        # ======================================
        # CARPETA
        # ======================================

        carpeta = "app/uploads/facturas"

        os.makedirs(
            carpeta,
            exist_ok=True
        )


        # ======================================
        # NOMBRE PDF
        # ======================================

        folio = data.get(
            "folio",
            "FACTURA"
        )

        nombre_pdf = f"{folio}.pdf"

        ruta_pdf = os.path.join(
            carpeta,
            nombre_pdf
        )


        # ======================================
        # DOCUMENTO
        # ======================================

        doc = SimpleDocTemplate(

            ruta_pdf,

            pagesize=letter,

            rightMargin=30,

            leftMargin=30,

            topMargin=30,

            bottomMargin=30
        )


        elementos = []

        estilos = getSampleStyleSheet()


        # ======================================
        # HEADER
        # ======================================

        titulo = Paragraph(

            "<b>PAPELERÍA LABORANTE</b>",

            estilos["Title"]
        )

        elementos.append(
            titulo
        )

        elementos.append(
            Spacer(1, 10)
        )


        # ======================================
        # FACTURA
        # ======================================

        info = f"""

        <b>FACTURA:</b> {folio}<br/>

        <b>FECHA:</b>
        {datetime.now().strftime('%d/%m/%Y %H:%M')}<br/>

        <b>CLIENTE:</b>
        {data.get('cliente')}<br/>

        <b>RFC:</b>
        {data.get('rfc')}<br/>

        <b>USO CFDI:</b>
        {data.get('uso_cfdi')}<br/>

        <b>RÉGIMEN:</b>
        {data.get('regimen')}<br/>

        <b>DIRECCIÓN:</b>
        {data.get('direccion')}<br/>

        """

        elementos.append(

            Paragraph(
                info,
                estilos["BodyText"]
            )
        )

        elementos.append(
            Spacer(1, 15)
        )


        # ======================================
        # TABLA PRODUCTOS
        # ======================================

        tabla_data = [[

            "#",

            "CODIGO",

            "PRODUCTO",

            "CANT",

            "P.U.",

            "IMPORTE"
        ]]


        productos = data.get(
            "productos",
            []
        )


        for i, p in enumerate(productos):

            tabla_data.append([

                str(i + 1),

                p.get("codigo", ""),

                p.get("nombre", ""),

                str(p.get("cantidad", 0)),

                f"$ {float(p.get('precio', 0)):.2f}",

                f"$ {float(p.get('subtotal', 0)):.2f}"
            ])


        tabla = Table(

            tabla_data,

            colWidths=[
                30,
                70,
                190,
                50,
                60,
                80
            ]
        )


        tabla.setStyle(

            TableStyle([

                (
                    "BACKGROUND",
                    (0,0),
                    (-1,0),
                    colors.black
                ),

                (
                    "TEXTCOLOR",
                    (0,0),
                    (-1,0),
                    colors.white
                ),

                (
                    "FONTNAME",
                    (0,0),
                    (-1,0),
                    "Helvetica-Bold"
                ),

                (
                    "GRID",
                    (0,0),
                    (-1,-1),
                    1,
                    colors.black
                ),

                (
                    "FONTSIZE",
                    (0,0),
                    (-1,-1),
                    9
                ),

                (
                    "BACKGROUND",
                    (0,1),
                    (-1,-1),
                    colors.whitesmoke
                )
            ])
        )

        elementos.append(
            tabla
        )

        elementos.append(
            Spacer(1, 20)
        )


        # ======================================
        # TOTALES
        # ======================================

        subtotal = float(
            data.get("subtotal", 0)
        )

        iva = float(
            data.get("iva", 0)
        )

        total = float(
            data.get("total", 0)
        )


        totales = f"""

        <b>SUBTOTAL:</b>
        $ {subtotal:.2f}<br/><br/>

        <b>IVA:</b>
        $ {iva:.2f}<br/><br/>

        <b>TOTAL:</b>
        $ {total:.2f}

        """

        elementos.append(

            Paragraph(
                totales,
                estilos["BodyText"]
            )
        )


        elementos.append(
            Spacer(1, 30)
        )


        # ======================================
        # FOOTER
        # ======================================

        footer = Paragraph(

            "Gracias por su compra.",

            estilos["Italic"]
        )

        elementos.append(
            footer
        )


        # ======================================
        # GENERAR PDF
        # ======================================

        doc.build(
            elementos
        )


        return {

            "ok": True,

            "ruta_pdf":
            ruta_pdf,

            "nombre_pdf":
            nombre_pdf
        }


    except Exception as e:

        print(
            "ERROR PDF:",
            str(e)
        )

        return {

            "ok": False,

            "error":
            str(e)
        }