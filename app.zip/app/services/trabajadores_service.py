from app.models import trabajadores_queries


# ============================
# GET
# ============================

def get_trabajadores():
    return trabajadores_queries.get_all_trabajadores()


def get_trabajador_by_id(id_trabajador):
    trabajador = trabajadores_queries.get_trabajador_by_id(id_trabajador)

    if not trabajador:
        raise ValueError("Trabajador no encontrado")

    return trabajador


# ============================
# POST
# ============================

def create_trabajador(data):
    # Validaciones básicas
    if not data.get("nombre"):
        raise ValueError("El nombre es obligatorio")

    if data.get("salario") is None:
        raise ValueError("El salario es obligatorio")

    return trabajadores_queries.create_trabajador(data)


# ============================
# PUT
# ============================

def update_trabajador(id_trabajador, data):
    trabajador = trabajadores_queries.get_trabajador_by_id(id_trabajador)

    if not trabajador:
        raise ValueError("El trabajador no existe")

    if "nombre" in data and not data["nombre"]:
        raise ValueError("El nombre no puede estar vacío")

    if "salario" in data and data["salario"] is None:
        raise ValueError("El salario no puede ser nulo")

    return trabajadores_queries.update_trabajador(
        id_trabajador,
        data
    )


# ============================
# DELETE
# ============================

def delete_trabajador(id_trabajador):
    trabajador = trabajadores_queries.get_trabajador_by_id(id_trabajador)

    if not trabajador:
        raise ValueError("El trabajador no existe")

    return trabajadores_queries.delete_trabajador(id_trabajador)