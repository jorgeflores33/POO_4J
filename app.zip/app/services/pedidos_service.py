# app/services/pedidos_service.py

from app.models import pedidos_queries
from app.models import clientes_queries


# ============================
# GET
# ============================

def get_pedidos(db):
    return pedidos_queries.get_all_pedidos(db)


def get_pedido_by_id(db, id_pedido):
    pedido = pedidos_queries.get_pedido_by_id(db, id_pedido)
    
    if not pedido:
        raise ValueError("Pedido no encontrado")
    
    return pedido


# ============================
# POST
# ============================

def create_pedido(db, data):
    id_cliente = data.get("id_cliente")

    # Validar cliente
    if id_cliente:
        cliente = clientes_queries.get_cliente_by_id(db, id_cliente)
        if not cliente:
            raise ValueError("El cliente no existe")

    # Validar dirección
    if not data.get("direccion"):
        raise ValueError("La dirección es obligatoria")

    # Validar teléfono
    if not data.get("telefono"):
        raise ValueError("El teléfono es obligatorio")

    # Generar folio automático
    if not data.get("folio"):
        data["folio"] = f"PED-{id_cliente if id_cliente else 'GEN'}"

    return pedidos_queries.create_pedido(db, data)


# ============================
# PUT
# ============================

def update_pedido(db, id_pedido, data):
    pedido = pedidos_queries.get_pedido_by_id(db, id_pedido)
    
    if not pedido:
        raise ValueError("El pedido no existe")

    if "direccion" in data and not data["direccion"]:
        raise ValueError("La dirección no puede estar vacía")

    if "telefono" in data and not data["telefono"]:
        raise ValueError("El teléfono no puede estar vacío")

    return pedidos_queries.update_pedido(db, id_pedido, data)


# ============================
# DELETE
# ============================

def delete_pedido(db, id_pedido):
    pedido = pedidos_queries.get_pedido_by_id(db, id_pedido)
    
    if not pedido:
        raise ValueError("El pedido no existe")
    
    return pedidos_queries.delete_pedido(db, id_pedido)