# app/services/detalle_ventas_service.py
from app.models.detalle_ventas_queries import (
    delete_by_venta
)
from app.models import detalle_ventas_queries
from app.models import ventas_queries
from app.models import productos_sucursal_queries


# ============================
# GET
# ============================

def get_detalle_ventas(db):

    return detalle_ventas_queries.get_all()


def get_detalle_by_id(
    db,
    id_detalle
):

    detalle = detalle_ventas_queries.get_by_id(
        id_detalle
    )

    if not detalle:

        raise ValueError(
            "Detalle de venta no encontrado"
        )

    return detalle


# ==============================================
# GET → detalle por venta
# ==============================================

def get_detalle_by_venta(
    db,
    id_venta
):

    return detalle_ventas_queries.get_by_venta(
        id_venta
    )


# ============================
# POST
# ============================

def create_detalle_venta(
    db,
    data
):

    # =====================================
    # VALIDAR VENTA
    # =====================================

    if not data.get("id_venta"):

        raise ValueError(
            "El id_venta es obligatorio"
        )


    # =====================================
    # VALIDAR PRODUCTO
    # =====================================

    if not data.get("id_producto"):

        raise ValueError(
            "El id_producto es obligatorio"
        )


    # =====================================
    # VALIDAR CANTIDAD
    # =====================================

    cantidad = int(
        data.get("cantidad", 0)
    )

    if cantidad <= 0:

        raise ValueError(
            "La cantidad debe ser mayor a 0"
        )


    # =====================================
    # VALIDAR PRECIO
    # =====================================

    precio = data.get(
        "precio_unitario"
    )

    if (
        precio is None
        or
        float(precio) <= 0
    ):

        raise ValueError(
            "El precio unitario debe ser mayor a 0"
        )


    # =====================================
    # OBTENER VENTA
    # =====================================

    venta = ventas_queries.get_by_id(
        data["id_venta"]
    )

    if not venta:

        raise ValueError(
            "Venta no encontrada"
        )


    # =====================================
    # SUCURSAL
    # =====================================

    id_sucursal = venta[
        "id_sucursal"
    ]


    # =====================================
    # PRODUCTO SUCURSAL
    # =====================================

    producto_sucursal = (

        productos_sucursal_queries
        .get_by_id(

            data["id_producto"],

            id_sucursal
        )
    )

    if not producto_sucursal:

        raise ValueError(
            "El producto no existe en la sucursal"
        )


    # =====================================
    # EXISTENCIA ACTUAL
    # =====================================

    existencia_actual = int(

        producto_sucursal[
            "existencia"
        ]
    )


    # =====================================
    # VALIDAR STOCK
    # =====================================

    if cantidad > existencia_actual:

        raise ValueError(
            "Stock insuficiente"
        )


    # =====================================
    # CALCULAR SUBTOTAL
    # =====================================

    subtotal = (
        float(precio)
        *
        cantidad
    )

    data["subtotal"] = subtotal


    # =====================================
    # NUEVA EXISTENCIA
    # =====================================

    nueva_existencia = (

        existencia_actual
        -
        cantidad
    )


    # =====================================
    # ACTUALIZAR STOCK
    # =====================================

    productos_sucursal_queries.update(

        data["id_producto"],

        id_sucursal,

        {
            "existencia":
            nueva_existencia
        }
    )


    # =====================================
    # INSERTAR DETALLE
    # =====================================

    detalle = detalle_ventas_queries.insert(
        data
    )


    # =====================================
    # RETURN
    # =====================================

    return detalle


# ============================
# PUT
# ============================

def update_detalle_venta(
    db,
    id_detalle,
    data
):

    detalle = detalle_ventas_queries.get_by_id(
        id_detalle
    )

    if not detalle:

        raise ValueError(
            "El detalle no existe"
        )


    cantidad = int(

        data.get(
            "cantidad",
            detalle["cantidad"]
        )
    )


    precio = float(

        data.get(
            "precio_unitario",
            detalle["precio_unitario"]
        )
    )


    if cantidad <= 0:

        raise ValueError(
            "La cantidad debe ser mayor a 0"
        )


    if precio <= 0:

        raise ValueError(
            "El precio unitario debe ser mayor a 0"
        )


    # =====================================
    # RECALCULAR SUBTOTAL
    # =====================================

    data["subtotal"] = (
        precio
        *
        cantidad
    )


    return detalle_ventas_queries.update(
        id_detalle,
        data
    )

# =========================================
# DELETE POR VENTA
# =========================================

def delete_detalles_by_venta(
    db,
    id_venta
):

    return delete_by_venta(
        id_venta
    )

# ============================
# DELETE
# ============================

def delete_detalle_venta(
    db,
    id_detalle
):

    detalle = detalle_ventas_queries.get_by_id(
        id_detalle
    )

    if not detalle:

        raise ValueError(
            "El detalle no existe"
        )


    return detalle_ventas_queries.delete(
        id_detalle
    )

