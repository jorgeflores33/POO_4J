# app/services/ventas_service.py

from datetime import datetime

from app.models import ventas_queries
from app.models import clientes_queries
from app.models import usuarios_queries
from app.models import sucursales_queries
from app.models import detalle_ventas_queries
from app.models import productos_sucursal_queries


# ============================
# GET
# ============================

def get_ventas(db):

    return ventas_queries.get_all()


def get_venta_by_id(
    db,
    id_venta
):

    venta = ventas_queries.get_by_id(
        id_venta
    )

    if not venta:

        raise ValueError(
            "Venta no encontrada"
        )

    return venta


# ============================
# POST
# ============================

def create_venta(
    db,
    data
):

    id_cliente = data.get(
        "id_cliente"
    )

    id_usuario = data.get(
        "id_usuario"
    )

    id_sucursal = data.get(
        "id_sucursal"
    )


    # =====================================
    # VALIDAR CLIENTE
    # =====================================

    if id_cliente:

        cliente = clientes_queries.get_by_id(
            id_cliente
        )

        if not cliente:

            raise ValueError(
                "El cliente no existe"
            )


    # =====================================
    # VALIDAR USUARIO
    # =====================================

    usuario = usuarios_queries.get_by_id(
        id_usuario
    )

    if not usuario:

        raise ValueError(
            "El usuario no existe"
        )


    # =====================================
    # VALIDAR SUCURSAL
    # =====================================

    sucursal = sucursales_queries.get_by_id(
        id_sucursal
    )

    if not sucursal:

        raise ValueError(
            "La sucursal no existe"
        )


    # =====================================
    # VALIDAR TIPO VENTA
    # =====================================

    if not data.get("tipo_venta"):

        raise ValueError(
            "El tipo de venta es obligatorio"
        )


    # =====================================
    # VALIDAR FORMA PAGO
    # =====================================

    if not data.get("forma_pago"):

        raise ValueError(
            "La forma de pago es obligatoria"
        )


    # =====================================
    # VALIDAR TOTAL
    # =====================================

    total = data.get("total")

    if total is None:

        raise ValueError(
            "El total es obligatorio"
        )


    if float(total) < 0:

        raise ValueError(
            "El total no puede ser negativo"
        )


    # =====================================
    # GENERAR FOLIO
    # =====================================

    if not data.get("folio"):

        timestamp = int(
            datetime.now().timestamp()
        )

        data["folio"] = (

            f"V-"

            f"{id_sucursal}-"

            f"{id_usuario}-"

            f"{timestamp}"
        )


    return ventas_queries.insert(
        data
    )


# ==========================================
# VENTA COMPLETA
# ==========================================

def create_venta_completa(
    db,
    data
):

    productos = data.get(
        "productos",
        []
    )


    # =====================================
    # VALIDAR PRODUCTOS
    # =====================================

    if len(productos) == 0:

        raise ValueError(
            "No hay productos en la venta"
        )


    # =====================================
    # CALCULAR TOTAL
    # =====================================

    total = 0

    for producto in productos:

        cantidad = int(
            producto["cantidad"]
        )

        precio = float(
            producto["precio"]
        )

        subtotal = (
            cantidad
            *
            precio
        )

        total += subtotal


    # =====================================
    # CREAR VENTA
    # =====================================

    venta_data = {

        "id_cliente":
        data.get("id_cliente"),

        "id_usuario":
        data.get("id_usuario"),

        "id_sucursal":
        data.get("id_sucursal"),

        "tipo_venta":
        data.get("tipo_venta"),

        "forma_pago":
        data.get("forma_pago"),

        "total":
        total
    }


    venta = create_venta(
        db,
        venta_data
    )


    id_venta = venta[
        "id_venta"
    ]


    # =====================================
    # RECORRER PRODUCTOS
    # =====================================

    for producto in productos:

        id_producto = int(
            producto["id_producto"]
        )

        cantidad = int(
            producto["cantidad"]
        )

        precio = float(
            producto["precio"]
        )


        # =====================================
        # PRODUCTO SUCURSAL
        # =====================================

        producto_sucursal = (

            productos_sucursal_queries
            .get_by_id(

                id_producto,

                data["id_sucursal"]
            )
        )


        if not producto_sucursal:

            raise ValueError(

                f"Producto {id_producto} "

                f"no existe en sucursal"
            )


        existencia_actual = int(

            producto_sucursal[
                "existencia"
            ]
        )


        # =====================================
        # VALIDAR STOCK
        # =====================================

        if cantidad > existencia_actual:

            raise ValueError(

                f"Stock insuficiente "

                f"para producto {id_producto}"
            )


        # =====================================
        # NUEVA EXISTENCIA
        # =====================================

        nueva_existencia = (

            existencia_actual
            -
            cantidad
        )


        # =====================================
        # ACTUALIZAR STOCK
        # =====================================

        productos_sucursal_queries.update(

            id_producto,

            data["id_sucursal"],

            {
                "existencia":
                nueva_existencia
            }
        )


        # =====================================
        # INSERTAR DETALLE
        # =====================================

        detalle_ventas_queries.insert({

            "id_venta":
            id_venta,

            "id_producto":
            id_producto,

            "cantidad":
            cantidad,

            "precio_unitario":
            precio,

            "subtotal":
            cantidad * precio
        })


    # =====================================
    # RETURN
    # =====================================

    return {

        "ok": True,

        "mensaje":
        "Venta completada correctamente",

        "id_venta":
        id_venta
    }


# ============================
# PUT
# ============================

def update_venta(
    db,
    id_venta,
    data
):

    venta = ventas_queries.get_by_id(
        id_venta
    )

    if not venta:

        raise ValueError(
            "La venta no existe"
        )


    if (

        "total" in data

        and

        data["total"] is not None

        and

        float(data["total"]) < 0
    ):

        raise ValueError(
            "El total no puede ser negativo"
        )


    return ventas_queries.update(
        id_venta,
        data
    )


# ============================
# DELETE
# ============================

def delete_venta(
    db,
    id_venta
):

    venta = ventas_queries.get_by_id(
        id_venta
    )

    if not venta:

        raise ValueError(
            "La venta no existe"
        )


    return ventas_queries.delete(
        id_venta
    )

