# app/services/usuarios_service.py

from app.models import usuarios_queries


# ============================
# GET
# ============================

def get_usuarios(db):
    return usuarios_queries.get_all()


def get_usuario_by_id(db, id_usuario):

    usuario = usuarios_queries.get_by_id(id_usuario)

    if not usuario:
        raise ValueError("Usuario no encontrado")

    return usuario


# ============================
# POST
# ============================

def create_usuario(db, data):

    # Validaciones básicas
    if not data.get("usuario"):
        raise ValueError("El usuario es obligatorio")

    if not data.get("password"):
        raise ValueError("La contraseña es obligatoria")

    if not data.get("rol"):
        raise ValueError("El rol es obligatorio")

    # Validar usuario repetido
    existente = usuarios_queries.get_by_username(
        data["usuario"]
    )

    if existente:
        raise ValueError("El usuario ya existe")

    # Validar relación
    if not data.get("id_trabajador") and not data.get("id_cliente"):
        raise ValueError(
            "Debe asignarse a un trabajador o cliente"
        )

    return usuarios_queries.insert(data)


# ============================
# PUT
# ============================

def update_usuario(db, id_usuario, data):

    usuario = usuarios_queries.get_by_id(id_usuario)

    if not usuario:
        raise ValueError("El usuario no existe")

    # Validar username
    if "usuario" in data:

        if not data["usuario"]:
            raise ValueError(
                "El usuario no puede estar vacío"
            )

        existente = usuarios_queries.get_by_username(
            data["usuario"]
        )

        if existente and existente["id_usuario"] != id_usuario:
            raise ValueError(
                "El usuario ya está en uso"
            )

    # Validar password
    if "password" in data and not data["password"]:
        raise ValueError(
            "La contraseña no puede estar vacía"
        )

    # Validar rol
    if "rol" in data and not data["rol"]:
        raise ValueError(
            "El rol no puede estar vacío"
        )

    return usuarios_queries.update(
        id_usuario,
        data
    )


# ============================
# DELETE
# ============================

def delete_usuario(db, id_usuario):

    usuario = usuarios_queries.get_by_id(id_usuario)

    if not usuario:
        raise ValueError("El usuario no existe")

    return usuarios_queries.delete(id_usuario)
# ============================
# LOGIN
# ============================

def login_usuario(db, data):

    usuario = data.get("usuario")
    password = data.get("password")

    if not usuario:
        raise ValueError("El usuario es obligatorio")

    if not password:
        raise ValueError("La contraseña es obligatoria")

    user = usuarios_queries.login(
        usuario,
        password
    )

    if not user:
        return {
            "usuario": None
        }

    return {
        "usuario": user
    }