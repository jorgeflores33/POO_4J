from fastapi_mail import (

    FastMail,
    MessageSchema,
    ConnectionConfig
)

from dotenv import load_dotenv

import os


# ==========================================
# CARGAR .ENV
# ==========================================

load_dotenv()


# ==========================================
# CONFIGURACION SMTP
# ==========================================

conf = ConnectionConfig(

    MAIL_USERNAME=
    os.getenv("MAIL_USERNAME"),

    MAIL_PASSWORD=
    os.getenv("MAIL_PASSWORD"),

    MAIL_FROM=
    os.getenv("MAIL_FROM"),

    MAIL_PORT=
    int(os.getenv("MAIL_PORT")),

    MAIL_SERVER=
    os.getenv("MAIL_SERVER"),

    MAIL_STARTTLS=True,

    MAIL_SSL_TLS=False,

    USE_CREDENTIALS=True
)


# ==========================================
# ENVIAR CORREO
# ==========================================

async def enviar_correo(

    destino: str,

    archivo_pdf: str
):

    try:

        mensaje = MessageSchema(

            subject=
            "Factura Electrónica - Papelería Laborante",

            recipients=[destino],

            body="""

Gracias por su compra en Papelería Laborante.

Adjuntamos su factura electrónica en formato PDF.

Gracias por su preferencia.

Papelería Laborante
""",

            subtype="plain",

            attachments=[archivo_pdf]
        )

        fm = FastMail(conf)

        await fm.send_message(
            mensaje
        )

        return {

            "ok": True,

            "mensaje":
            "Correo enviado correctamente"
        }

    except Exception as e:

        print(
            "ERROR CORREO:",
            str(e)
        )

        return {

            "ok": False,

            "error":
            str(e)
        }