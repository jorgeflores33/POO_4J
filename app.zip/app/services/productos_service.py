# app/services/productos_service.py

from app.models import productos_queries


# ============================
# GET
# ============================

def get_productos(db):

    return productos_queries.get_all()


def get_producto_by_id(
    db,
    id_producto
):

    producto = productos_queries.get_by_id(
        id_producto
    )

    if not producto:

        raise ValueError(
            "Producto no encontrado"
        )

    return producto


# ============================
# POST
# ============================

def create_producto(
    db,
    data
):

    # Validar nombre
    if not data.get("nombre"):

        raise ValueError(
            "El nombre es obligatorio"
        )

    # Validar precio
    precio = data.get("precio")

    if (
        precio is None
        or
        float(precio) < 0
    ):

        raise ValueError(
            "El precio es inválido"
        )

    # generar código automático
    if not data.get("codigo"):

        nombre = data["nombre"][:3].upper()

        data["codigo"] = (
            f"PROD-{nombre}"
        )

    return productos_queries.insert(
        data
    )


# ============================
# PUT
# ============================

def update_producto(
    db,
    id_producto,
    data
):

    producto = productos_queries.get_by_id(
        id_producto
    )

    if not producto:

        raise ValueError(
            "El producto no existe"
        )

    if (
        "nombre" in data
        and
        not data["nombre"]
    ):

        raise ValueError(
            "El nombre no puede estar vacío"
        )

    if (
        "precio" in data
        and
        float(data["precio"]) < 0
    ):

        raise ValueError(
            "El precio no puede ser negativo"
        )

    return productos_queries.update(
        id_producto,
        data
    )


# ============================
# DELETE
# ============================

def delete_producto(
    db,
    id_producto
):

    producto = productos_queries.get_by_id(
        id_producto
    )

    if not producto:

        raise ValueError(
            "El producto no existe"
        )

    return productos_queries.delete(
        id_producto
    )