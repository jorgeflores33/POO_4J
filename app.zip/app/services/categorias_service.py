# app/services/categorias_service.py

from app.models import categorias_queries


# ============================
# GET
# ============================

def get_categorias(db):

    return categorias_queries.get_all()


def get_categoria_by_id(
    db,
    id_categoria
):

    categoria = categorias_queries.get_by_id(
        id_categoria
    )

    if not categoria:

        raise ValueError(
            "Categoría no encontrada"
        )

    return categoria


# ============================
# POST
# ============================

def create_categoria(
    db,
    data
):

    # Validar nombre
    if not data.get("nombre"):

        raise ValueError(
            "El nombre es obligatorio"
        )

    return categorias_queries.insert(
        data
    )


# ============================
# PUT
# ============================

def update_categoria(
    db,
    id_categoria,
    data
):

    categoria = categorias_queries.get_by_id(
        id_categoria
    )

    if not categoria:

        raise ValueError(
            "La categoría no existe"
        )

    if (
        "nombre" in data
        and
        not data["nombre"]
    ):

        raise ValueError(
            "El nombre no puede estar vacío"
        )

    return categorias_queries.update(
        id_categoria,
        data
    )


# ============================
# DELETE
# ============================

def delete_categoria(
    db,
    id_categoria
):

    categoria = categorias_queries.get_by_id(
        id_categoria
    )

    if not categoria:

        raise ValueError(
            "La categoría no existe"
        )

    return categorias_queries.delete(
        id_categoria
    )