# app/services/corte_caja_service.py

from app.models import corte_caja_queries


# ============================
# GET
# ============================

def get_cortes(db):

    return corte_caja_queries.get_all()


def get_corte_by_id(
    db,
    id_corte
):

    corte = corte_caja_queries.get_by_id(
        id_corte
    )

    if not corte:

        raise ValueError(
            "Corte de caja no encontrado"
        )

    return corte


# ============================
# POST
# ============================

def create_corte(
    db,
    data
):

    # Validar apertura
    if not data.get("id_apertura"):

        raise ValueError(
            "El id_apertura es obligatorio"
        )

    # Validar montos
    for campo in [
        "efectivo",
        "debito",
        "credito",
        "transferencia"
    ]:

        valor = float(
            data.get(campo, 0)
        )

        if valor < 0:

            raise ValueError(
                f"{campo} no puede ser negativo"
            )

    return corte_caja_queries.insert(
        data
    )


# ============================
# PUT
# ============================

def update_corte(
    db,
    id_corte,
    data
):

    corte = corte_caja_queries.get_by_id(
        id_corte
    )

    if not corte:

        raise ValueError(
            "El corte no existe"
        )

    # Validar montos
    for campo in [
        "efectivo",
        "debito",
        "credito",
        "transferencia"
    ]:

        if campo in data:

            valor = float(
                data.get(campo, 0)
            )

            if valor < 0:

                raise ValueError(
                    f"{campo} no puede ser negativo"
                )

    return corte_caja_queries.update(
        id_corte,
        data
    )


# ============================
# DELETE
# ============================

def delete_corte(
    db,
    id_corte
):

    corte = corte_caja_queries.get_by_id(
        id_corte
    )

    if not corte:

        raise ValueError(
            "El corte no existe"
        )

    return corte_caja_queries.delete(
        id_corte
    )