# app/services/facturas_proveedores_service.py

from app.models import facturas_proveedores_queries


# ============================
# GET
# ============================

def get_facturas_proveedores(db):

    return facturas_proveedores_queries.get_all()


def get_factura_proveedor_by_id(
    db,
    id_factura
):

    factura = facturas_proveedores_queries.get_by_id(
        id_factura
    )

    if not factura:

        raise ValueError(
            "Factura de proveedor no encontrada"
        )

    return factura


# ============================
# POST
# ============================

def create_factura_proveedor(
    db,
    data
):

    # Validar proveedor
    if not data.get("id_proveedor"):

        raise ValueError(
            "El id_proveedor es obligatorio"
        )

    # Validar total
    total = data.get("total")

    if (
        total is None
        or
        float(total) < 0
    ):

        raise ValueError(
            "El total es inválido"
        )

    # Generar folio automático
    if not data.get("folio"):

        data["folio"] = (
            f"FP-{data['id_proveedor']}"
        )

    return facturas_proveedores_queries.insert(
        data
    )


# ============================
# PUT
# ============================

def update_factura_proveedor(
    db,
    id_factura,
    data
):

    factura = facturas_proveedores_queries.get_by_id(
        id_factura
    )

    if not factura:

        raise ValueError(
            "La factura no existe"
        )

    if (
        "total" in data
        and
        float(data["total"]) < 0
    ):

        raise ValueError(
            "El total no puede ser negativo"
        )

    return facturas_proveedores_queries.update(
        id_factura,
        data
    )


# ============================
# DELETE
# ============================

def delete_factura_proveedor(
    db,
    id_factura
):

    factura = facturas_proveedores_queries.get_by_id(
        id_factura
    )

    if not factura:

        raise ValueError(
            "La factura no existe"
        )

    return facturas_proveedores_queries.delete(
        id_factura
    )