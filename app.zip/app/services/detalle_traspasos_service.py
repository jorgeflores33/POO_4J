# app/services/detalle_traspasos_service.py

from app.models import detalle_traspasos_queries


# ============================
# GET
# ============================

def get_detalles_traspasos(db):

    return detalle_traspasos_queries.get_all()


def get_detalle_by_id(
    db,
    id_detalle
):

    detalle = detalle_traspasos_queries.get_by_id(
        id_detalle
    )

    if not detalle:

        raise ValueError(
            "Detalle de traspaso no encontrado"
        )

    return detalle


# ============================
# POST
# ============================

def create_detalle_traspaso(
    db,
    data
):

    # Validar traspaso
    if not data.get("id_traspaso"):

        raise ValueError(
            "El id_traspaso es obligatorio"
        )

    # Validar producto
    if not data.get("id_producto"):

        raise ValueError(
            "El id_producto es obligatorio"
        )

    # Validar cantidad
    cantidad = data.get("cantidad")

    if (
        not cantidad
        or
        cantidad <= 0
    ):

        raise ValueError(
            "La cantidad debe ser mayor a 0"
        )

    return detalle_traspasos_queries.insert(
        data
    )


# ============================
# PUT
# ============================

def update_detalle_traspaso(
    db,
    id_detalle,
    data
):

    detalle = detalle_traspasos_queries.get_by_id(
        id_detalle
    )

    if not detalle:

        raise ValueError(
            "El detalle no existe"
        )

    cantidad = data.get(
        "cantidad",
        detalle["cantidad"]
    )

    if cantidad <= 0:

        raise ValueError(
            "La cantidad debe ser mayor a 0"
        )

    return detalle_traspasos_queries.update(
        id_detalle,
        data
    )


# ============================
# DELETE
# ============================

def delete_detalle_traspaso(
    db,
    id_detalle
):

    detalle = detalle_traspasos_queries.get_by_id(
        id_detalle
    )

    if not detalle:

        raise ValueError(
            "El detalle no existe"
        )

    return detalle_traspasos_queries.delete(
        id_detalle
    )