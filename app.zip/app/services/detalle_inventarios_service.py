# app/services/detalle_inventarios_service.py

from app.models import detalle_inventarios_queries
from app.models import productos_sucursal_queries
from app.models import inventarios_queries


# ============================
# GET
# ============================

def get_detalles_inventario(db):

    return detalle_inventarios_queries.get_all()



def get_detalle_by_id(
    db,
    id_detalle
):

    detalle = detalle_inventarios_queries.get_by_id(
        id_detalle
    )

    if not detalle:

        raise ValueError(
            "Detalle de inventario no encontrado"
        )

    return detalle



# ============================
# GET BY INVENTARIO
# ============================

def get_detalles_por_inventario(
    db,
    id_inventario
):

    return detalle_inventarios_queries.get_by_inventario(
        id_inventario
    )



# ============================
# POST
# ============================

def create_detalle_inventario(
    db,
    data
):

    # VALIDAR INVENTARIO
    if not data.get("id_inventario"):

        raise ValueError(
            "El id_inventario es obligatorio"
        )


    # VALIDAR PRODUCTO
    if not data.get("id_producto"):

        raise ValueError(
            "El id_producto es obligatorio"
        )


    # EXISTENCIAS
    existencia_sistema = data.get(
        "existencia_sistema"
    )

    existencia_fisica = data.get(
        "existencia_fisica"
    )


    if existencia_sistema is None:

        raise ValueError(
            "La existencia sistema es obligatoria"
        )


    if existencia_fisica is None:

        raise ValueError(
            "La existencia física es obligatoria"
        )


    # CALCULAR DIFERENCIA
    data["diferencia"] = (

        int(existencia_fisica)

        -

        int(existencia_sistema)
    )


    # =====================================
    # ACTUALIZAR EXISTENCIA REAL
    # =====================================

    inventario = inventarios_queries.get_by_id(

        data["id_inventario"]
    )


    id_sucursal = inventario[
        "id_sucursal"
    ]


    productos_sucursal_queries.update(

        int(data["id_producto"]),

        int(id_sucursal),

        {

            "existencia":
            int(existencia_fisica)
        }
    )


    # INSERTAR
    return detalle_inventarios_queries.insert(
        data
    )



# ============================
# PUT
# ============================

def update_detalle_inventario(
    db,
    id_detalle,
    data
):

    detalle = detalle_inventarios_queries.get_by_id(
        id_detalle
    )

    if not detalle:

        raise ValueError(
            "El detalle no existe"
        )


    existencia_sistema = data.get(

        "existencia_sistema",

        detalle["existencia_sistema"]
    )


    existencia_fisica = data.get(

        "existencia_fisica",

        detalle["existencia_fisica"]
    )


    # RECALCULAR DIFERENCIA
    data["diferencia"] = (

        int(existencia_fisica)

        -

        int(existencia_sistema)
    )


    # ACTUALIZAR DETALLE
    return detalle_inventarios_queries.update(

        id_detalle,

        data
    )



# ============================
# DELETE
# ============================

def delete_detalle_inventario(
    db,
    id_detalle
):

    detalle = detalle_inventarios_queries.get_by_id(
        id_detalle
    )

    if not detalle:

        raise ValueError(
            "El detalle no existe"
        )


    return detalle_inventarios_queries.delete(
        id_detalle
    )