# app/services/sucursales_service.py

from app.models import sucursales_queries


# ============================
# GET
# ============================

def get_sucursales(db):

    return sucursales_queries.get_all()


def get_sucursal_by_id(
    db,
    id_sucursal
):

    sucursal = sucursales_queries.get_by_id(
        id_sucursal
    )

    if not sucursal:

        raise ValueError(
            "Sucursal no encontrada"
        )

    return sucursal


# ============================
# POST
# ============================

def create_sucursal(
    db,
    data
):

    # Validar nombre
    if not data.get("nombre"):

        raise ValueError(
            "El nombre es obligatorio"
        )

    return sucursales_queries.insert(
        data
    )


# ============================
# PUT
# ============================

def update_sucursal(
    db,
    id_sucursal,
    data
):

    sucursal = sucursales_queries.get_by_id(
        id_sucursal
    )

    if not sucursal:

        raise ValueError(
            "La sucursal no existe"
        )

    if (
        "nombre" in data
        and
        not data["nombre"]
    ):

        raise ValueError(
            "El nombre no puede estar vacío"
        )

    return sucursales_queries.update(
        id_sucursal,
        data
    )


# ============================
# DELETE
# ============================

def delete_sucursal(
    db,
    id_sucursal
):

    sucursal = sucursales_queries.get_by_id(
        id_sucursal
    )

    if not sucursal:

        raise ValueError(
            "La sucursal no existe"
        )

    return sucursales_queries.delete(
        id_sucursal
    )