# app/services/productos_sucursal_service.py

from app.models import productos_sucursal_queries


# ============================
# GET
# ============================

def get_productos_sucursal(
    db
):

    return productos_sucursal_queries.get_all()


def get_producto_sucursal(

    db,

    id_producto,

    id_sucursal
):

    return productos_sucursal_queries.get_by_id(

        int(id_producto),

        int(id_sucursal)
    )


# ============================
# GET PRODUCTOS USUARIO
# ============================

def get_productos_usuario_service(

    db,

    usuario
):

    if not usuario:

        raise ValueError(
            "El usuario es obligatorio"
        )

    return (

        productos_sucursal_queries
        .get_productos_usuario(
            usuario
        )
    )


# ============================
# POST
# ============================

def create_producto_sucursal(

    db,

    data
):

    # =========================
    # VALIDAR PRODUCTO
    # =========================

    if not data.get("id_producto"):

        raise ValueError(
            "El id_producto es obligatorio"
        )


    # =========================
    # VALIDAR SUCURSAL
    # =========================

    if not data.get("id_sucursal"):

        raise ValueError(
            "El id_sucursal es obligatorio"
        )


    # =========================
    # EXISTENCIA
    # =========================

    existencia = int(

        data.get(
            "existencia",
            0
        )
    )


    if existencia < 0:

        raise ValueError(
            "La existencia no puede ser negativa"
        )


    # =========================
    # VALIDAR DUPLICADO
    # =========================

    existente = (

        productos_sucursal_queries
        .get_by_id(

            int(data["id_producto"]),

            int(data["id_sucursal"])
        )
    )


    if existente:

        raise ValueError(

            "El producto ya existe "
            "en esa sucursal"
        )


    # =========================
    # INSERT
    # =========================

    return productos_sucursal_queries.insert({

        "id_producto":
        int(data["id_producto"]),

        "id_sucursal":
        int(data["id_sucursal"]),

        "existencia":
        existencia
    })


# ============================
# PUT
# ============================

def update_producto_sucursal(

    db,

    id_producto,

    id_sucursal,

    data
):

    id_producto = int(
        id_producto
    )

    id_sucursal = int(
        id_sucursal
    )

    existencia = int(

        data.get(
            "existencia",
            0
        )
    )


    # =========================
    # VALIDAR EXISTENCIA
    # =========================

    if existencia < 0:

        raise ValueError(
            "La existencia no puede ser negativa"
        )


    # =========================
    # VALIDAR EXISTE
    # =========================

    producto = (

        productos_sucursal_queries
        .get_by_id(

            id_producto,

            id_sucursal
        )
    )


    if not producto:

        raise ValueError(

            "El producto sucursal "
            "no existe"
        )


    # =========================
    # UPDATE
    # =========================

    return productos_sucursal_queries.update(

        id_producto,

        id_sucursal,

        {
            "existencia":
            existencia
        }
    )


# ============================
# DELETE
# ============================

def delete_producto_sucursal(

    db,

    id_producto,

    id_sucursal
):

    producto = (

        productos_sucursal_queries
        .get_by_id(

            int(id_producto),

            int(id_sucursal)
        )
    )


    if not producto:

        raise ValueError(

            "El producto sucursal "
            "no existe"
        )


    return productos_sucursal_queries.delete(

        int(id_producto),

        int(id_sucursal)
    )


# ============================
# VALIDAR PRODUCTO SUCURSAL
# ============================

def validar_producto_sucursal(

    usuario,

    id_producto
):

    producto = (

        productos_sucursal_queries
        .validar_producto_usuario(

            usuario,

            int(id_producto)
        )
    )


    # =========================
    # NO EXISTE
    # =========================

    if not producto:

        return {

            "existe": False,

            "stock": 0
        }


    # =========================
    # EXISTE
    # =========================

    return {

        "existe": True,

        "stock":
        producto["existencia"],

        "producto":
        producto
    }

