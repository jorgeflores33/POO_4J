# app/services/asistencia_service.py

from app.models import asistencia_queries


# ============================
# GET
# ============================

def get_asistencias(db):

    return asistencia_queries.get_all()


def get_asistencia_by_id(
    db,
    id_asistencia
):

    asistencia = asistencia_queries.get_by_id(
        id_asistencia
    )

    if not asistencia:

        raise ValueError(
            "Asistencia no encontrada"
        )

    return asistencia


# ============================
# POST
# ============================

def create_asistencia(
    db,
    data
):

    # Validar trabajador
    if not data.get("id_trabajador"):

        raise ValueError(
            "El id_trabajador es obligatorio"
        )

    # Validar fecha
    if not data.get("fecha"):

        raise ValueError(
            "La fecha es obligatoria"
        )

    return asistencia_queries.insert(
        data
    )


# ============================
# PUT
# ============================

def update_asistencia(
    db,
    id_asistencia,
    data
):

    asistencia = asistencia_queries.get_by_id(
        id_asistencia
    )

    if not asistencia:

        raise ValueError(
            "La asistencia no existe"
        )

    return asistencia_queries.update(
        id_asistencia,
        data
    )


# ============================
# DELETE
# ============================

def delete_asistencia(
    db,
    id_asistencia
):

    asistencia = asistencia_queries.get_by_id(
        id_asistencia
    )

    if not asistencia:

        raise ValueError(
            "La asistencia no existe"
        )

    return asistencia_queries.delete(
        id_asistencia
    )