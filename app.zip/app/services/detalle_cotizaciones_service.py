# app/services/detalle_cotizaciones_service.py

from app.models import detalle_cotizaciones_queries


# ============================
# GET
# ============================

def get_detalles_cotizacion(db):

    return detalle_cotizaciones_queries.get_all()


def get_detalle_by_id(
    db,
    id_detalle
):

    detalle = detalle_cotizaciones_queries.get_by_id(
        id_detalle
    )

    if not detalle:

        raise ValueError(
            "Detalle de cotización no encontrado"
        )

    return detalle


# ============================
# POST
# ============================

def create_detalle_cotizacion(
    db,
    data
):

    # Validar cotización
    if not data.get("id_cotizacion"):

        raise ValueError(
            "El id_cotizacion es obligatorio"
        )

    # Validar producto
    if not data.get("id_producto"):

        raise ValueError(
            "El id_producto es obligatorio"
        )

    # Validar cantidad
    cantidad = data.get("cantidad")

    if (
        not cantidad
        or
        cantidad <= 0
    ):

        raise ValueError(
            "La cantidad debe ser mayor a 0"
        )

    # Validar precio
    precio = float(
        data.get("precio", 0)
    )

    if precio < 0:

        raise ValueError(
            "El precio no puede ser negativo"
        )

    # Calcular subtotal
    data["subtotal"] = (
        float(precio)
        *
        int(cantidad)
    )

    return detalle_cotizaciones_queries.insert(
        data
    )


# ============================
# PUT
# ============================

def update_detalle_cotizacion(
    db,
    id_detalle,
    data
):

    detalle = detalle_cotizaciones_queries.get_by_id(
        id_detalle
    )

    if not detalle:

        raise ValueError(
            "El detalle no existe"
        )

    cantidad = data.get(
        "cantidad",
        detalle["cantidad"]
    )

    precio = data.get(
        "precio",
        detalle["precio"]
    )

    if cantidad <= 0:

        raise ValueError(
            "La cantidad debe ser mayor a 0"
        )

    if float(precio) < 0:

        raise ValueError(
            "El precio no puede ser negativo"
        )

    # recalcular subtotal
    data["subtotal"] = (
        float(precio)
        *
        int(cantidad)
    )

    return detalle_cotizaciones_queries.update(
        id_detalle,
        data
    )


# ============================
# DELETE
# ============================

def delete_detalle_cotizacion(
    db,
    id_detalle
):

    detalle = detalle_cotizaciones_queries.get_by_id(
        id_detalle
    )

    if not detalle:

        raise ValueError(
            "El detalle no existe"
        )

    return detalle_cotizaciones_queries.delete(
        id_detalle
    )