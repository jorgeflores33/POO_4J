# app/services/proveedores_service.py

from app.models import proveedores_queries


# ============================
# GET
# ============================

def get_proveedores(db):

    return proveedores_queries.get_all()


def get_proveedor_by_id(db, id_proveedor):

    proveedor = proveedores_queries.get_by_id(
        id_proveedor
    )

    if not proveedor:
        raise ValueError(
            "Proveedor no encontrado"
        )

    return proveedor


# ============================
# POST
# ============================

def create_proveedor(db, data):

    # Validar nombre
    if not data.get("nombre"):

        raise ValueError(
            "El nombre es obligatorio"
        )

    # Teléfono o correo
    if (
        not data.get("telefono")
        and
        not data.get("correo")
    ):

        raise ValueError(
            "Debe ingresar teléfono o correo"
        )

    return proveedores_queries.insert(
        data
    )


# ============================
# PUT
# ============================

def update_proveedor(
    db,
    id_proveedor,
    data
):

    proveedor = proveedores_queries.get_by_id(
        id_proveedor
    )

    if not proveedor:

        raise ValueError(
            "Proveedor no encontrado"
        )

    if (
        "nombre" in data
        and
        not data["nombre"]
    ):

        raise ValueError(
            "El nombre no puede estar vacío"
        )

    return proveedores_queries.update(
        id_proveedor,
        data
    )


# ============================
# DELETE
# ============================

def delete_proveedor(
    db,
    id_proveedor
):

    proveedor = proveedores_queries.get_by_id(
        id_proveedor
    )

    if not proveedor:

        raise ValueError(
            "Proveedor no encontrado"
        )

    return proveedores_queries.delete(
        id_proveedor
    )