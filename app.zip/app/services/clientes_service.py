from app.models import clientes_queries


# ============================
# GET
# ============================

def get_clientes(db):

    return clientes_queries.get_all()


def get_cliente_by_id(db, id_cliente):

    cliente = clientes_queries.get_by_id(
        id_cliente
    )

    if not cliente:
        raise ValueError(
            "Cliente no encontrado"
        )

    return cliente


# ============================
# POST
# ============================

def create_cliente(db, data):

    # Validar nombre
    if not data.get("nombre"):
        raise ValueError(
            "El nombre es obligatorio"
        )

    # Validar teléfono o correo
    if not data.get("telefono") and not data.get("correo"):
        raise ValueError(
            "Debe proporcionar teléfono o correo"
        )

    # Validar RFC si hay régimen fiscal
    if data.get("regimen_fiscal") and not data.get("rfc"):
        raise ValueError(
            "Debe proporcionar RFC para asignar régimen fiscal"
        )

    return clientes_queries.insert(
        data
    )


# ============================
# PUT
# ============================

def update_cliente(
    db,
    id_cliente,
    data
):

    cliente = clientes_queries.get_by_id(
        id_cliente
    )

    if not cliente:
        raise ValueError(
            "El cliente no existe"
        )

    if "nombre" in data and not data["nombre"]:
        raise ValueError(
            "El nombre no puede estar vacío"
        )

    # Validar RFC si hay régimen fiscal
    if data.get("regimen_fiscal") and not data.get("rfc"):
        raise ValueError(
            "Debe proporcionar RFC para asignar régimen fiscal"
        )

    return clientes_queries.update(
        id_cliente,
        data
    )


# ============================
# DELETE
# ============================

def delete_cliente(
    db,
    id_cliente
):

    cliente = clientes_queries.get_by_id(
        id_cliente
    )

    if not cliente:
        raise ValueError(
            "El cliente no existe"
        )

    return clientes_queries.delete(
        id_cliente
    )