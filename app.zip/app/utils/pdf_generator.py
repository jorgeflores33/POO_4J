from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet


# =========================
# TICKET
# =========================
def generar_ticket_pdf(data, path):

    doc = SimpleDocTemplate(path)
    styles = getSampleStyleSheet()

    contenido = []

    contenido.append(Paragraph("TICKET DE VENTA", styles["Title"]))
    contenido.append(Spacer(1, 12))

    contenido.append(Paragraph(f"Folio: {data['folio']}", styles["Normal"]))
    contenido.append(Paragraph(f"Fecha: {data['fecha']}", styles["Normal"]))
    contenido.append(Paragraph(f"Cliente: {data.get('cliente','Mostrador')}", styles["Normal"]))
    contenido.append(Paragraph(f"Usuario: {data['usuario']}", styles["Normal"]))
    contenido.append(Paragraph(f"Sucursal: {data['sucursal']}", styles["Normal"]))
    contenido.append(Paragraph(f"Total: ${data['total']}", styles["Normal"]))

    doc.build(contenido)


# =========================
# FACTURA
# =========================
def generar_factura_pdf(data, path):

    doc = SimpleDocTemplate(path)
    styles = getSampleStyleSheet()

    contenido = []

    contenido.append(Paragraph("FACTURA", styles["Title"]))
    contenido.append(Spacer(1, 12))

    contenido.append(Paragraph(f"Folio: {data['folio']}", styles["Normal"]))
    contenido.append(Paragraph(f"Cliente: {data['cliente']}", styles["Normal"]))
    contenido.append(Paragraph(f"Subtotal: ${data['subtotal']}", styles["Normal"]))
    contenido.append(Paragraph(f"IVA: ${data['iva']}", styles["Normal"]))
    contenido.append(Paragraph(f"Total: ${data['total']}", styles["Normal"]))

    doc.build(contenido)