from pydantic import BaseModel
from typing import Optional
from datetime import datetime

# =========================
# BASE
# =========================
class InventarioBase(BaseModel):
    folio: Optional[str] = None
    id_sucursal: Optional[int] = None
    id_categoria: Optional[int] = None
    fecha: Optional[datetime] = None


# =========================
# CREATE (POST)
# =========================
class InventarioCreate(InventarioBase):
    pass


# =========================
# UPDATE (PUT)
# =========================
class InventarioUpdate(BaseModel):
    folio: Optional[str] = None
    id_sucursal: Optional[int] = None
    id_categoria: Optional[int] = None
    fecha: Optional[datetime] = None


# =========================
# RESPONSE (GET)
# =========================
class InventarioResponse(InventarioBase):
    id_inventario: int

    class Config:
        from_attributes = True