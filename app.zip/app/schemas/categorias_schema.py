from pydantic import BaseModel
from typing import Optional

# =========================
# BASE
# =========================
class CategoriaBase(BaseModel):
    nombre: Optional[str] = None


# =========================
# CREATE (POST)
# =========================
class CategoriaCreate(CategoriaBase):
    pass


# =========================
# UPDATE (PUT)
# =========================
class CategoriaUpdate(BaseModel):
    nombre: Optional[str] = None


# =========================
# RESPONSE (GET)
# =========================
class CategoriaResponse(CategoriaBase):
    id_categoria: int

    class Config:
        from_attributes = True