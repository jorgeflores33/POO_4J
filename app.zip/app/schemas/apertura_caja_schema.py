# app/schemas/apertura_caja_schema.py

from pydantic import BaseModel

from typing import Optional

from datetime import datetime


# =========================
# ESTADOS
# =========================

ESTADO_ABIERTA = "ABIERTA"

ESTADO_CERRADA = "CERRADA"


# =========================
# BASE
# =========================

class AperturaCajaBase(BaseModel):

    id_usuario: Optional[int] = None

    id_trabajador: Optional[int] = None

    id_sucursal: Optional[int] = None

    fecha: Optional[datetime] = None

    estado: Optional[str] = ESTADO_ABIERTA


# =========================
# CREATE (POST)
# =========================

class AperturaCajaCreate(
    AperturaCajaBase
):

    pass


# =========================
# UPDATE (PUT)
# =========================

class AperturaCajaUpdate(
    BaseModel
):

    id_usuario: Optional[int] = None

    id_trabajador: Optional[int] = None

    id_sucursal: Optional[int] = None

    fecha: Optional[datetime] = None

    estado: Optional[str] = None


# =========================
# RESPONSE (GET)
# =========================

class AperturaCajaResponse(
    AperturaCajaBase
):

    id_apertura: int


    class Config:

        from_attributes = True