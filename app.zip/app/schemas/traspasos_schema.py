from pydantic import BaseModel
from typing import Optional
from datetime import datetime

# =========================
# BASE
# =========================
class TraspasoBase(BaseModel):
    id_sucursal_origen: Optional[int] = None
    id_sucursal_destino: Optional[int] = None
    fecha: Optional[datetime] = None


# =========================
# CREATE (POST)
# =========================
class TraspasoCreate(TraspasoBase):
    pass


# =========================
# UPDATE (PUT)
# =========================
class TraspasoUpdate(BaseModel):
    id_sucursal_origen: Optional[int] = None
    id_sucursal_destino: Optional[int] = None
    fecha: Optional[datetime] = None


# =========================
# RESPONSE (GET)
# =========================
class TraspasoResponse(TraspasoBase):
    id_traspaso: int

    class Config:
        from_attributes = True