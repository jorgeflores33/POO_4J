from pydantic import BaseModel
from typing import Optional
from datetime import date

# =========================
# BASE
# =========================
class TrabajadorBase(BaseModel):
    nombre: str
    fecha_nacimiento: Optional[date] = None
    area: Optional[str] = None
    salario: Optional[float] = None


# =========================
# CREATE (POST)
# =========================
class TrabajadorCreate(TrabajadorBase):
    pass


# =========================
# UPDATE (PUT)
# =========================
class TrabajadorUpdate(BaseModel):
    nombre: Optional[str] = None
    fecha_nacimiento: Optional[date] = None
    area: Optional[str] = None
    salario: Optional[float] = None


# =========================
# RESPONSE (GET)
# =========================
class TrabajadorResponse(TrabajadorBase):
    id_trabajador: int

    class Config:
        from_attributes = True