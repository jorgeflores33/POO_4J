from pydantic import BaseModel
from typing import Optional

# =========================
# BASE
# =========================
class NominaBase(BaseModel):
    id_trabajador: Optional[int] = None
    id_asistencia: Optional[int] = None
    sueldo_base: Optional[float] = None
    dias_trabajados: Optional[int] = None
    total_pago: Optional[float] = None


# =========================
# CREATE (POST)
# =========================
class NominaCreate(NominaBase):
    pass


# =========================
# UPDATE (PUT)
# =========================
class NominaUpdate(BaseModel):
    id_trabajador: Optional[int] = None
    id_asistencia: Optional[int] = None
    sueldo_base: Optional[float] = None
    dias_trabajados: Optional[int] = None
    total_pago: Optional[float] = None


# =========================
# RESPONSE (GET)
# =========================
class NominaResponse(NominaBase):
    id_nomina: int

    class Config:
        from_attributes = True