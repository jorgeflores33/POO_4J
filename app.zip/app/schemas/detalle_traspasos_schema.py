from pydantic import BaseModel
from typing import Optional

# =========================
# BASE
# =========================
class DetalleTraspasoBase(BaseModel):
    id_traspaso: Optional[int] = None
    id_producto: Optional[int] = None
    cantidad: Optional[int] = None


# =========================
# CREATE (POST)
# =========================
class DetalleTraspasoCreate(DetalleTraspasoBase):
    pass


# =========================
# UPDATE (PUT)
# =========================
class DetalleTraspasoUpdate(BaseModel):
    id_traspaso: Optional[int] = None
    id_producto: Optional[int] = None
    cantidad: Optional[int] = None


# =========================
# RESPONSE (GET)
# =========================
class DetalleTraspasoResponse(DetalleTraspasoBase):
    id_detalle: int

    class Config:
        from_attributes = True