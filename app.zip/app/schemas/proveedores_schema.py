from pydantic import BaseModel
from typing import Optional

# =========================
# BASE
# =========================
class ProveedorBase(BaseModel):
    nombre: Optional[str] = None
    telefono: Optional[str] = None
    correo: Optional[str] = None
    direccion: Optional[str] = None
    folio: Optional[str] = None


# =========================
# CREATE (POST)
# =========================
class ProveedorCreate(ProveedorBase):
    pass


# =========================
# UPDATE (PUT)
# =========================
class ProveedorUpdate(BaseModel):
    nombre: Optional[str] = None
    telefono: Optional[str] = None
    correo: Optional[str] = None
    direccion: Optional[str] = None
    folio: Optional[str] = None


# =========================
# RESPONSE (GET)
# =========================
class ProveedorResponse(ProveedorBase):
    id_proveedor: int

    class Config:
        from_attributes = True