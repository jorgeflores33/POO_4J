from pydantic import BaseModel
from typing import Optional

# =========================
# BASE
# =========================
class DetalleInventarioBase(BaseModel):
    id_inventario: Optional[int] = None
    id_producto: Optional[int] = None
    existencia_sistema: Optional[int] = None
    existencia_fisica: Optional[int] = None
    diferencia: Optional[int] = None


# =========================
# CREATE (POST)
# =========================
class DetalleInventarioCreate(DetalleInventarioBase):
    pass


# =========================
# UPDATE (PUT)
# =========================
class DetalleInventarioUpdate(BaseModel):
    id_inventario: Optional[int] = None
    id_producto: Optional[int] = None
    existencia_sistema: Optional[int] = None
    existencia_fisica: Optional[int] = None
    diferencia: Optional[int] = None


# =========================
# RESPONSE (GET)
# =========================
class DetalleInventarioResponse(DetalleInventarioBase):
    id_detalle: int

    class Config:
        from_attributes = True