from pydantic import BaseModel
from typing import Optional

# =========================
# BASE
# =========================
class ClienteBase(BaseModel):
    nombre: Optional[str] = None
    telefono: Optional[str] = None
    correo: Optional[str] = None
    direccion: Optional[str] = None
    rfc: Optional[str] = None
    regimen_fiscal: Optional[str] = None
    codigo_postal: Optional[str] = None
    entidad: Optional[str] = None
    ciudad: Optional[str] = None
    folio: Optional[str] = None


# =========================
# CREATE (POST)
# =========================
class ClienteCreate(ClienteBase):
    pass


# =========================
# UPDATE (PUT)
# =========================
class ClienteUpdate(BaseModel):
    nombre: Optional[str] = None
    telefono: Optional[str] = None
    correo: Optional[str] = None
    direccion: Optional[str] = None
    rfc: Optional[str] = None
    regimen_fiscal: Optional[str] = None
    codigo_postal: Optional[str] = None
    entidad: Optional[str] = None
    ciudad: Optional[str] = None
    folio: Optional[str] = None


# =========================
# RESPONSE (GET)
# =========================
class ClienteResponse(ClienteBase):
    id_cliente: int

    class Config:
        from_attributes = True