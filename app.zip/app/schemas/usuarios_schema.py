# =========================================
# app/schemas/usuarios_schema.py
# =========================================

from pydantic import BaseModel
from typing import Optional


class UsuarioCreate(BaseModel):

    id_trabajador: Optional[int] = None
    id_cliente: Optional[int] = None

    usuario: str
    password: str
    rol: str


class UsuarioUpdate(BaseModel):

    id_trabajador: Optional[int] = None
    id_cliente: Optional[int] = None

    usuario: Optional[str] = None
    password: Optional[str] = None
    rol: Optional[str] = None

class LoginSchema(BaseModel):
    usuario: str
    password: str