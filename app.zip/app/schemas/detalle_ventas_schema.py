from pydantic import BaseModel
from typing import Optional

# =========================
# BASE
# =========================
class DetalleVentaBase(BaseModel):
    id_venta: Optional[int] = None
    id_producto: Optional[int] = None
    cantidad: Optional[int] = None
    precio_unitario: Optional[float] = None
    subtotal: Optional[float] = None


# =========================
# CREATE (POST)
# =========================
class DetalleVentaCreate(DetalleVentaBase):
    pass


# =========================
# UPDATE (PUT)
# =========================
class DetalleVentaUpdate(BaseModel):
    id_venta: Optional[int] = None
    id_producto: Optional[int] = None
    cantidad: Optional[int] = None
    precio_unitario: Optional[float] = None
    subtotal: Optional[float] = None


# =========================
# RESPONSE (GET)
# =========================
class DetalleVentaResponse(DetalleVentaBase):
    id_detalle: int

    class Config:
        from_attributes = True