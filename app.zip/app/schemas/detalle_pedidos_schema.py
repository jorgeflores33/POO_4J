from pydantic import BaseModel
from typing import Optional

# =========================
# BASE
# =========================
class DetallePedidoBase(BaseModel):
    id_pedido: Optional[int] = None
    id_producto: Optional[int] = None
    cantidad: Optional[int] = None
    precio_unitario: Optional[float] = None
    subtotal: Optional[float] = None


# =========================
# CREATE (POST)
# =========================
class DetallePedidoCreate(DetallePedidoBase):
    pass


# =========================
# UPDATE (PUT)
# =========================
class DetallePedidoUpdate(BaseModel):
    id_pedido: Optional[int] = None
    id_producto: Optional[int] = None
    cantidad: Optional[int] = None
    precio_unitario: Optional[float] = None
    subtotal: Optional[float] = None


# =========================
# RESPONSE (GET)
# =========================
class DetallePedidoResponse(DetallePedidoBase):
    id_detalle: int

    class Config:
        from_attributes = True