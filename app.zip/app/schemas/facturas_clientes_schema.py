from pydantic import BaseModel
from typing import Optional
from datetime import datetime
from typing import List


# =========================
# BASE
# =========================
class FacturaClienteBase(BaseModel):

    id_cliente: Optional[int] = None

    id_venta: Optional[int] = None

    folio: Optional[str] = None

    uso_cfdi: Optional[str] = None

    correo: Optional[str] = None

    subtotal: Optional[float] = None

    iva: Optional[float] = None

    total: Optional[float] = None

    fecha: Optional[datetime] = None


# =========================
# CREATE (POST)
# =========================
class FacturaClienteCreate(
    FacturaClienteBase
):

    pass


# =========================
# UPDATE (PUT)
# =========================
class FacturaClienteUpdate(
    BaseModel
):

    id_cliente: Optional[int] = None

    id_venta: Optional[int] = None

    folio: Optional[str] = None

    uso_cfdi: Optional[str] = None

    correo: Optional[str] = None

    subtotal: Optional[float] = None

    iva: Optional[float] = None

    total: Optional[float] = None

    fecha: Optional[datetime] = None


# =========================
# RESPONSE (GET)
# =========================
class FacturaClienteResponse(
    FacturaClienteBase
):

    id_factura: int

    class Config:

        from_attributes = True

# ==========================================
# SCHEMA PRODUCTO PDF
# ==========================================

class ProductoPDF(BaseModel):

    codigo: str

    nombre: str

    cantidad: int

    precio: float

    subtotal: float


# ==========================================
# SCHEMA FACTURA PDF
# ==========================================

class FacturaPDFSchema(BaseModel):

    folio: str

    cliente: str

    rfc: str

    uso_cfdi: str

    regimen: str

    direccion: str

    subtotal: float

    iva: float

    total: float

    productos: List[ProductoPDF]