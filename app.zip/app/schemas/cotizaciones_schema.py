from pydantic import BaseModel
from typing import Optional
from datetime import datetime

# =========================
# BASE
# =========================
class CotizacionBase(BaseModel):
    id_cliente: Optional[int] = None
    fecha: Optional[datetime] = None
    folio: Optional[str] = None


# =========================
# CREATE (POST)
# =========================
class CotizacionCreate(CotizacionBase):
    pass


# =========================
# UPDATE (PUT)
# =========================
class CotizacionUpdate(BaseModel):
    id_cliente: Optional[int] = None
    fecha: Optional[datetime] = None
    folio: Optional[str] = None


# =========================
# RESPONSE (GET)
# =========================
class CotizacionResponse(CotizacionBase):
    id_cotizacion: int

    class Config:
        from_attributes = True