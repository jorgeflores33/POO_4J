from pydantic import BaseModel
from typing import Optional

# =========================
# BASE
# =========================
class DetalleCotizacionBase(BaseModel):
    id_cotizacion: Optional[int] = None
    id_producto: Optional[int] = None
    cantidad: Optional[int] = None
    precio: Optional[float] = None
    subtotal: Optional[float] = None


# =========================
# CREATE (POST)
# =========================
class DetalleCotizacionCreate(DetalleCotizacionBase):
    pass


# =========================
# UPDATE (PUT)
# =========================
class DetalleCotizacionUpdate(BaseModel):
    id_cotizacion: Optional[int] = None
    id_producto: Optional[int] = None
    cantidad: Optional[int] = None
    precio: Optional[float] = None
    subtotal: Optional[float] = None


# =========================
# RESPONSE (GET)
# =========================
class DetalleCotizacionResponse(DetalleCotizacionBase):
    id_detalle: int

    class Config:
        from_attributes = True