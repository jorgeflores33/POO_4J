from pydantic import BaseModel
from typing import Optional
from datetime import date

# =========================
# BASE
# =========================
class FacturaProveedorBase(BaseModel):
    id_proveedor: Optional[int] = None
    folio: Optional[str] = None
    fecha: Optional[date] = None
    total: Optional[float] = None


# =========================
# CREATE (POST)
# =========================
class FacturaProveedorCreate(FacturaProveedorBase):
    pass


# =========================
# UPDATE (PUT)
# =========================
class FacturaProveedorUpdate(BaseModel):
    id_proveedor: Optional[int] = None
    folio: Optional[str] = None
    fecha: Optional[date] = None
    total: Optional[float] = None


# =========================
# RESPONSE (GET)
# =========================
class FacturaProveedorResponse(FacturaProveedorBase):
    id_factura: int

    class Config:
        from_attributes = True