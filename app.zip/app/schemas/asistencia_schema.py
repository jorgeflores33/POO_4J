from pydantic import BaseModel
from typing import Optional
from datetime import date, time

# =========================
# BASE
# =========================
class AsistenciaBase(BaseModel):
    id_trabajador: Optional[int] = None
    fecha: Optional[date] = None
    hora_entrada: Optional[time] = None
    hora_salida: Optional[time] = None


# =========================
# CREATE (POST)
# =========================
class AsistenciaCreate(AsistenciaBase):
    pass


# =========================
# UPDATE (PUT)
# =========================
class AsistenciaUpdate(BaseModel):
    id_trabajador: Optional[int] = None
    fecha: Optional[date] = None
    hora_entrada: Optional[time] = None
    hora_salida: Optional[time] = None


# =========================
# RESPONSE (GET)
# =========================
class AsistenciaResponse(AsistenciaBase):
    id_asistencia: int

    class Config:
        from_attributes = True