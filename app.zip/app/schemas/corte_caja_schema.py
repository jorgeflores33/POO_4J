from pydantic import BaseModel
from typing import Optional


# =========================
# BASE
# =========================
class CorteCajaBase(BaseModel):

    id_apertura: Optional[int] = None

    efectivo: Optional[float] = 0

    debito: Optional[float] = 0

    credito: Optional[float] = 0

    transferencia: Optional[float] = 0

    total_ventas: Optional[float] = 0

    diferencia: Optional[float] = 0

# =========================
# CREATE
# =========================

class CorteCajaCreate(
    CorteCajaBase
):
    pass


# =========================
# UPDATE
# =========================

class CorteCajaUpdate(
    BaseModel
):

    id_apertura: Optional[int] = None

    efectivo: Optional[float] = None

    debito: Optional[float] = None

    credito: Optional[float] = None

    transferencia: Optional[float] = None

    total_ventas: Optional[float] = None

    diferencia: Optional[float] = None


# =========================
# RESPONSE
# =========================

class CorteCajaResponse(
    CorteCajaBase
):

    id_corte: int

    class Config:

        from_attributes = True