from pydantic import BaseModel
from typing import Optional

# =========================
# BASE
# =========================
class ProductoBase(BaseModel):
    id_categoria: Optional[int] = None
    nombre: Optional[str] = None
    descripcion: Optional[str] = None
    codigo: Optional[str] = None
    precio: Optional[float] = None
    imagen_url: Optional[str] = None


# =========================
# CREATE (POST)
# =========================
class ProductoCreate(ProductoBase):
    pass


# =========================
# UPDATE (PUT)
# =========================
class ProductoUpdate(BaseModel):
    id_categoria: Optional[int] = None
    nombre: Optional[str] = None
    descripcion: Optional[str] = None
    codigo: Optional[str] = None
    precio: Optional[float] = None
    imagen_url: Optional[str] = None


# =========================
# RESPONSE (GET)
# =========================
class ProductoResponse(ProductoBase):
    id_producto: int

    class Config:
        from_attributes = True