from pydantic import BaseModel
from typing import Optional

# =========================
# BASE
# =========================
class SucursalBase(BaseModel):
    nombre: Optional[str] = None
    direccion: Optional[str] = None
    telefono: Optional[str] = None
    activo: Optional[bool] = True


# =========================
# CREATE (POST)
# =========================
class SucursalCreate(SucursalBase):
    pass


# =========================
# UPDATE (PUT)
# =========================
class SucursalUpdate(BaseModel):
    nombre: Optional[str] = None
    direccion: Optional[str] = None
    telefono: Optional[str] = None
    activo: Optional[bool] = None


# =========================
# RESPONSE (GET)
# =========================
class SucursalResponse(SucursalBase):
    id_sucursal: int

    class Config:
        from_attributes = True