from pydantic import BaseModel


# CREATE
class ProductoSucursalCreate(BaseModel):

    id_producto: int
    id_sucursal: int
    existencia: int


# UPDATE
class ProductoSucursalUpdate(BaseModel):

    existencia: int