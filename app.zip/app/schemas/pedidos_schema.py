from pydantic import BaseModel
from typing import Optional
from datetime import datetime

# =========================
# BASE
# =========================
class PedidoBase(BaseModel):
    id_cliente: Optional[int] = None
    folio: Optional[str] = None
    fecha: Optional[datetime] = None
    direccion: Optional[str] = None
    telefono: Optional[str] = None


# =========================
# CREATE (POST)
# =========================
class PedidoCreate(PedidoBase):
    pass


# =========================
# UPDATE (PUT)
# =========================
class PedidoUpdate(BaseModel):
    id_cliente: Optional[int] = None
    folio: Optional[str] = None
    fecha: Optional[datetime] = None
    direccion: Optional[str] = None
    telefono: Optional[str] = None


# =========================
# RESPONSE (GET)
# =========================
class PedidoResponse(PedidoBase):
    id_pedido: int

    class Config:
        from_attributes = True