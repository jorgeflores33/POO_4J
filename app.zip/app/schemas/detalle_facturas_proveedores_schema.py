from pydantic import BaseModel
from typing import Optional

# =========================
# BASE
# =========================
class DetalleFacturaProveedorBase(BaseModel):
    id_factura: Optional[int] = None
    codigo_producto: Optional[str] = None
    cantidad: Optional[int] = None
    precio_unitario: Optional[float] = None
    subtotal: Optional[float] = None


# =========================
# CREATE (POST)
# =========================
class DetalleFacturaProveedorCreate(DetalleFacturaProveedorBase):
    pass


# =========================
# UPDATE (PUT)
# =========================
class DetalleFacturaProveedorUpdate(BaseModel):
    id_factura: Optional[int] = None
    codigo_producto: Optional[str] = None
    cantidad: Optional[int] = None
    precio_unitario: Optional[float] = None
    subtotal: Optional[float] = None


# =========================
# RESPONSE (GET)
# =========================
class DetalleFacturaProveedorResponse(DetalleFacturaProveedorBase):
    id_detalle: int

    class Config:
        from_attributes = True