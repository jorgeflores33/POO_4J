from pydantic import BaseModel
from typing import Optional
from datetime import datetime

# =========================
# BASE
# =========================
class VentaBase(BaseModel):
    id_cliente: Optional[int] = None
    id_usuario: Optional[int] = None
    id_sucursal: Optional[int] = None
    tipo_venta: Optional[str] = None
    forma_pago: Optional[str] = None
    total: Optional[float] = None
    fecha: Optional[datetime] = None
    folio: Optional[str] = None


# =========================
# CREATE (POST)
# =========================
class VentaCreate(VentaBase):
    pass


# =========================
# UPDATE (PUT)
# =========================
class VentaUpdate(BaseModel):
    id_cliente: Optional[int] = None
    id_usuario: Optional[int] = None
    id_sucursal: Optional[int] = None
    tipo_venta: Optional[str] = None
    forma_pago: Optional[str] = None
    total: Optional[float] = None
    fecha: Optional[datetime] = None
    folio: Optional[str] = None


# =========================
# RESPONSE (GET)
# =========================
class VentaResponse(VentaBase):
    id_venta: int

    class Config:
        from_attributes = True