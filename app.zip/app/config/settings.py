class Settings:
    DATABASE_URL = "mysql+pymysql://root:@localhost/papeleria"

settings = Settings()