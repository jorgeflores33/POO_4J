from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

# 🔥 SERVIR ARCHIVOS ESTATICOS

# ==============================
# IMPORTAR ROUTERS
# ==============================

from app.controllers.trabajadores_router import router as trabajadores_router
from app.controllers.clientes_router import router as clientes_router
from app.controllers.proveedores_router import router as proveedores_router
from app.controllers.sucursales_router import router as sucursales_router
from app.controllers.categorias_router import router as categorias_router
from app.controllers.usuarios_router import router as usuarios_router
from app.controllers.productos_router import router as productos_router
from app.controllers.productos_sucursal_router import router as productos_sucursal_router
from app.controllers.asistencia_router import router as asistencia_router
from app.controllers.nomina_router import router as nomina_router
from app.controllers.ventas_router import router as ventas_router
from app.controllers.detalle_ventas_router import router as detalle_ventas_router
from app.controllers.facturas_clientes_router import router as facturas_clientes_router
from app.controllers.facturas_proveedores_router import router as facturas_proveedores_router
from app.controllers.detalle_facturas_proveedores_router import router as detalle_facturas_proveedores_router
from app.controllers.apertura_caja_router import router as apertura_caja_router
from app.controllers.corte_caja_router import router as corte_caja_router
from app.controllers.cotizaciones_router import router as cotizaciones_router
from app.controllers.detalle_cotizaciones_router import router as detalle_cotizaciones_router
from app.controllers.pedidos_router import router as pedidos_router
from app.controllers.detalle_pedidos_router import router as detalle_pedidos_router
from app.controllers.traspasos_router import router as traspasos_router
from app.controllers.detalle_traspasos_router import router as detalle_traspasos_router
from app.controllers.inventarios_router import router as inventarios_router
from app.controllers.detalle_inventarios_router import router as detalle_inventarios_router

# ==========================================
# 🔥 NUEVO ROUTER CORREO
# ==========================================

from app.controllers.correo_router import router as correo_router


# ==============================
# APP
# ==============================

app = FastAPI(
    title="Sistema ERP Papeleria",
    version="1.0.0"
)


# 🔥 SERVIR ARCHIVOS ESTATICOS

app.mount(
    "/front",
    StaticFiles(directory="front"),
    name="front"
)


# ==============================
# CORS
# ==============================

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ==============================
# REGISTRAR ROUTERS
# ==============================

app.include_router(trabajadores_router)
app.include_router(clientes_router)
app.include_router(proveedores_router)
app.include_router(sucursales_router)
app.include_router(categorias_router)
app.include_router(usuarios_router)
app.include_router(productos_router)
app.include_router(productos_sucursal_router)
app.include_router(asistencia_router)
app.include_router(nomina_router)
app.include_router(ventas_router)
app.include_router(detalle_ventas_router)
app.include_router(facturas_clientes_router)
app.include_router(facturas_proveedores_router)
app.include_router(detalle_facturas_proveedores_router)
app.include_router(apertura_caja_router)
app.include_router(corte_caja_router)
app.include_router(cotizaciones_router)
app.include_router(detalle_cotizaciones_router)
app.include_router(pedidos_router)
app.include_router(detalle_pedidos_router)
app.include_router(traspasos_router)
app.include_router(detalle_traspasos_router)
app.include_router(inventarios_router)
app.include_router(detalle_inventarios_router)

# ==========================================
# 🔥 NUEVO ROUTER CORREO
# ==========================================

app.include_router(correo_router)


# ==============================
# RUTA PRINCIPAL
# ==============================

@app.get("/")
def root():

    return {

        "mensaje":
        "API ERP Papeleria funcionando correctamente"
    }