from app.db.database import get_connection


# ==============================
# GET → obtener todos
# ==============================
def get_all():

    conn = get_connection()

    cursor = conn.cursor(
        dictionary=True
    )

    cursor.execute(
        "SELECT * FROM facturas_clientes"
    )

    result = cursor.fetchall()

    conn.close()

    return result


# ==============================
# GET → obtener por ID
# ==============================
def get_by_id(id_factura: int):

    conn = get_connection()

    cursor = conn.cursor(
        dictionary=True
    )

    sql = """

        SELECT *

        FROM facturas_clientes

        WHERE id_factura = %s
    """

    cursor.execute(
        sql,
        (id_factura,)
    )

    result = cursor.fetchone()

    conn.close()

    return result


# ==============================
# POST → insertar
# ==============================
def insert(data: dict):

    conn = get_connection()

    cursor = conn.cursor()

    sql = """

        INSERT INTO facturas_clientes (

            id_cliente,
            id_venta,
            folio,
            uso_cfdi,
            subtotal,
            iva,
            total
        )

        VALUES (

            %s,
            %s,
            %s,
            %s,
            %s,
            %s,
            %s
        )
    """

    cursor.execute(

        sql,

        (

            data.get("id_cliente"),

            data.get("id_venta"),

            data.get("folio"),

            data.get("uso_cfdi"),

            data.get("subtotal"),

            data.get("iva"),

            data.get("total")
        )
    )

    # ==================================
    # OBTENER ID FACTURA
    # ==================================

    id_factura = cursor.lastrowid

    conn.commit()

    conn.close()

    return {

        "mensaje":

        "Factura de cliente creada correctamente",

        "id_factura":
        id_factura
    }


# ==============================
# PUT → actualizar
# ==============================
def update(
    id_factura: int,
    data: dict
):

    conn = get_connection()

    cursor = conn.cursor()

    sql = """

        UPDATE facturas_clientes

        SET

            id_cliente = %s,

            id_venta = %s,

            folio = %s,

            uso_cfdi = %s,

            subtotal = %s,

            iva = %s,

            total = %s

        WHERE id_factura = %s
    """

    cursor.execute(

        sql,

        (

            data.get("id_cliente"),

            data.get("id_venta"),

            data.get("folio"),

            data.get("uso_cfdi"),

            data.get("subtotal"),

            data.get("iva"),

            data.get("total"),

            id_factura
        )
    )

    conn.commit()

    conn.close()

    return {

        "mensaje":

        "Factura de cliente actualizada correctamente"
    }


# ==============================
# DELETE → eliminar
# ==============================
def delete(id_factura: int):

    conn = get_connection()

    cursor = conn.cursor()

    sql = """

        DELETE FROM facturas_clientes

        WHERE id_factura = %s
    """

    cursor.execute(
        sql,
        (id_factura,)
    )

    conn.commit()

    conn.close()

    return {

        "mensaje":

        "Factura de cliente eliminada correctamente"
    }