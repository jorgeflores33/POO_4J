from app.db.database import get_connection

# ==============================
# GET → obtener todos
# ==============================
def get_all():
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT * FROM proveedores")
    result = cursor.fetchall()

    conn.close()
    return result


# ==============================
# GET → obtener por ID
# ==============================
def get_by_id(id_proveedor: int):
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    sql = "SELECT * FROM proveedores WHERE id_proveedor = %s"
    cursor.execute(sql, (id_proveedor,))

    result = cursor.fetchone()

    conn.close()
    return result


# ==============================
# POST → insertar
# ==============================
def insert(data: dict):
    conn = get_connection()
    cursor = conn.cursor()

    sql = """
        INSERT INTO proveedores (
            nombre, telefono, correo, direccion, folio
        )
        VALUES (%s, %s, %s, %s, %s)
    """

    cursor.execute(sql, (
        data.get("nombre"),
        data.get("telefono"),
        data.get("correo"),
        data.get("direccion"),
        data.get("folio")
    ))

    conn.commit()
    conn.close()

    return {"mensaje": "Proveedor creado correctamente"}


# ==============================
# PUT → actualizar
# ==============================
def update(id_proveedor: int, data: dict):
    conn = get_connection()
    cursor = conn.cursor()

    sql = """
        UPDATE proveedores
        SET nombre = %s,
            telefono = %s,
            correo = %s,
            direccion = %s,
            folio = %s
        WHERE id_proveedor = %s
    """

    cursor.execute(sql, (
        data.get("nombre"),
        data.get("telefono"),
        data.get("correo"),
        data.get("direccion"),
        data.get("folio"),
        id_proveedor
    ))

    conn.commit()
    conn.close()

    return {"mensaje": "Proveedor actualizado correctamente"}


# ==============================
# DELETE → eliminar
# ==============================
def delete(id_proveedor: int):
    conn = get_connection()
    cursor = conn.cursor()

    sql = "DELETE FROM proveedores WHERE id_proveedor = %s"
    cursor.execute(sql, (id_proveedor,))

    conn.commit()
    conn.close()

    return {"mensaje": "Proveedor eliminado correctamente"}