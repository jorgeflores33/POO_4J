from app.db.database import get_connection

# ==============================
# GET → obtener todos
# ==============================
def get_all():
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT * FROM detalle_pedidos")
    result = cursor.fetchall()

    conn.close()
    return result


# ==============================
# GET → obtener por ID
# ==============================
def get_by_id(id_detalle: int):
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    sql = "SELECT * FROM detalle_pedidos WHERE id_detalle = %s"
    cursor.execute(sql, (id_detalle,))

    result = cursor.fetchone()

    conn.close()
    return result


# ==============================
# POST → insertar
# ==============================
def insert(data: dict):
    conn = get_connection()
    cursor = conn.cursor()

    sql = """
        INSERT INTO detalle_pedidos (
            id_pedido, id_producto, cantidad,
            precio_unitario, subtotal
        )
        VALUES (%s, %s, %s, %s, %s)
    """

    cursor.execute(sql, (
        data.get("id_pedido"),
        data.get("id_producto"),
        data.get("cantidad"),
        data.get("precio_unitario"),
        data.get("subtotal")
    ))

    conn.commit()
    conn.close()

    return {"mensaje": "Detalle de pedido creado correctamente"}


# ==============================
# PUT → actualizar
# ==============================
def update(id_detalle: int, data: dict):
    conn = get_connection()
    cursor = conn.cursor()

    sql = """
        UPDATE detalle_pedidos
        SET id_pedido = %s,
            id_producto = %s,
            cantidad = %s,
            precio_unitario = %s,
            subtotal = %s
        WHERE id_detalle = %s
    """

    cursor.execute(sql, (
        data.get("id_pedido"),
        data.get("id_producto"),
        data.get("cantidad"),
        data.get("precio_unitario"),
        data.get("subtotal"),
        id_detalle
    ))

    conn.commit()
    conn.close()

    return {"mensaje": "Detalle de pedido actualizado correctamente"}
# ==============================
# DELETE → eliminar
# ==============================
def delete(id_detalle: int):
    conn = get_connection()
    cursor = conn.cursor()

    sql = "DELETE FROM detalle_pedidos WHERE id_detalle = %s"
    cursor.execute(sql, (id_detalle,))

    conn.commit()
    conn.close()

    return {"mensaje": "Detalle de pedido eliminado correctamente"}