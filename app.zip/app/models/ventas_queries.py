
from app.db.database import get_connection


# ==============================
# GET → obtener todos
# ==============================

def get_all():

    conn = get_connection()

    cursor = conn.cursor(
        dictionary=True
    )

    sql = """

        SELECT

            v.*,

            c.nombre AS nombre_cliente,

            u.usuario,

            s.nombre AS nombre_sucursal

        FROM ventas v

        LEFT JOIN clientes c
        ON v.id_cliente = c.id_cliente

        INNER JOIN usuarios u
        ON v.id_usuario = u.id_usuario

        INNER JOIN sucursales s
        ON v.id_sucursal = s.id_sucursal

        ORDER BY v.id_venta DESC
    """

    cursor.execute(sql)

    result = cursor.fetchall()

    conn.close()

    return result


# ==============================
# GET → obtener por ID
# ==============================

def get_by_id(
    id_venta: int
):

    conn = get_connection()

    cursor = conn.cursor(
        dictionary=True
    )

    sql = """

        SELECT

            v.*,

            c.nombre AS nombre_cliente,

            u.usuario,

            s.nombre AS nombre_sucursal

        FROM ventas v

        LEFT JOIN clientes c
        ON v.id_cliente = c.id_cliente

        INNER JOIN usuarios u
        ON v.id_usuario = u.id_usuario

        INNER JOIN sucursales s
        ON v.id_sucursal = s.id_sucursal

        WHERE v.id_venta = %s
    """

    cursor.execute(
        sql,
        (id_venta,)
    )

    result = cursor.fetchone()

    conn.close()

    return result


# ==============================
# GET → ventas por usuario
# ==============================

def get_by_usuario(
    id_usuario: int
):

    conn = get_connection()

    cursor = conn.cursor(
        dictionary=True
    )

    sql = """

        SELECT

            v.*,

            c.nombre AS nombre_cliente,

            u.usuario,

            s.nombre AS nombre_sucursal

        FROM ventas v

        LEFT JOIN clientes c
        ON v.id_cliente = c.id_cliente

        INNER JOIN usuarios u
        ON v.id_usuario = u.id_usuario

        INNER JOIN sucursales s
        ON v.id_sucursal = s.id_sucursal

        WHERE v.id_usuario = %s

        ORDER BY v.id_venta DESC
    """

    cursor.execute(
        sql,
        (id_usuario,)
    )

    result = cursor.fetchall()

    conn.close()

    return result


# ==============================
# GET → ventas por sucursal
# ==============================

def get_by_sucursal(
    id_sucursal: int
):

    conn = get_connection()

    cursor = conn.cursor(
        dictionary=True
    )

    sql = """

        SELECT

            v.*,

            c.nombre AS nombre_cliente,

            u.usuario,

            s.nombre AS nombre_sucursal

        FROM ventas v

        LEFT JOIN clientes c
        ON v.id_cliente = c.id_cliente

        INNER JOIN usuarios u
        ON v.id_usuario = u.id_usuario

        INNER JOIN sucursales s
        ON v.id_sucursal = s.id_sucursal

        WHERE v.id_sucursal = %s

        ORDER BY v.id_venta DESC
    """

    cursor.execute(
        sql,
        (id_sucursal,)
    )

    result = cursor.fetchall()

    conn.close()

    return result


# ==============================
# POST → insertar
# ==============================

def insert(
    data: dict
):

    conn = get_connection()

    cursor = conn.cursor()

    try:

        sql = """

            INSERT INTO ventas (

                id_cliente,
                id_usuario,
                id_sucursal,
                tipo_venta,
                forma_pago,
                total,
                folio
            )

            VALUES (

                %s,
                %s,
                %s,
                %s,
                %s,
                %s,
                %s
            )
        """

        cursor.execute(

            sql,

            (

                data.get("id_cliente"),

                data.get("id_usuario"),

                data.get("id_sucursal"),

                data.get("tipo_venta"),

                data.get("forma_pago"),

                data.get("total"),

                data.get("folio")
            )
        )

        id_venta = cursor.lastrowid

        conn.commit()

        return {

            "ok": True,

            "mensaje":
            "Venta registrada correctamente",

            "id_venta":
            id_venta,

            "folio":
            data.get("folio")
        }

    except Exception as e:

        conn.rollback()

        raise ValueError(
            str(e)
        )

    finally:

        conn.close()


# ==============================
# PUT → actualizar
# ==============================

def update(
    id_venta: int,
    data: dict
):

    conn = get_connection()

    cursor = conn.cursor()

    try:

        sql = """

            UPDATE ventas

            SET

                id_cliente = %s,

                id_usuario = %s,

                id_sucursal = %s,

                tipo_venta = %s,

                forma_pago = %s,

                total = %s,

                folio = %s

            WHERE id_venta = %s
        """

        cursor.execute(

            sql,

            (

                data.get("id_cliente"),

                data.get("id_usuario"),

                data.get("id_sucursal"),

                data.get("tipo_venta"),

                data.get("forma_pago"),

                data.get("total"),

                data.get("folio"),

                id_venta
            )
        )

        conn.commit()

        return {

            "ok": True,

            "mensaje":
            "Venta actualizada correctamente"
        }

    except Exception as e:

        conn.rollback()

        raise ValueError(
            str(e)
        )

    finally:

        conn.close()


# ==============================
# DELETE
# ==============================
def delete(id_venta: int):

    conn = get_connection()

    cursor = conn.cursor()

    try:

        # =====================================
        # ELIMINAR FACTURAS
        # =====================================

        sql_facturas = """
            DELETE FROM facturas_clientes
            WHERE id_venta = %s
        """

        cursor.execute(
            sql_facturas,
            (id_venta,)
        )


        # =====================================
        # ELIMINAR DETALLE VENTA
        # =====================================

        sql_detalle = """
            DELETE FROM detalle_ventas
            WHERE id_venta = %s
        """

        cursor.execute(
            sql_detalle,
            (id_venta,)
        )


        # =====================================
        # ELIMINAR VENTA
        # =====================================

        sql_venta = """
            DELETE FROM ventas
            WHERE id_venta = %s
        """

        cursor.execute(
            sql_venta,
            (id_venta,)
        )


        conn.commit()

        return {

            "ok": True,

            "mensaje":
            "Venta eliminada correctamente"
        }

    except Exception as e:

        conn.rollback()

        raise ValueError(str(e))

    finally:

        conn.close()