from app.db.database import get_connection

# ==============================
# GET → obtener todos
# ==============================
def get_all():
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT * FROM facturas_proveedores")
    result = cursor.fetchall()

    conn.close()
    return result


# ==============================
# GET → obtener por ID
# ==============================
def get_by_id(id_factura: int):
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    sql = "SELECT * FROM facturas_proveedores WHERE id_factura = %s"
    cursor.execute(sql, (id_factura,))

    result = cursor.fetchone()

    conn.close()
    return result


# ==============================
# POST → insertar
# ==============================
def insert(data: dict):
    conn = get_connection()
    cursor = conn.cursor()

    sql = """
        INSERT INTO facturas_proveedores (
            id_proveedor, folio, fecha, total
        )
        VALUES (%s, %s, %s, %s)
    """

    cursor.execute(sql, (
        data.get("id_proveedor"),
        data.get("folio"),
        data.get("fecha"),
        data.get("total")
    ))

    conn.commit()
    conn.close()

    return {"mensaje": "Factura de proveedor creada correctamente"}


# ==============================
# PUT → actualizar
# ==============================
def update(id_factura: int, data: dict):
    conn = get_connection()
    cursor = conn.cursor()

    sql = """
        UPDATE facturas_proveedores
        SET id_proveedor = %s,
            folio = %s,
            fecha = %s,
            total = %s
        WHERE id_factura = %s
    """

    cursor.execute(sql, (
        data.get("id_proveedor"),
        data.get("folio"),
        data.get("fecha"),
        data.get("total"),
        id_factura
    ))

    conn.commit()
    conn.close()

    return {"mensaje": "Factura de proveedor actualizada correctamente"}


# ==============================
# DELETE → eliminar
# ==============================
def delete(id_factura: int):
    conn = get_connection()
    cursor = conn.cursor()

    sql = "DELETE FROM facturas_proveedores WHERE id_factura = %s"
    cursor.execute(sql, (id_factura,))

    conn.commit()
    conn.close()

    return {"mensaje": "Factura de proveedor eliminada correctamente"}