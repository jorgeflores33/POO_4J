from app.db.database import get_connection

# ==============================
# GET → obtener todos
# ==============================
def get_all():
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT * FROM cotizaciones")
    result = cursor.fetchall()

    conn.close()
    return result


# ==============================
# GET → obtener por ID
# ==============================
def get_by_id(id_cotizacion: int):
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    sql = "SELECT * FROM cotizaciones WHERE id_cotizacion = %s"
    cursor.execute(sql, (id_cotizacion,))

    result = cursor.fetchone()

    conn.close()
    return result


# ==============================
# POST → insertar
# ==============================
def insert(data: dict):
    conn = get_connection()
    cursor = conn.cursor()

    sql = """
        INSERT INTO cotizaciones (
            id_cliente, folio
        )
        VALUES (%s, %s)
    """

    cursor.execute(sql, (
        data.get("id_cliente"),
        data.get("folio")
    ))

    conn.commit()
    conn.close()

    return {"mensaje": "Cotización creada correctamente"}


# ==============================
# PUT → actualizar
# ==============================
def update(id_cotizacion: int, data: dict):
    conn = get_connection()
    cursor = conn.cursor()

    sql = """
        UPDATE cotizaciones
        SET id_cliente = %s,
            folio = %s
        WHERE id_cotizacion = %s
    """

    cursor.execute(sql, (
        data.get("id_cliente"),
        data.get("folio"),
        id_cotizacion
    ))

    conn.commit()
    conn.close()

    return {"mensaje": "Cotización actualizada correctamente"}


# ==============================
# DELETE → eliminar
# ==============================
def delete(id_cotizacion: int):
    conn = get_connection()
    cursor = conn.cursor()

    sql = "DELETE FROM cotizaciones WHERE id_cotizacion = %s"
    cursor.execute(sql, (id_cotizacion,))

    conn.commit()
    conn.close()

    return {"mensaje": "Cotización eliminada correctamente"}