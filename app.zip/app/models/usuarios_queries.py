from app.db.database import get_connection


# ==============================
# GET → obtener por username
# ==============================
def get_by_username(usuario: str):

    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    sql = """
        SELECT * FROM usuarios
        WHERE usuario = %s
    """

    cursor.execute(sql, (usuario,))

    result = cursor.fetchone()

    conn.close()

    return result


# ==============================
# GET → obtener todos
# ==============================
def get_all():

    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT * FROM usuarios")

    result = cursor.fetchall()

    conn.close()

    return result


# ==============================
# GET → obtener por ID
# ==============================
def get_by_id(id_usuario: int):

    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    sql = """
        SELECT * FROM usuarios
        WHERE id_usuario = %s
    """

    cursor.execute(sql, (id_usuario,))

    result = cursor.fetchone()

    conn.close()

    return result


# ==============================
# POST → insertar
# ==============================
def insert(data: dict):

    conn = get_connection()
    cursor = conn.cursor()

    sql = """
        INSERT INTO usuarios (
            id_trabajador,
            id_cliente,
            usuario,
            password,
            rol
        )
        VALUES (%s, %s, %s, %s, %s)
    """

    cursor.execute(
        sql,
        (
            data.get("id_trabajador"),
            data.get("id_cliente"),
            data.get("usuario"),
            data.get("password"),
            data.get("rol")
        )
    )

    conn.commit()

    id_insertado = cursor.lastrowid

    conn.close()

    return {
        "mensaje": "Usuario creado correctamente",
        "id_usuario": id_insertado
    }


# ==============================
# PUT → actualizar
# ==============================
def update(id_usuario: int, data: dict):

    conn = get_connection()
    cursor = conn.cursor()

    sql = """
        UPDATE usuarios
        SET id_trabajador = %s,
            id_cliente = %s,
            usuario = %s,
            password = %s,
            rol = %s
        WHERE id_usuario = %s
    """

    cursor.execute(
        sql,
        (
            data.get("id_trabajador"),
            data.get("id_cliente"),
            data.get("usuario"),
            data.get("password"),
            data.get("rol"),
            id_usuario
        )
    )

    conn.commit()

    conn.close()

    return {
        "mensaje": "Usuario actualizado correctamente"
    }


# ==============================
# DELETE → eliminar
# ==============================
def delete(id_usuario: int):

    conn = get_connection()
    cursor = conn.cursor()

    sql = """
        DELETE FROM usuarios
        WHERE id_usuario = %s
    """

    cursor.execute(sql, (id_usuario,))

    conn.commit()

    conn.close()

    return {
        "mensaje": "Usuario eliminado correctamente"
    }
# ==============================
# LOGIN
# ==============================
def login(usuario: str, password: str):

    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    sql = """
        SELECT *
        FROM usuarios
        WHERE usuario = %s
        AND password = %s
    """

    cursor.execute(sql, (
        usuario,
        password
    ))

    result = cursor.fetchone()

    conn.close()

    return result