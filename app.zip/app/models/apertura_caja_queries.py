from app.db.database import get_connection


# ==============================
# GET → obtener todos
# ==============================

def get_all():

    conn = get_connection()

    cursor = conn.cursor(
        dictionary=True
    )

    sql = """

        SELECT

            ac.*,

            u.usuario,

            t.nombre AS nombre_trabajador,

            s.nombre AS nombre_sucursal

        FROM apertura_caja ac

        LEFT JOIN usuarios u
        ON ac.id_usuario = u.id_usuario

        LEFT JOIN trabajadores t
        ON ac.id_trabajador = t.id_trabajador

        LEFT JOIN sucursales s
        ON ac.id_sucursal = s.id_sucursal

        ORDER BY ac.id_apertura DESC
    """

    cursor.execute(sql)

    result = cursor.fetchall()

    conn.close()

    return result


# ==============================
# GET → caja abierta usuario
# ==============================

def get_caja_abierta_usuario(
    id_usuario: int
):

    conn = get_connection()

    cursor = conn.cursor(
        dictionary=True
    )

    sql = """

        SELECT

            ac.*,

            u.usuario,

            t.nombre AS nombre_trabajador,

            s.nombre AS nombre_sucursal

        FROM apertura_caja ac

        LEFT JOIN usuarios u
        ON ac.id_usuario = u.id_usuario

        LEFT JOIN trabajadores t
        ON ac.id_trabajador = t.id_trabajador

        LEFT JOIN sucursales s
        ON ac.id_sucursal = s.id_sucursal

        WHERE ac.id_usuario = %s

        AND ac.estado = 'ABIERTA'

        ORDER BY ac.id_apertura DESC

        LIMIT 1
    """

    cursor.execute(
        sql,
        (id_usuario,)
    )

    result = cursor.fetchone()

    conn.close()

    return result


# ==============================
# GET → obtener por ID
# ==============================

def get_by_id(
    id_apertura: int
):

    conn = get_connection()

    cursor = conn.cursor(
        dictionary=True
    )

    sql = """

        SELECT

            ac.*,

            u.usuario,

            t.nombre AS nombre_trabajador,

            s.nombre AS nombre_sucursal

        FROM apertura_caja ac

        LEFT JOIN usuarios u
        ON ac.id_usuario = u.id_usuario

        LEFT JOIN trabajadores t
        ON ac.id_trabajador = t.id_trabajador

        LEFT JOIN sucursales s
        ON ac.id_sucursal = s.id_sucursal

        WHERE ac.id_apertura = %s
    """

    cursor.execute(
        sql,
        (id_apertura,)
    )

    result = cursor.fetchone()

    conn.close()

    return result


# ==============================
# POST → insertar
# ==============================

def insert(
    data: dict
):

    conn = get_connection()

    cursor = conn.cursor()

    try:

        sql = """

            INSERT INTO apertura_caja (

                id_usuario,

                id_trabajador,

                id_sucursal,

                estado
            )

            VALUES (%s, %s, %s, %s)
        """

        cursor.execute(

            sql,

            (

                data.get("id_usuario"),

                data.get("id_trabajador"),

                data.get("id_sucursal"),

                data.get("estado")
            )
        )

        id_apertura = cursor.lastrowid

        conn.commit()

        return {

            "ok": True,

            "mensaje":
            "Apertura de caja registrada correctamente",

            "id_apertura":
            id_apertura
        }

    except Exception as e:

        conn.rollback()

        raise ValueError(
            str(e)
        )

    finally:

        conn.close()


# ==============================
# PUT → actualizar
# ==============================

def update(
    id_apertura: int,
    data: dict
):

    conn = get_connection()

    cursor = conn.cursor()

    try:

        sql = """

            UPDATE apertura_caja

            SET

                id_usuario = %s,

                id_trabajador = %s,

                id_sucursal = %s,

                estado = %s

            WHERE id_apertura = %s
        """

        cursor.execute(

            sql,

            (

                data.get("id_usuario"),

                data.get("id_trabajador"),

                data.get("id_sucursal"),

                data.get("estado"),

                id_apertura
            )
        )

        conn.commit()

        return {

            "ok": True,

            "mensaje":
            "Apertura de caja actualizada correctamente"
        }

    except Exception as e:

        conn.rollback()

        raise ValueError(
            str(e)
        )

    finally:

        conn.close()


# ==============================
# CERRAR CAJA
# ==============================

def cerrar_caja(
    id_apertura: int
):

    conn = get_connection()

    cursor = conn.cursor()

    try:

        sql = """

            UPDATE apertura_caja

            SET estado = 'CERRADA'

            WHERE id_apertura = %s
        """

        cursor.execute(
            sql,
            (id_apertura,)
        )

        conn.commit()

        return {

            "ok": True,

            "mensaje":
            "Caja cerrada correctamente"
        }

    except Exception as e:

        conn.rollback()

        raise ValueError(
            str(e)
        )

    finally:

        conn.close()


# ==============================
# DELETE → eliminar
# ==============================

def delete(
    id_apertura: int
):

    conn = get_connection()

    cursor = conn.cursor()

    try:

        sql = """

            DELETE FROM apertura_caja

            WHERE id_apertura = %s
        """

        cursor.execute(
            sql,
            (id_apertura,)
        )

        conn.commit()

        return {

            "ok": True,

            "mensaje":
            "Apertura de caja eliminada correctamente"
        }

    except Exception as e:

        conn.rollback()

        raise ValueError(
            str(e)
        )

    finally:

        conn.close()

