from app.db.database import get_connection

# ==============================
# GET → obtener todos
# ==============================
def get_all():
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT * FROM pedidos")
    result = cursor.fetchall()

    conn.close()
    return result


# ==============================
# GET → obtener por ID
# ==============================
def get_by_id(id_pedido: int):
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    sql = "SELECT * FROM pedidos WHERE id_pedido = %s"
    cursor.execute(sql, (id_pedido,))

    result = cursor.fetchone()

    conn.close()
    return result


# ==============================
# POST → insertar
# ==============================
def insert(data: dict):
    conn = get_connection()
    cursor = conn.cursor()

    sql = """
        INSERT INTO pedidos (
            id_cliente, folio, direccion, telefono
        )
        VALUES (%s, %s, %s, %s)
    """

    cursor.execute(sql, (
        data.get("id_cliente"),
        data.get("folio"),
        data.get("direccion"),
        data.get("telefono")
    ))

    conn.commit()
    conn.close()

    return {"mensaje": "Pedido creado correctamente"}


# ==============================
# PUT → actualizar
# ==============================
def update(id_pedido: int, data: dict):
    conn = get_connection()
    cursor = conn.cursor()

    sql = """
        UPDATE pedidos
        SET id_cliente = %s,
            folio = %s,
            direccion = %s,
            telefono = %s
        WHERE id_pedido = %s
    """

    cursor.execute(sql, (
        data.get("id_cliente"),
        data.get("folio"),
        data.get("direccion"),
        data.get("telefono"),
        id_pedido
    ))

    conn.commit()
    conn.close()

    return {"mensaje": "Pedido actualizado correctamente"}


# ==============================
# DELETE → eliminar
# ==============================
def delete(id_pedido: int):
    conn = get_connection()
    cursor = conn.cursor()

    sql = "DELETE FROM pedidos WHERE id_pedido = %s"
    cursor.execute(sql, (id_pedido,))

    conn.commit()
    conn.close()

    return {"mensaje": "Pedido eliminado correctamente"}