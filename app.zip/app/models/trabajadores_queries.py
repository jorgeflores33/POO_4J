from app.db.database import get_connection


# ==============================
# GET → obtener todos
# ==============================
def get_all_trabajadores():

    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT * FROM trabajadores")

    result = cursor.fetchall()

    conn.close()

    return result



# ==============================
# GET → obtener por ID
# ==============================
def get_trabajador_by_id(id_trabajador: int):

    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    sql = """
        SELECT * FROM trabajadores
        WHERE id_trabajador = %s
    """

    cursor.execute(sql, (id_trabajador,))

    result = cursor.fetchone()

    conn.close()

    return result


# ==============================
# POST → insertar
# ==============================
def create_trabajador(data: dict):

    conn = get_connection()
    cursor = conn.cursor()

    sql = """
        INSERT INTO trabajadores (
            nombre,
            fecha_nacimiento,
            area,
            salario
        )
        VALUES (%s, %s, %s, %s)
    """

    cursor.execute(sql, (
        data["nombre"],
        data.get("fecha_nacimiento"),
        data.get("area"),
        data.get("salario")
    ))

    conn.commit()

    id_insertado = cursor.lastrowid

    conn.close()

    return {
        "mensaje": "Trabajador creado correctamente",
        "id_trabajador": id_insertado
    }


# ==============================
# PUT → actualizar
# ==============================
def update_trabajador(id_trabajador: int, data: dict):

    conn = get_connection()
    cursor = conn.cursor()

    sql = """
        UPDATE trabajadores
        SET nombre = %s,
            fecha_nacimiento = %s,
            area = %s,
            salario = %s
        WHERE id_trabajador = %s
    """

    cursor.execute(sql, (
        data["nombre"],
        data.get("fecha_nacimiento"),
        data.get("area"),
        data.get("salario"),
        id_trabajador
    ))

    conn.commit()

    conn.close()

    return {
        "mensaje": "Trabajador actualizado correctamente"
    }


# ==============================
# DELETE → eliminar
# ==============================
def delete_trabajador(id_trabajador: int):

    conn = get_connection()
    cursor = conn.cursor()

    sql = """
        DELETE FROM trabajadores
        WHERE id_trabajador = %s
    """

    cursor.execute(sql, (id_trabajador,))

    conn.commit()

    conn.close()

    return {
        "mensaje": "Trabajador eliminado correctamente"
    }