from app.db.database import get_connection

# ==============================
# GET → obtener todos
# ==============================
def get_all():
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT * FROM nomina")
    result = cursor.fetchall()

    conn.close()
    return result


# ==============================
# GET → obtener por ID
# ==============================
def get_by_id(id_nomina: int):
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    sql = "SELECT * FROM nomina WHERE id_nomina = %s"
    cursor.execute(sql, (id_nomina,))

    result = cursor.fetchone()

    conn.close()
    return result


# ==============================
# POST → insertar
# ==============================
def insert(data: dict):
    conn = get_connection()
    cursor = conn.cursor()

    sql = """
        INSERT INTO nomina (
            id_trabajador, id_asistencia,
            sueldo_base, dias_trabajados, total_pago
        )
        VALUES (%s, %s, %s, %s, %s)
    """

    cursor.execute(sql, (
        data.get("id_trabajador"),
        data.get("id_asistencia"),
        data.get("sueldo_base"),
        data.get("dias_trabajados"),
        data.get("total_pago")
    ))

    conn.commit()
    conn.close()

    return {"mensaje": "Nómina creada correctamente"}


# ==============================
# PUT → actualizar
# ==============================
def update(id_nomina: int, data: dict):
    conn = get_connection()
    cursor = conn.cursor()

    sql = """
        UPDATE nomina
        SET id_trabajador = %s,
            id_asistencia = %s,
            sueldo_base = %s,
            dias_trabajados = %s,
            total_pago = %s
        WHERE id_nomina = %s
    """

    cursor.execute(sql, (
        data.get("id_trabajador"),
        data.get("id_asistencia"),
        data.get("sueldo_base"),
        data.get("dias_trabajados"),
        data.get("total_pago"),
        id_nomina
    ))

    conn.commit()
    conn.close()

    return {"mensaje": "Nómina actualizada correctamente"}


# ==============================
# DELETE → eliminar
# ==============================
def delete(id_nomina: int):
    conn = get_connection()
    cursor = conn.cursor()

    sql = "DELETE FROM nomina WHERE id_nomina = %s"
    cursor.execute(sql, (id_nomina,))

    conn.commit()
    conn.close()

    return {"mensaje": "Nómina eliminada correctamente"}