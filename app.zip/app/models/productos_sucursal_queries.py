from app.db.database import get_connection


# ==============================
# GET → obtener todos
# ==============================

def get_all():

    conn = get_connection()

    cursor = conn.cursor(
        dictionary=True
    )

    sql = """

        SELECT

            ps.*,

            p.nombre,

            p.codigo,

            p.precio,

            p.imagen_url,

            c.nombre AS categoria,

            s.nombre AS sucursal

        FROM productos_sucursal ps

        INNER JOIN productos p
        ON ps.id_producto = p.id_producto

        LEFT JOIN categorias c
        ON p.id_categoria = c.id_categoria

        INNER JOIN sucursales s
        ON ps.id_sucursal = s.id_sucursal

        ORDER BY p.nombre ASC
    """

    cursor.execute(sql)

    result = cursor.fetchall()

    conn.close()

    return result


# ==============================
# GET → obtener productos usuario
# ==============================

def get_productos_usuario(
    usuario: str
):

    conn = get_connection()

    cursor = conn.cursor(
        dictionary=True
    )

    sql = """

        SELECT

            ps.id_producto,

            ps.id_sucursal,

            ps.existencia,

            p.nombre,

            p.codigo,

            p.precio,

            p.imagen_url,

            c.nombre AS categoria,

            s.nombre AS sucursal

        FROM usuarios u

        INNER JOIN apertura_caja ac
        ON u.id_usuario = ac.id_usuario

        INNER JOIN productos_sucursal ps
        ON ac.id_sucursal = ps.id_sucursal

        INNER JOIN productos p
        ON ps.id_producto = p.id_producto

        LEFT JOIN categorias c
        ON p.id_categoria = c.id_categoria

        INNER JOIN sucursales s
        ON ps.id_sucursal = s.id_sucursal

        WHERE u.usuario = %s

        AND ac.estado = 'ABIERTA'

        AND ps.existencia > 0

        ORDER BY p.nombre ASC
    """

    cursor.execute(
        sql,
        (usuario,)
    )

    result = cursor.fetchall()

    conn.close()

    return result


# ==============================
# GET → obtener por PK compuesta
# ==============================

def get_by_id(
    id_producto: int,
    id_sucursal: int
):

    conn = get_connection()

    cursor = conn.cursor(
        dictionary=True
    )

    sql = """

        SELECT *

        FROM productos_sucursal

        WHERE id_producto = %s

        AND id_sucursal = %s
    """

    cursor.execute(

        sql,

        (
            id_producto,
            id_sucursal
        )
    )

    result = cursor.fetchone()

    conn.close()

    return result


# ==============================
# POST → insertar
# ==============================

def insert(data: dict):

    conn = get_connection()

    cursor = conn.cursor()

    sql = """

        INSERT INTO productos_sucursal (

            id_producto,

            id_sucursal,

            existencia
        )

        VALUES (%s, %s, %s)
    """

    cursor.execute(

        sql,

        (

            data.get("id_producto"),

            data.get("id_sucursal"),

            data.get("existencia", 0)
        )
    )

    conn.commit()

    conn.close()

    return {

        "mensaje":

        "Registro producto-sucursal creado correctamente"
    }


# ==============================
# PUT → actualizar
# ==============================

def update(
    id_producto: int,
    id_sucursal: int,
    data: dict
):

    conn = get_connection()

    cursor = conn.cursor()

    sql = """

        UPDATE productos_sucursal

        SET existencia = %s

        WHERE id_producto = %s

        AND id_sucursal = %s
    """

    cursor.execute(

        sql,

        (

            data.get("existencia"),

            id_producto,

            id_sucursal
        )
    )

    conn.commit()

    conn.close()

    return {

        "mensaje":

        "Existencia actualizada correctamente"
    }


# ==============================
# DELETE → eliminar
# ==============================

def delete(
    id_producto: int,
    id_sucursal: int
):

    conn = get_connection()

    cursor = conn.cursor()

    sql = """

        DELETE FROM productos_sucursal

        WHERE id_producto = %s

        AND id_sucursal = %s
    """

    cursor.execute(

        sql,

        (
            id_producto,
            id_sucursal
        )
    )

    conn.commit()

    conn.close()

    return {

        "mensaje":

        "Registro eliminado correctamente"
    }


# ==============================================
# VALIDAR PRODUCTO POR USUARIO
# ==============================================

def validar_producto_usuario(
    usuario: str,
    id_producto: int
):

    conn = get_connection()

    cursor = conn.cursor(
        dictionary=True
    )

    sql = """

        SELECT

            ps.id_producto,

            ps.id_sucursal,

            ps.existencia,

            p.nombre,

            p.codigo,

            p.precio,

            s.nombre AS sucursal

        FROM usuarios u

        INNER JOIN apertura_caja ac
        ON u.id_usuario = ac.id_usuario

        INNER JOIN productos_sucursal ps
        ON ac.id_sucursal = ps.id_sucursal

        INNER JOIN productos p
        ON ps.id_producto = p.id_producto

        INNER JOIN sucursales s
        ON ps.id_sucursal = s.id_sucursal

        WHERE u.usuario = %s

        AND ps.id_producto = %s

        AND ac.estado = 'ABIERTA'

        ORDER BY ac.id_apertura DESC

        LIMIT 1
    """

    cursor.execute(

        sql,

        (
            usuario,
            id_producto
        )
    )

    result = cursor.fetchone()

    conn.close()

    return result

