from app.db.database import get_connection

# ==============================
# GET → obtener todos
# ==============================
def get_all():
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT * FROM asistencia")
    result = cursor.fetchall()

    conn.close()
    return result


# ==============================
# GET → obtener por ID
# ==============================
def get_by_id(id_asistencia: int):
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    sql = "SELECT * FROM asistencia WHERE id_asistencia = %s"
    cursor.execute(sql, (id_asistencia,))

    result = cursor.fetchone()

    conn.close()
    return result


# ==============================
# POST → insertar
# ==============================
def insert(data: dict):
    conn = get_connection()
    cursor = conn.cursor()

    sql = """
        INSERT INTO asistencia (
            id_trabajador, fecha, hora_entrada, hora_salida
        )
        VALUES (%s, %s, %s, %s)
    """

    cursor.execute(sql, (
        data.get("id_trabajador"),
        data.get("fecha"),
        data.get("hora_entrada"),
        data.get("hora_salida")
    ))

    conn.commit()
    conn.close()

    return {"mensaje": "Asistencia registrada correctamente"}


# ==============================
# PUT → actualizar
# ==============================
def update(id_asistencia: int, data: dict):
    conn = get_connection()
    cursor = conn.cursor()

    sql = """
        UPDATE asistencia
        SET id_trabajador = %s,
            fecha = %s,
            hora_entrada = %s,
            hora_salida = %s
        WHERE id_asistencia = %s
    """

    cursor.execute(sql, (
        data.get("id_trabajador"),
        data.get("fecha"),
        data.get("hora_entrada"),
        data.get("hora_salida"),
        id_asistencia
    ))

    conn.commit()
    conn.close()

    return {"mensaje": "Asistencia actualizada correctamente"}


# ==============================
# DELETE → eliminar
# ==============================
def delete(id_asistencia: int):
    conn = get_connection()
    cursor = conn.cursor()

    sql = "DELETE FROM asistencia WHERE id_asistencia = %s"
    cursor.execute(sql, (id_asistencia,))

    conn.commit()
    conn.close()

    return {"mensaje": "Asistencia eliminada correctamente"}