from app.db.database import get_connection


# ==============================
# GET → obtener todos
# ==============================
def get_all():

    conn = get_connection()

    cursor = conn.cursor(
        dictionary=True
    )

    cursor.execute("""

        SELECT
            i.*,
            s.nombre AS sucursal
        FROM inventarios i
        INNER JOIN sucursales s
            ON i.id_sucursal = s.id_sucursal
        ORDER BY i.id_inventario DESC

    """)

    result = cursor.fetchall()

    conn.close()

    return result



# ==============================
# GET → obtener por ID
# ==============================
def get_by_id(id_inventario: int):

    conn = get_connection()

    cursor = conn.cursor(
        dictionary=True
    )

    sql = """

        SELECT
            i.*,
            s.nombre AS sucursal
        FROM inventarios i
        INNER JOIN sucursales s
            ON i.id_sucursal = s.id_sucursal
        WHERE i.id_inventario = %s

    """

    cursor.execute(
        sql,
        (id_inventario,)
    )

    result = cursor.fetchone()

    conn.close()

    return result



# ==============================
# POST → insertar
# ==============================
def insert(data: dict):

    conn = get_connection()

    cursor = conn.cursor()

    sql = """

        INSERT INTO inventarios (

            folio,
            id_sucursal,
            id_categoria

        )

        VALUES (%s, %s, %s)

    """

    cursor.execute(sql, (

        data.get("folio"),

        data.get("id_sucursal"),

        data.get("id_categoria")

    ))


    # ==================================
    # OBTENER ID GENERADO
    # ==================================
    id_inventario = cursor.lastrowid


    conn.commit()

    conn.close()

    return {

        "mensaje":
        "Inventario creado correctamente",

        "id_inventario":
        id_inventario
    }



# ==============================
# PUT → actualizar
# ==============================
def update(
    id_inventario: int,
    data: dict
):

    conn = get_connection()

    cursor = conn.cursor()

    sql = """

        UPDATE inventarios

        SET

            folio = %s,
            id_sucursal = %s,
            id_categoria = %s

        WHERE id_inventario = %s

    """

    cursor.execute(sql, (

        data.get("folio"),

        data.get("id_sucursal"),

        data.get("id_categoria"),

        id_inventario

    ))

    conn.commit()

    conn.close()

    return {

        "mensaje":
        "Inventario actualizado correctamente"
    }



# ==============================
# DELETE → eliminar
# ==============================
def delete(id_inventario: int):

    conn = get_connection()

    cursor = conn.cursor()

    sql = """

        DELETE FROM inventarios
        WHERE id_inventario = %s

    """

    cursor.execute(
        sql,
        (id_inventario,)
    )

    conn.commit()

    conn.close()

    return {

        "mensaje":
        "Inventario eliminado correctamente"
    }