from app.db.database import get_connection

# ==============================
# GET → obtener todos
# ==============================
def get_all():
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT * FROM clientes")
    result = cursor.fetchall()

    conn.close()
    return result


# ==============================
# GET → obtener por ID
# ==============================
def get_by_id(id_cliente: int):
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    sql = "SELECT * FROM clientes WHERE id_cliente = %s"
    cursor.execute(sql, (id_cliente,))

    result = cursor.fetchone()

    conn.close()
    return result


# ==============================
# POST → insertar
# ==============================
def insert(data: dict):
    conn = get_connection()
    cursor = conn.cursor()

    sql = """
        INSERT INTO clientes (
            nombre,
            telefono,
            correo,
            direccion,
            rfc,
            regimen_fiscal,
            codigo_postal,
            entidad,
            ciudad,
            folio
        )
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
    """

    cursor.execute(sql, (
        data.get("nombre"),
        data.get("telefono"),
        data.get("correo"),
        data.get("direccion"),
        data.get("rfc"),
        data.get("regimen_fiscal"),
        data.get("codigo_postal"),
        data.get("entidad"),
        data.get("ciudad"),
        data.get("folio")
    ))

    conn.commit()
    conn.close()

    return {"mensaje": "Cliente creado correctamente"}


# ==============================
# PUT → actualizar
# ==============================
def update(id_cliente: int, data: dict):
    conn = get_connection()
    cursor = conn.cursor()

    sql = """
        UPDATE clientes
        SET nombre = %s,
            telefono = %s,
            correo = %s,
            direccion = %s,
            rfc = %s,
            regimen_fiscal = %s,
            codigo_postal = %s,
            entidad = %s,
            ciudad = %s,
            folio = %s
        WHERE id_cliente = %s
    """

    cursor.execute(sql, (
        data.get("nombre"),
        data.get("telefono"),
        data.get("correo"),
        data.get("direccion"),
        data.get("rfc"),
        data.get("regimen_fiscal"),
        data.get("codigo_postal"),
        data.get("entidad"),
        data.get("ciudad"),
        data.get("folio"),
        id_cliente
    ))

    conn.commit()
    conn.close()

    return {"mensaje": "Cliente actualizado correctamente"}


# ==============================
# DELETE → eliminar
# ==============================
def delete(id_cliente: int):
    conn = get_connection()
    cursor = conn.cursor()

    sql = "DELETE FROM clientes WHERE id_cliente = %s"
    cursor.execute(sql, (id_cliente,))

    conn.commit()
    conn.close()

    return {"mensaje": "Cliente eliminado correctamente"}