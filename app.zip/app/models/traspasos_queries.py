from app.db.database import get_connection

# ==============================
# GET → obtener todos
# ==============================
def get_all():
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT * FROM traspasos")
    result = cursor.fetchall()

    conn.close()
    return result


# ==============================
# GET → obtener por ID
# ==============================
def get_by_id(id_traspaso: int):
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    sql = "SELECT * FROM traspasos WHERE id_traspaso = %s"
    cursor.execute(sql, (id_traspaso,))

    result = cursor.fetchone()

    conn.close()
    return result


# ==============================
# POST → insertar
# ==============================
def insert(data: dict):
    conn = get_connection()
    cursor = conn.cursor()

    sql = """
        INSERT INTO traspasos (
            id_sucursal_origen, id_sucursal_destino
        )
        VALUES (%s, %s)
    """

    cursor.execute(sql, (
        data.get("id_sucursal_origen"),
        data.get("id_sucursal_destino")
    ))

    conn.commit()
    conn.close()

    return {"mensaje": "Traspaso registrado correctamente"}


# ==============================
# PUT → actualizar
# ==============================
def update(id_traspaso: int, data: dict):
    conn = get_connection()
    cursor = conn.cursor()

    sql = """
        UPDATE traspasos
        SET id_sucursal_origen = %s,
            id_sucursal_destino = %s
        WHERE id_traspaso = %s
    """

    cursor.execute(sql, (
        data.get("id_sucursal_origen"),
        data.get("id_sucursal_destino"),
        id_traspaso
    ))

    conn.commit()
    conn.close()

    return {"mensaje": "Traspaso actualizado correctamente"}


# ==============================
# DELETE → eliminar
# ==============================
def delete(id_traspaso: int):
    conn = get_connection()
    cursor = conn.cursor()

    sql = "DELETE FROM traspasos WHERE id_traspaso = %s"
    cursor.execute(sql, (id_traspaso,))

    conn.commit()
    conn.close()

    return {"mensaje": "Traspaso eliminado correctamente"}