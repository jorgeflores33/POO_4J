from app.db.database import get_connection

# ==============================
# GET → obtener todos
# ==============================
def get_all():
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT * FROM sucursales")
    result = cursor.fetchall()

    conn.close()
    return result


# ==============================
# GET → obtener por ID
# ==============================
def get_by_id(id_sucursal: int):
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    sql = "SELECT * FROM sucursales WHERE id_sucursal = %s"
    cursor.execute(sql, (id_sucursal,))

    result = cursor.fetchone()

    conn.close()
    return result


# ==============================
# POST → insertar
# ==============================
def insert(data: dict):
    conn = get_connection()
    cursor = conn.cursor()

    sql = """
        INSERT INTO sucursales (
            nombre, direccion, telefono, activo
        )
        VALUES (%s, %s, %s, %s)
    """

    cursor.execute(sql, (
        data.get("nombre"),
        data.get("direccion"),
        data.get("telefono"),
        data.get("activo", True)  # valor por defecto
    ))

    conn.commit()
    conn.close()

    return {"mensaje": "Sucursal creada correctamente"}


# ==============================
# PUT → actualizar
# ==============================
def update(id_sucursal: int, data: dict):
    conn = get_connection()
    cursor = conn.cursor()

    sql = """
        UPDATE sucursales
        SET nombre = %s,
            direccion = %s,
            telefono = %s,
            activo = %s
        WHERE id_sucursal = %s
    """

    cursor.execute(sql, (
        data.get("nombre"),
        data.get("direccion"),
        data.get("telefono"),
        data.get("activo"),
        id_sucursal
    ))

    conn.commit()
    conn.close()

    return {"mensaje": "Sucursal actualizada correctamente"}


# ==============================
# DELETE → eliminar
# ==============================
def delete(id_sucursal: int):
    conn = get_connection()
    cursor = conn.cursor()

    sql = "DELETE FROM sucursales WHERE id_sucursal = %s"
    cursor.execute(sql, (id_sucursal,))

    conn.commit()
    conn.close()

    return {"mensaje": "Sucursal eliminada correctamente"}