from app.db.database import get_connection

# ==============================
# GET → obtener todos
# ==============================
def get_all():
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT * FROM categorias")
    result = cursor.fetchall()

    conn.close()
    return result


# ==============================
# GET → obtener por ID
# ==============================
def get_by_id(id_categoria: int):
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    sql = "SELECT * FROM categorias WHERE id_categoria = %s"
    cursor.execute(sql, (id_categoria,))

    result = cursor.fetchone()

    conn.close()
    return result


# ==============================
# POST → insertar
# ==============================
def insert(data: dict):
    conn = get_connection()
    cursor = conn.cursor()

    sql = "INSERT INTO categorias (nombre) VALUES (%s)"

    cursor.execute(sql, (
        data.get("nombre"),
    ))

    conn.commit()
    conn.close()

    return {"mensaje": "Categoría creada correctamente"}


# ==============================
# PUT → actualizar
# ==============================
def update(id_categoria: int, data: dict):
    conn = get_connection()
    cursor = conn.cursor()

    sql = """
        UPDATE categorias
        SET nombre = %s
        WHERE id_categoria = %s
    """

    cursor.execute(sql, (
        data.get("nombre"),
        id_categoria
    ))

    conn.commit()
    conn.close()

    return {"mensaje": "Categoría actualizada correctamente"}


# ==============================
# DELETE → eliminar
# ==============================
def delete(id_categoria: int):
    conn = get_connection()
    cursor = conn.cursor()

    sql = "DELETE FROM categorias WHERE id_categoria = %s"
    cursor.execute(sql, (id_categoria,))

    conn.commit()
    conn.close()

    return {"mensaje": "Categoría eliminada correctamente"}