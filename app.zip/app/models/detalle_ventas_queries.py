from app.db.database import get_connection


# ==============================
# GET → obtener todos
# ==============================

def get_all():

    conn = get_connection()

    cursor = conn.cursor(
        dictionary=True
    )

    sql = """

        SELECT

            dv.*,

            p.nombre,

            p.codigo,

            p.precio

        FROM detalle_ventas dv

        INNER JOIN productos p
        ON dv.id_producto = p.id_producto

        ORDER BY dv.id_detalle DESC
    """

    cursor.execute(sql)

    result = cursor.fetchall()

    conn.close()

    return result


# ==============================
# GET → obtener por ID
# ==============================

def get_by_id(
    id_detalle: int
):

    conn = get_connection()

    cursor = conn.cursor(
        dictionary=True
    )

    sql = """

        SELECT

            dv.*,

            p.nombre,

            p.codigo,

            p.precio

        FROM detalle_ventas dv

        INNER JOIN productos p
        ON dv.id_producto = p.id_producto

        WHERE dv.id_detalle = %s
    """

    cursor.execute(
        sql,
        (id_detalle,)
    )

    result = cursor.fetchone()

    conn.close()

    return result


# ==============================================
# GET → obtener detalle por venta
# ==============================================

def get_by_venta(
    id_venta: int
):

    conn = get_connection()

    cursor = conn.cursor(
        dictionary=True
    )

    sql = """

        SELECT

            dv.*,

            p.nombre,

            p.codigo,

            p.precio,

            p.imagen_url

        FROM detalle_ventas dv

        INNER JOIN productos p
        ON dv.id_producto = p.id_producto

        WHERE dv.id_venta = %s

        ORDER BY dv.id_detalle ASC
    """

    cursor.execute(
        sql,
        (id_venta,)
    )

    result = cursor.fetchall()

    conn.close()

    return result


# ==============================
# POST → insertar
# ==============================

def insert(
    data: dict
):

    conn = get_connection()

    cursor = conn.cursor()

    try:

        sql = """

            INSERT INTO detalle_ventas (

                id_venta,

                id_producto,

                cantidad,

                precio_unitario,

                subtotal
            )

            VALUES (%s, %s, %s, %s, %s)
        """

        cursor.execute(

            sql,

            (

                data.get("id_venta"),

                data.get("id_producto"),

                data.get("cantidad"),

                data.get("precio_unitario"),

                data.get("subtotal")
            )
        )

        id_detalle = cursor.lastrowid

        conn.commit()

        return {

            "ok": True,

            "mensaje":
            "Detalle de venta creado correctamente",

            "id_detalle":
            id_detalle
        }

    except Exception as e:

        conn.rollback()

        raise ValueError(
            str(e)
        )

    finally:

        conn.close()


# ==============================
# PUT → actualizar
# ==============================

def update(
    id_detalle: int,
    data: dict
):

    conn = get_connection()

    cursor = conn.cursor()

    try:

        sql = """

            UPDATE detalle_ventas

            SET

                id_venta = %s,

                id_producto = %s,

                cantidad = %s,

                precio_unitario = %s,

                subtotal = %s

            WHERE id_detalle = %s
        """

        cursor.execute(

            sql,

            (

                data.get("id_venta"),

                data.get("id_producto"),

                data.get("cantidad"),

                data.get("precio_unitario"),

                data.get("subtotal"),

                id_detalle
            )
        )

        conn.commit()

        return {

            "ok": True,

            "mensaje":
            "Detalle de venta actualizado correctamente"
        }

    except Exception as e:

        conn.rollback()

        raise ValueError(
            str(e)
        )

    finally:

        conn.close()

# ==============================================
# DELETE → eliminar por venta
# ==============================================

def delete_by_venta(
    id_venta: int
):

    conn = get_connection()

    cursor = conn.cursor()

    try:

        sql = """

            DELETE FROM detalle_ventas

            WHERE id_venta = %s
        """

        cursor.execute(
            sql,
            (id_venta,)
        )

        conn.commit()

        return {

            "ok": True,

            "mensaje":
            "Detalles eliminados correctamente"
        }

    except Exception as e:

        conn.rollback()

        raise ValueError(
            str(e)
        )

    finally:

        conn.close()
        
# ==============================
# DELETE → eliminar
# ==============================

def delete(
    id_detalle: int
):

    conn = get_connection()

    cursor = conn.cursor()

    try:

        sql = """

            DELETE FROM detalle_ventas

            WHERE id_detalle = %s
        """

        cursor.execute(
            sql,
            (id_detalle,)
        )

        conn.commit()

        return {

            "ok": True,

            "mensaje":
            "Detalle de venta eliminado correctamente"
        }

    except Exception as e:

        conn.rollback()

        raise ValueError(
            str(e)
        )

    finally:

        conn.close()
