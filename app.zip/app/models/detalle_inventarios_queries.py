from app.db.database import get_connection


# ==============================
# GET → obtener todos
# ==============================
def get_all():

    conn = get_connection()

    cursor = conn.cursor(
        dictionary=True
    )

    cursor.execute("""

        SELECT
            di.*,
            p.nombre AS producto,
            p.codigo
        FROM detalle_inventarios di
        INNER JOIN productos p
            ON di.id_producto = p.id_producto

    """)

    result = cursor.fetchall()

    conn.close()

    return result



# ==============================
# GET → obtener por ID
# ==============================
def get_by_id(id_detalle: int):

    conn = get_connection()

    cursor = conn.cursor(
        dictionary=True
    )

    sql = """

        SELECT
            di.*,
            p.nombre AS producto,
            p.codigo
        FROM detalle_inventarios di
        INNER JOIN productos p
            ON di.id_producto = p.id_producto
        WHERE di.id_detalle = %s

    """

    cursor.execute(
        sql,
        (id_detalle,)
    )

    result = cursor.fetchone()

    conn.close()

    return result



# ==============================
# GET → obtener por inventario
# ==============================
def get_by_inventario(
    id_inventario: int
):

    conn = get_connection()

    cursor = conn.cursor(
        dictionary=True
    )

    sql = """

        SELECT
            di.*,
            p.nombre AS producto,
            p.codigo
        FROM detalle_inventarios di
        INNER JOIN productos p
            ON di.id_producto = p.id_producto
        WHERE di.id_inventario = %s

    """

    cursor.execute(
        sql,
        (id_inventario,)
    )

    result = cursor.fetchall()

    conn.close()

    return result



# ==============================
# POST → insertar
# ==============================
def insert(data: dict):

    conn = get_connection()

    cursor = conn.cursor()

    sql = """

        INSERT INTO detalle_inventarios (

            id_inventario,
            id_producto,
            existencia_sistema,
            existencia_fisica,
            diferencia

        )

        VALUES (%s, %s, %s, %s, %s)

    """

    cursor.execute(sql, (

        data.get("id_inventario"),

        data.get("id_producto"),

        data.get("existencia_sistema"),

        data.get("existencia_fisica"),

        data.get("diferencia")

    ))

    id_detalle = cursor.lastrowid

    conn.commit()

    conn.close()

    return {

        "mensaje":
        "Detalle de inventario creado correctamente",

        "id_detalle":
        id_detalle
    }



# ==============================
# PUT → actualizar
# ==============================
def update(
    id_detalle: int,
    data: dict
):

    conn = get_connection()

    cursor = conn.cursor()

    sql = """

        UPDATE detalle_inventarios

        SET

            id_inventario = %s,
            id_producto = %s,
            existencia_sistema = %s,
            existencia_fisica = %s,
            diferencia = %s

        WHERE id_detalle = %s

    """

    cursor.execute(sql, (

        data.get("id_inventario"),

        data.get("id_producto"),

        data.get("existencia_sistema"),

        data.get("existencia_fisica"),

        data.get("diferencia"),

        id_detalle

    ))

    conn.commit()

    conn.close()

    return {

        "mensaje":
        "Detalle de inventario actualizado correctamente"
    }



# ==============================
# DELETE → eliminar
# ==============================
def delete(id_detalle: int):

    conn = get_connection()

    cursor = conn.cursor()

    sql = """

        DELETE FROM detalle_inventarios
        WHERE id_detalle = %s

    """

    cursor.execute(
        sql,
        (id_detalle,)
    )

    conn.commit()

    conn.close()

    return {

        "mensaje":
        "Detalle de inventario eliminado correctamente"
    }