from app.db.database import get_connection

# ==============================
# GET → obtener todos
# ==============================
def get_all():
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT * FROM detalle_traspasos")
    result = cursor.fetchall()

    conn.close()
    return result


# ==============================
# GET → obtener por ID
# ==============================
def get_by_id(id_detalle: int):
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    sql = "SELECT * FROM detalle_traspasos WHERE id_detalle = %s"
    cursor.execute(sql, (id_detalle,))

    result = cursor.fetchone()

    conn.close()
    return result


# ==============================
# POST → insertar
# ==============================
def insert(data: dict):
    conn = get_connection()
    cursor = conn.cursor()

    sql = """
        INSERT INTO detalle_traspasos (
            id_traspaso, id_producto, cantidad
        )
        VALUES (%s, %s, %s)
    """

    cursor.execute(sql, (
        data.get("id_traspaso"),
        data.get("id_producto"),
        data.get("cantidad")
    ))

    conn.commit()
    conn.close()

    return {"mensaje": "Detalle de traspaso creado correctamente"}


# ==============================
# PUT → actualizar
# ==============================
def update(id_detalle: int, data: dict):
    conn = get_connection()
    cursor = conn.cursor()

    sql = """
        UPDATE detalle_traspasos
        SET id_traspaso = %s,
            id_producto = %s,
            cantidad = %s
        WHERE id_detalle = %s
    """

    cursor.execute(sql, (
        data.get("id_traspaso"),
        data.get("id_producto"),
        data.get("cantidad"),
        id_detalle
    ))

    conn.commit()
    conn.close()

    return {"mensaje": "Detalle de traspaso actualizado correctamente"}
# ==============================
# DELETE → eliminar
# ==============================
def delete(id_detalle: int):
    conn = get_connection()
    cursor = conn.cursor()

    sql = "DELETE FROM detalle_traspasos WHERE id_detalle = %s"
    cursor.execute(sql, (id_detalle,))

    conn.commit()
    conn.close()

    return {"mensaje": "Detalle de traspaso eliminado correctamente"}