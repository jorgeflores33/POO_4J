from app.db.database import get_connection

# ==============================
# GET → obtener todos
# ==============================
def get_all():
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT * FROM detalle_cotizaciones")
    result = cursor.fetchall()

    conn.close()
    return result


# ==============================
# GET → obtener por ID
# ==============================
def get_by_id(id_detalle: int):
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    sql = "SELECT * FROM detalle_cotizaciones WHERE id_detalle = %s"
    cursor.execute(sql, (id_detalle,))

    result = cursor.fetchone()

    conn.close()
    return result


# ==============================
# POST → insertar
# ==============================
def insert(data: dict):
    conn = get_connection()
    cursor = conn.cursor()

    sql = """
        INSERT INTO detalle_cotizaciones (
            id_cotizacion, id_producto, cantidad,
            precio, subtotal
        )
        VALUES (%s, %s, %s, %s, %s)
    """

    cursor.execute(sql, (
        data.get("id_cotizacion"),
        data.get("id_producto"),
        data.get("cantidad"),
        data.get("precio"),
        data.get("subtotal")
    ))

    conn.commit()
    conn.close()

    return {"mensaje": "Detalle de cotización creado correctamente"}


# ==============================
# PUT → actualizar
# ==============================
def update(id_detalle: int, data: dict):
    conn = get_connection()
    cursor = conn.cursor()

    sql = """
        UPDATE detalle_cotizaciones
        SET id_cotizacion = %s,
            id_producto = %s,
            cantidad = %s,
            precio = %s,
            subtotal = %s
        WHERE id_detalle = %s
    """

    cursor.execute(sql, (
        data.get("id_cotizacion"),
        data.get("id_producto"),
        data.get("cantidad"),
        data.get("precio"),
        data.get("subtotal"),
        id_detalle
    ))

    conn.commit()
    conn.close()

    return {"mensaje": "Detalle de cotización actualizado correctamente"}
# ==============================
# DELETE → eliminar
# ==============================
def delete(id_detalle: int):
    conn = get_connection()
    cursor = conn.cursor()

    sql = "DELETE FROM detalle_cotizaciones WHERE id_detalle = %s"
    cursor.execute(sql, (id_detalle,))

    conn.commit()
    conn.close()

    return {"mensaje": "Detalle de cotización eliminado correctamente"}