from app.db.database import get_connection


# ==============================
# GET → obtener todos
# ==============================

def get_all():

    conn = get_connection()

    cursor = conn.cursor(
        dictionary=True
    )

    sql = """

        SELECT *

        FROM corte_caja

        ORDER BY id_corte DESC
    """

    cursor.execute(sql)

    result = cursor.fetchall()

    conn.close()

    return result


# ==============================
# GET → obtener por ID
# ==============================

def get_by_id(
    id_corte: int
):

    conn = get_connection()

    cursor = conn.cursor(
        dictionary=True
    )

    sql = """

        SELECT *

        FROM corte_caja

        WHERE id_corte = %s
    """

    cursor.execute(
        sql,
        (id_corte,)
    )

    result = cursor.fetchone()

    conn.close()

    return result


# ==============================
# POST → insertar
# ==============================

def insert(
    data: dict
):

    conn = get_connection()

    cursor = conn.cursor()

    try:

        sql = """

            INSERT INTO corte_caja (

                id_apertura,

                efectivo,

                debito,

                credito,

                transferencia,

                total_ventas,

                diferencia
            )

            VALUES (%s, %s, %s, %s, %s, %s, %s)
        """

        cursor.execute(

            sql,

            (

                data.get("id_apertura"),

                data.get("efectivo"),

                data.get("debito"),

                data.get("credito"),

                data.get("transferencia"),

                data.get("total_ventas"),

                data.get("diferencia")
            )
        )

        id_corte = cursor.lastrowid

        conn.commit()

        return {

            "ok": True,

            "mensaje":
            "Corte de caja registrado correctamente",

            "id_corte":
            id_corte
        }

    except Exception as e:

        conn.rollback()

        raise ValueError(
            str(e)
        )

    finally:

        conn.close()


# ==============================
# PUT → actualizar
# ==============================

def update(
    id_corte: int,
    data: dict
):

    conn = get_connection()

    cursor = conn.cursor()

    try:

        sql = """

            UPDATE corte_caja

            SET

                id_apertura = %s,

                efectivo = %s,

                debito = %s,

                credito = %s,

                transferencia = %s,

                total_ventas = %s,

                diferencia = %s

            WHERE id_corte = %s
        """

        cursor.execute(

            sql,

            (

                data.get("id_apertura"),

                data.get("efectivo"),

                data.get("debito"),

                data.get("credito"),

                data.get("transferencia"),

                data.get("total_ventas"),

                data.get("diferencia"),

                id_corte
            )
        )

        conn.commit()

        return {

            "ok": True,

            "mensaje":
            "Corte de caja actualizado correctamente"
        }

    except Exception as e:

        conn.rollback()

        raise ValueError(
            str(e)
        )

    finally:

        conn.close()


# ==============================
# DELETE → eliminar
# ==============================

def delete(
    id_corte: int
):

    conn = get_connection()

    cursor = conn.cursor()

    try:

        sql = """

            DELETE FROM corte_caja

            WHERE id_corte = %s
        """

        cursor.execute(
            sql,
            (id_corte,)
        )

        conn.commit()

        return {

            "ok": True,

            "mensaje":
            "Corte de caja eliminado correctamente"
        }

    except Exception as e:

        conn.rollback()

        raise ValueError(
            str(e)
        )

    finally:

        conn.close()