from app.db.database import get_connection

# ==============================
# GET → obtener todos
# ==============================
def get_all():
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT * FROM productos")
    result = cursor.fetchall()

    conn.close()
    return result


# ==============================
# GET → obtener por ID
# ==============================
def get_by_id(id_producto: int):
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    sql = "SELECT * FROM productos WHERE id_producto = %s"
    cursor.execute(sql, (id_producto,))

    result = cursor.fetchone()

    conn.close()
    return result


# ==============================
# POST → insertar
# ==============================
def insert(data: dict):

    conn = get_connection()

    cursor = conn.cursor()

    sql = """
        INSERT INTO productos (
            id_categoria,
            nombre,
            descripcion,
            codigo,
            precio,
            imagen_url
        )
        VALUES (%s, %s, %s, %s, %s, %s)
    """

    cursor.execute(sql, (

        data.get("id_categoria"),
        data.get("nombre"),
        data.get("descripcion"),
        data.get("codigo"),
        data.get("precio"),
        data.get("imagen_url")

    ))

    # 🔥 OBTENER ID
    id_producto = cursor.lastrowid

    conn.commit()

    conn.close()

    return {

        "mensaje":
        "Producto creado correctamente",

        "id_producto":
        id_producto
    }

# ==============================
# PUT → actualizar
# ==============================
def update(id_producto: int, data: dict):
    conn = get_connection()
    cursor = conn.cursor()

    sql = """
        UPDATE productos
        SET id_categoria = %s,
            nombre = %s,
            descripcion = %s,
            codigo = %s,
            precio = %s,
            imagen_url = %s
        WHERE id_producto = %s
    """

    cursor.execute(sql, (
        data.get("id_categoria"),
        data.get("nombre"),
        data.get("descripcion"),
        data.get("codigo"),
        data.get("precio"),
        data.get("imagen_url"),
        id_producto
    ))

    conn.commit()
    conn.close()

    return {"mensaje": "Producto actualizado correctamente"}


# ==============================
# DELETE → eliminar
# ==============================
def delete(id_producto: int):
    conn = get_connection()
    cursor = conn.cursor()

    sql = "DELETE FROM productos WHERE id_producto = %s"
    cursor.execute(sql, (id_producto,))

    conn.commit()
    conn.close()

    return {"mensaje": "Producto eliminado correctamente"}