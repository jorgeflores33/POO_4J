const API = "http://127.0.0.1:8000/usuarios";

/* ==============================
   🔥 MODAL LOGIN
============================== */

document.getElementById("btnLogin").addEventListener("click", function () {
    document.getElementById("loginModal").style.display = "flex";
});

// cerrar modal al hacer click fuera
window.addEventListener("click", function (e) {

    const modal =
    document.getElementById("loginModal");

    if (e.target === modal) {

        modal.style.display = "none";
    }
});

/* ==============================
   🔐 LOGIN REAL (FASTAPI)
============================== */

document.getElementById("submitLogin").addEventListener("click", async function (e) {

    e.preventDefault();

    // 🔥 AQUÍ ESTABA EL ERROR
    const usuario =
    document.getElementById("usuario").value;

    const password =
    document.getElementById("password").value;

    if (!usuario || !password) {

        alert("Completa los campos");

        return;
    }

    try {

        const res = await fetch(`${API}/login`, {

            method: "POST",

            headers: {
                "Content-Type": "application/json"
            },

            body: JSON.stringify({
                usuario,
                password
            })
        });

        const data = await res.json();

        console.log("LOGIN:", data);

        if (!data.usuario) {

            alert("Credenciales incorrectas");

            return;
        }

        const user = data.usuario;

        // 🔥 GUARDAR SESIÓN COMPLETA
        localStorage.setItem(
            "usuario",
            user.usuario
        );

        localStorage.setItem(
            "id_usuario",
            user.id_usuario
        );

        localStorage.setItem(
            "rol",
            user.rol
        );

        localStorage.setItem(
            "id_trabajador",
            user.id_trabajador || ""
        );

        localStorage.setItem(
            "id_cliente",
            user.id_cliente || ""
        );

        document.getElementById(
            "loginModal"
        ).style.display = "none";

        // 🚀 REDIRECCIÓN POR ROL
        redirectByRole(user.rol);

    }

    catch (error) {

        console.error(error);

        alert(
            "Error de conexión con el servidor"
        );
    }
});

/* ==============================
   🚀 REDIRECCIÓN POR ROL
============================== */

function redirectByRole(rol) {

    switch (rol) {

        // 🔥 TODOS LOS INTERNOS
        case "admin":
        case "cajero":
        case "almacen":
        case "contabilidad":

            window.location.href =
            "interno/modulo_interno.html";

            break;


        // 🌐 CLIENTE
        case "cliente":

            window.location.href =
            "externo/productos/productos.html";

            break;


        // ❌ DEFAULT
        default:

            window.location.href =
            "index.html";
    }
}

/* ==============================
   🔥 NAVEGACIÓN EXTERNA
============================== */

function irProductos() {

    window.location.href =
    "externo/productos/productos.html";
}

function irCategoria(categoria) {

    window.location.href =
    `externo/productos/productos.html?categoria=${encodeURIComponent(categoria)}`;
}

/* ==============================
   🔗 EVENTOS DE NAVEGACIÓN
============================== */

window.onload = function () {

    // menú principal
    document.getElementById("btnAcerca")?.addEventListener("click", () => {

        window.location.href =
        "externo/acerca/acerca.html";
    });

    document.getElementById("btnProductos")?.addEventListener("click", () => {

        window.location.href =
        "externo/productos/productos.html";
    });

    document.getElementById("btnInicio")?.addEventListener("click", () => {

        window.location.href =
        "index.html";
    });

    document.getElementById("btnContacto")?.addEventListener("click", () => {

        window.location.href =
        "externo/contacto/contacto.html";
    });

    document.getElementById("btnCarrito")?.addEventListener("click", () => {

        window.location.href =
        "externo/pago/pago.html";
    });

    // botón hero productos
    const btnHero =
    document.querySelector(".btn.products");

    if (btnHero) {

        btnHero.addEventListener(
            "click",
            irProductos
        );
    }
};

/* ==============================
   🔐 LOGOUT GLOBAL
============================== */

function logout() {

    localStorage.clear();

    window.location.href =
    "index.html";
}