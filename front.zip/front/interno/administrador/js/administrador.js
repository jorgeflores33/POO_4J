const API = "http://localhost:3000";

// 🔐 VALIDAR
if (!localStorage.getItem("rol")) {
    window.location.href = "C:/papeleria/papeleria/front/index.html";
}

// 🔓 LOGOUT
function logout() {
    localStorage.clear();
    window.location.href = "C:/papeleria/papeleria/front/index.html";
}

// 🔄 NAVEGAR
function ir(pagina) {
    window.location.href = pagina;
}