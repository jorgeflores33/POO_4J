// 🔥 APIs
const API_VENTAS =
"http://127.0.0.1:8000/ventas";

const API_CLIENTES =
"http://127.0.0.1:8000/clientes";

const API_USUARIOS =
"http://127.0.0.1:8000/usuarios";

const API_SUCURSALES =
"http://127.0.0.1:8000/sucursales";


// 🔐 LOGIN
if (!localStorage.getItem("rol")) {

    window.location.href =
    "file:///C:/papeleria/papeleria/front/index.html";
}


// 🔓 LOGOUT
function logout() {

    localStorage.clear();

    window.location.href =
    "file:///C:/papeleria/papeleria/front/index.html";
}


// 🚀 CARGAR VENTAS
async function cargarVentas() {

    try {

        const [
            resVentas,
            resClientes,
            resUsuarios,
            resSucursales
        ] = await Promise.all([

            fetch(API_VENTAS),
            fetch(API_CLIENTES),
            fetch(API_USUARIOS),
            fetch(API_SUCURSALES)
        ]);


        const ventas =
        await resVentas.json();

        const clientes =
        await resClientes.json();

        const usuarios =
        await resUsuarios.json();

        const sucursales =
        await resSucursales.json();


        let html = "";


        // ❌ SIN VENTAS
        if (!ventas.length) {

            html = `
                <tr>
                    <td colspan="8">
                        No hay ventas
                    </td>
                </tr>
            `;
        }


        // ✅ CON DATOS
        else {

            ventas.forEach(v => {

                // 🔥 CLIENTE
                const cliente =
                clientes.find(c =>
                    c.id_cliente === v.id_cliente
                );


                // 🔥 NOMBRE CLIENTE
                const nombreCliente =

                    v.id_cliente

                    ?

                    (
                        cliente
                        ?
                        cliente.nombre
                        :
                        "Cliente"
                    )

                    :

                    "Venta de Mostrador";


                // 🔥 USUARIO
                const usuario =
                usuarios.find(u =>
                    u.id_usuario === v.id_usuario
                );


                // 🔥 SUCURSAL
                const sucursal =
                sucursales.find(s =>
                    s.id_sucursal === v.id_sucursal
                );


                html += `

                    <tr>

                        <td>
                            ${v.folio || ""}
                        </td>

                        <td>
                            ${formatearFecha(v.fecha)}
                        </td>

                        <td>
                            ${nombreCliente}
                        </td>

                        <td>
                            $${v.total || 0}
                        </td>

                        <td>
                            ${
                                usuario
                                ?
                                usuario.usuario
                                :
                                ""
                            }
                        </td>

                        <td>
                            ${
                                sucursal
                                ?
                                sucursal.nombre
                                :
                                ""
                            }
                        </td>

                        <td>

                            <button
                                class="btn-editar"
                                onclick="editar(${v.id_venta})"
                            >
                                ✏️
                            </button>

                            <button
                                class="btn-eliminar"
                                onclick="eliminar(${v.id_venta})"
                            >
                                🗑
                            </button>

                        </td>

                        <td>

                            <button
                                class="btn-ticket"
                                onclick="ticket(${v.id_venta})"
                            >
                                🧾 Ticket
                            </button>

                            <button
                                class="btn-factura"
                                onclick="factura(${v.id_venta})"
                            >
                                📄 Factura
                            </button>

                        </td>

                    </tr>
                `;
            });
        }


        document.getElementById(
            "tablaVentas"
        ).innerHTML = html;
    }

    catch (err) {

        console.error(
            "Error cargando ventas:",
            err
        );

        alert(
            "Error al cargar ventas"
        );
    }
}


// 🗑 ELIMINAR VENTA
async function eliminar(id) {

    if (
        !confirm(
            "¿Eliminar venta?"
        )
    ) {
        return;
    }


    try {

        await fetch(
            `${API_VENTAS}/${id}`,
            {
                method: "DELETE"
            }
        );

        cargarVentas();

    }

    catch (error) {

        console.error(error);

        alert(
            "Error al eliminar venta"
        );
    }
}


// ✏️ EDITAR
function editar(id) {

    alert(
        "Editar venta ID: " + id
    );

    // 🔥 FUTURO
    // window.location.href =
    // `editar_venta.html?id=${id}`;
}


// 🧾 GENERAR TICKET
async function ticket(id) {

    try {

        const res =
        await fetch(
            `${API_VENTAS}/${id}/ticket`,
            {
                method: "POST"
            }
        );

        const data =
        await res.json();


        // 🔥 ABRIR PDF
        window.open(

            `http://127.0.0.1:8000/${data.url}`,

            "_blank"
        );
    }

    catch (err) {

        console.error(
            "Error ticket:",
            err
        );

        alert(
            "Error al generar ticket"
        );
    }
}


// 📄 GENERAR FACTURA
async function factura(id) {

    try {

        const res =
        await fetch(
            `${API_VENTAS}/${id}/factura`,
            {
                method: "POST"
            }
        );

        const data =
        await res.json();


        // 🔥 ABRIR PDF
        window.open(

            `http://127.0.0.1:8000/${data.url}`,

            "_blank"
        );
    }

    catch (err) {

        console.error(
            "Error factura:",
            err
        );

        alert(
            "Error al generar factura"
        );
    }
}


// 📅 FORMATEAR FECHA
function formatearFecha(fecha) {

    if (!fecha) {

        return "";
    }

    return new Date(
        fecha
    ).toLocaleString();
}


// 🚀 INICIO
window.onload =
cargarVentas;