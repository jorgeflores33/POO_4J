// 🔥 APIs
const API_FACTURAS =
"http://127.0.0.1:8000/facturas_clientes";

const API_CLIENTES =
"http://127.0.0.1:8000/clientes";

const API_VENTAS =
"http://127.0.0.1:8000/ventas";

const API_DETALLES =
"http://127.0.0.1:8000/detalle_ventas";


// 🔐 LOGIN
if (!localStorage.getItem("rol")) {

    window.location.href =
    "file:///C:/papeleria/papeleria/front/index.html";
}


// 🔓 LOGOUT
function logout() {

    localStorage.clear();

    window.location.href =
    "file:///C:/papeleria/papeleria/front/index.html";
}


// 🚀 CARGAR FACTURAS
async function cargarFacturas() {

    try {

        // 🔥 CARGAR TODO
        const [
            resFacturas,
            resClientes,
            resVentas,
            resDetalles
        ] = await Promise.all([

            fetch(API_FACTURAS),
            fetch(API_CLIENTES),
            fetch(API_VENTAS),
            fetch(API_DETALLES)
        ]);


        const facturas =
        await resFacturas.json();

        const clientes =
        await resClientes.json();

        const ventas =
        await resVentas.json();

        const detalles =
        await resDetalles.json();


        let html = "";


        // ❌ SIN FACTURAS
        if (
            !facturas
            ||
            facturas.length === 0
        ) {

            html = `
                <tr>
                    <td colspan="8">
                        No hay facturas
                    </td>
                </tr>
            `;
        }


        // ✅ CON FACTURAS
        else {

            facturas.forEach(f => {

                // 🔥 CLIENTE
                const cliente =
                clientes.find(c =>
                    c.id_cliente === f.id_cliente
                );

                // 🔥 VENTA
                const venta =
                ventas.find(v =>
                    v.id_venta === f.id_venta
                );

                // 🔥 DETALLES
                const detalleVenta =
                detalles.filter(d =>
                    d.id_venta === f.id_venta
                );

                // 🔥 TOTAL PRODUCTOS
                const totalProductos =
                detalleVenta.length;


                html += `

                    <tr>

                        <td>
                            ${f.id_factura}
                        </td>

                        <td>
                            ${f.folio || ""}
                        </td>

                        <td>
                            ${
                                cliente
                                ?
                                cliente.nombre
                                :
                                "Sin cliente"
                            }
                        </td>

                        <td>
                            ${
                                venta
                                ?
                                venta.forma_pago
                                :
                                ""
                            }
                        </td>

                        <td>
                            ${
                                totalProductos
                            }
                        </td>

                        <td>
                            ${f.fecha || ""}
                        </td>

                        <td>
                            $${f.total || 0}
                        </td>

                        <td>

                            <button
                                class="btn-pdf"
                                onclick="verPDF('${f.folio}')"
                            >
                                🧾
                            </button>

                            <button
                                class="btn-eliminar"
                                onclick="eliminar(${f.id_factura})"
                            >
                                🗑
                            </button>

                        </td>

                    </tr>
                `;
            });
        }


        document.getElementById(
            "tablaFacturas"
        ).innerHTML = html;
    }

    catch (error) {

        console.error(
            "Error cargando facturas:",
            error
        );

        alert(
            "Error al cargar facturas"
        );
    }
}


// 🧾 VER PDF
function verPDF(folio) {

    if (!folio) {

        alert(
            "La factura no tiene folio"
        );

        return;
    }


    const url =
    `http://127.0.0.1:8000/reports/facturas/factura_${folio}.pdf`;

    window.open(
        url,
        "_blank"
    );
}


// 🗑 ELIMINAR
async function eliminar(id) {

    if (
        !confirm(
            "¿Eliminar factura?"
        )
    ) {
        return;
    }


    try {

        await fetch(
            `${API_FACTURAS}/${id}`,
            {
                method: "DELETE"
            }
        );

        cargarFacturas();

    }

    catch (error) {

        console.error(error);

        alert(
            "Error al eliminar factura"
        );
    }
}


// 🚀 INIT
window.onload = cargarFacturas;