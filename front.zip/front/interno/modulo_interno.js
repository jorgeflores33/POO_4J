// 🔐 VALIDAR LOGIN

const rol = localStorage.getItem("rol");

// 🔐 LOGIN
if (!localStorage.getItem("rol")) {

    window.location.href =
    "file:///C:/papeleria/papeleria/front/index.html";
}



// 🔥 MÓDULOS

const modAdmin = document.getElementById("modAdmin");
const modcajero = document.getElementById("modVentas");
const modAlmacen = document.getElementById("modAlmacen");
const modConta = document.getElementById("modConta");


// 🔥 BLOQUEAR SEGÚN ROL

function bloquearModulos() {

    // ADMIN → acceso total
    if (rol === "admin") {
        return;
    }

    // VENTAS
    if (rol === "cajero") {

        modAdmin.classList.add("bloqueado");
        modAlmacen.classList.add("bloqueado");
        modConta.classList.add("bloqueado");
    }

    // ALMACÉN
    else if (rol === "almacen") {

        modAdmin.classList.add("bloqueado");
        modVentas.classList.add("bloqueado");
        modConta.classList.add("bloqueado");
    }

    // CONTABILIDAD
    else if (rol === "contabilidad") {

        modAdmin.classList.add("bloqueado");
        modVentas.classList.add("bloqueado");
        modAlmacen.classList.add("bloqueado");
    }

    // OTROS
    else {

        modAdmin.classList.add("bloqueado");
        modVentas.classList.add("bloqueado");
        modAlmacen.classList.add("bloqueado");
        modConta.classList.add("bloqueado");
    }
}


// 🚀 REDIRECCIONES

function irModulo(modulo) {

    switch(modulo) {

        case "admin":
            window.location.href =
            "C:/papeleria/papeleria/front/interno/administrador/html/administrador.html";
            break;

        case "ventas":
            window.location.href =
            "C:/papeleria/papeleria/front/interno/venta/html/ventas.html";
            break;

        case "almacen":
            window.location.href =
            "C:/papeleria/papeleria/front/interno/almacen/html/almacen.html";
            break;

        case "contabilidad":
            window.location.href =
            "C:/papeleria/papeleria/front/interno/contabilidad/html/contabilidad.html";
            break;
    }
}




// 🔓 LOGOUT
function logout() {

    localStorage.clear();

    window.location.href =
    "file:///C:/papeleria/papeleria/front/index.html";
}



// 🚀 INICIO

bloquearModulos();