// 🔥 APIs
const API_INVENTARIOS =
"http://127.0.0.1:8000/inventarios";

const API_DETALLE =
"http://127.0.0.1:8000/detalle_inventarios";

const API_SUCURSALES =
"http://127.0.0.1:8000/sucursales";

const API_CATEGORIAS =
"http://127.0.0.1:8000/categorias";

const API_PRODUCTOS =
"http://127.0.0.1:8000/productos";

const API_PRODUCTOS_SUCURSAL =
"http://127.0.0.1:8000/productos_sucursal";


// 🔐 VALIDAR LOGIN
if (!localStorage.getItem("rol")) {

    window.location.href =
    "../html/index.html";
}


// 🔓 LOGOUT
function logout() {

    localStorage.clear();

    window.location.href =
    "../html/index.html";
}


// 🚀 CARGAR INVENTARIOS
async function cargarInventarios() {

    try {

        const [
            resInventarios,
            resSucursales,
            resCategorias
        ] = await Promise.all([

            fetch(API_INVENTARIOS),
            fetch(API_SUCURSALES),
            fetch(API_CATEGORIAS)
        ]);


        const inventarios =
        await resInventarios.json();

        const sucursales =
        await resSucursales.json();

        const categorias =
        await resCategorias.json();


        let html = "";


        // ❌ SIN INVENTARIOS
        if (!inventarios.length) {

            html = `
                <tr>
                    <td colspan="5">
                        Sin inventarios
                    </td>
                </tr>
            `;
        }


        // ✅ CON DATOS
        else {

            inventarios.forEach(i => {

                const sucursal =
                sucursales.find(s =>
                    s.id_sucursal === i.id_sucursal
                );

                const categoria =
                categorias.find(c =>
                    c.id_categoria === i.id_categoria
                );


                html += `

                    <tr>

                        <td>
                            ${i.folio || ""}
                        </td>

                        <td>
                            ${
                                sucursal
                                ?
                                sucursal.nombre
                                :
                                ""
                            }
                        </td>

                        <td>
                            ${
                                categoria
                                ?
                                categoria.nombre
                                :
                                ""
                            }
                        </td>

                        <td>
                            ${formatearFecha(i.fecha)}
                        </td>

                        <td>

                            <button
                                onclick="imprimir(${i.id_inventario})"
                            >
                                🧾
                            </button>

                        </td>

                    </tr>
                `;
            });
        }


        document.getElementById(
            "tablaInventarios"
        ).innerHTML = html;
    }

    catch (error) {

        console.error(error);

        alert(
            "Error al cargar inventarios"
        );
    }
}


// 🔥 ABRIR MODAL
function abrirModal() {

    document.getElementById(
        "modal"
    ).style.display = "flex";

    cargarSelects();
}


// ❌ CERRAR
function cerrarModal() {

    document.getElementById(
        "modal"
    ).style.display = "none";
}


// 🔄 CARGAR SELECTS
async function cargarSelects() {

    try {

        const [
            resSucursales,
            resCategorias
        ] = await Promise.all([

            fetch(API_SUCURSALES),
            fetch(API_CATEGORIAS)
        ]);


        const sucursales =
        await resSucursales.json();

        const categorias =
        await resCategorias.json();


        // 🔥 SUCURSALES
        let htmlSucursales = `
            <option value="">
                Sucursal
            </option>
        `;


        sucursales.forEach(s => {

            htmlSucursales += `

                <option value="${s.id_sucursal}">

                    ${s.nombre}

                </option>
            `;
        });


        document.getElementById(
            "sucursal"
        ).innerHTML = htmlSucursales;


        // 🔥 CATEGORÍAS
        let htmlCategorias = `
            <option value="">
                Categoría
            </option>
        `;


        categorias.forEach(c => {

            htmlCategorias += `

                <option value="${c.id_categoria}">

                    ${c.nombre}

                </option>
            `;
        });


        document.getElementById(
            "categoria"
        ).innerHTML = htmlCategorias;
    }

    catch (error) {

        console.error(error);
    }
}


// 🔥 CARGAR PRODUCTOS
document.addEventListener(
    "DOMContentLoaded",
    () => {

        document.getElementById(
            "categoria"
        ).addEventListener(
            "change",
            cargarProductosCategoria
        );

        document.getElementById(
            "sucursal"
        ).addEventListener(
            "change",
            cargarProductosCategoria
        );
    }
);


// 📦 PRODUCTOS POR CATEGORÍA
async function cargarProductosCategoria() {

    const categoria =
    document.getElementById(
        "categoria"
    ).value;

    const sucursal =
    document.getElementById(
        "sucursal"
    ).value;


    if (
        !categoria
        ||
        !sucursal
    ) {
        return;
    }


    try {

        const [
            resProductos,
            resProductosSucursal
        ] = await Promise.all([

            fetch(API_PRODUCTOS),
            fetch(API_PRODUCTOS_SUCURSAL)
        ]);


        const productos =
        await resProductos.json();

        const productosSucursal =
        await resProductosSucursal.json();


        // 🔥 FILTRAR PRODUCTOS
        const filtrados =
        productos.filter(p =>
            p.id_categoria == categoria
        );


        let html = "";


        filtrados.forEach(p => {

            // 🔥 EXISTENCIA
            const existencia =
            productosSucursal.find(ps =>

                ps.id_producto == p.id_producto
                &&
                ps.id_sucursal == sucursal
            );


            html += `

                <tr>

                    <td>
                        ${p.codigo || ""}
                    </td>

                    <td>
                        ${p.nombre || ""}
                    </td>

                    <td>
                        ${
                            existencia
                            ?
                            existencia.existencia
                            :
                            0
                        }
                    </td>

                    <td>

                        <input
                            type="number"
                            id="fisico-${p.id_producto}"
                            min="0"
                        >

                    </td>

                </tr>
            `;
        });


        document.getElementById(
            "tablaProductos"
        ).innerHTML = html;
    }

    catch (error) {

        console.error(error);

        alert(
            "Error al cargar productos"
        );
    }
}


// 💾 GUARDAR INVENTARIO
async function guardar() {

    const sucursal =
    document.getElementById(
        "sucursal"
    ).value;

    const categoria =
    document.getElementById(
        "categoria"
    ).value;


    if (
        !sucursal
        ||
        !categoria
    ) {

        alert(
            "Selecciona sucursal y categoría"
        );

        return;
    }


    try {

        // 🔥 CREAR INVENTARIO
        const invRes =
        await fetch(API_INVENTARIOS, {

            method: "POST",

            headers: {
                "Content-Type":
                "application/json"
            },

            body: JSON.stringify({

                id_sucursal:
                parseInt(sucursal),

                id_categoria:
                parseInt(categoria)
            })
        });


        const inv =
        await invRes.json();


        // 🔥 DETALLES
        const filas =
        document.querySelectorAll(
            "#tablaProductos tr"
        );


        for (const f of filas) {

            const input =
            f.querySelector("input");

            const id_producto =
            input.id.split("-")[1];

            const fisico =
            input.value || 0;


            await fetch(API_DETALLE, {

                method: "POST",

                headers: {
                    "Content-Type":
                    "application/json"
                },

                body: JSON.stringify({

                    id_inventario:
                    inv.id_inventario,

                    id_producto:
                    parseInt(id_producto),

                    existencia_fisica:
                    parseInt(fisico)
                })
            });
        }


        alert(
            "Inventario guardado correctamente"
        );

        cerrarModal();

        cargarInventarios();

    }

    catch (error) {

        console.error(error);

        alert(
            "Error al guardar inventario"
        );
    }
}


// 🧾 PDF
function imprimir(id) {

    window.open(

        `http://127.0.0.1:8000/inventarios/pdf/${id}`,

        "_blank"
    );
}


// 📅 FORMATO FECHA
function formatearFecha(fecha) {

    if (!fecha) {

        return "";
    }

    return new Date(
        fecha
    ).toLocaleString();
}


// 🚀 INIT
window.onload =
cargarInventarios;