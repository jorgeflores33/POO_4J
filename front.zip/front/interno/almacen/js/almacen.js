const rol = localStorage.getItem("rol");

if (!rol) {
    window.location.href = "../html/index.html";
}

function logout() {
    localStorage.removeItem("rol");
    window.location.href = "../html/index.html";
}

function ir(pagina) {
    window.location.href = pagina;
}