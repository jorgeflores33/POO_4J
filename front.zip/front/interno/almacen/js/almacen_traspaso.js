const API_TRASPASOS =
"http://127.0.0.1:8000/traspasos";

const API_DETALLE =
"http://127.0.0.1:8000/detalle-traspasos";

const API_PRODUCTOS =
"http://127.0.0.1:8000/productos";

const API_SUCURSALES =
"http://127.0.0.1:8000/sucursales";

const API_PRODUCTOS_SUCURSAL =
"http://127.0.0.1:8000/productos-sucursal";


// ======================================
// INIT
// ======================================
window.onload = () => {

    cargarTabla();

    cargarSucursales();

    generarFolio();

    agregarProducto();
};



// ======================================
// GENERAR FOLIO
// ======================================
function generarFolio() {

    const folio =
    "TRS-" + Date.now();

    document.getElementById(
        "folio"
    ).value = folio;
}



// ======================================
// TABLA
// ======================================
async function cargarTabla() {

    const res = await fetch(
        API_TRASPASOS
    );

    const traspasos =
    await res.json();

    const resSuc =
    await fetch(API_SUCURSALES);

    const sucursales =
    await resSuc.json();

    const tabla =
    document.getElementById(
        "tablaTraspasos"
    );

    tabla.innerHTML = "";


    traspasos.forEach(t => {

        const origen =
        sucursales.find(s =>
            s.id_sucursal ==
            t.id_sucursal_origen
        );

        const destino =
        sucursales.find(s =>
            s.id_sucursal ==
            t.id_sucursal_destino
        );

        tabla.innerHTML += `

            <tr>

                <td>
                    ${
                        new Date(
                            t.fecha
                        ).toLocaleString()
                    }
                </td>

                <td>
                    TRS-${t.id_traspaso}
                </td>

                <td>
                    ${
                        origen
                        ? origen.nombre
                        : "N/A"
                    }
                </td>

                <td>
                    ${
                        destino
                        ? destino.nombre
                        : "N/A"
                    }
                </td>

                <td>

                    <button
                        onclick="eliminar(${t.id_traspaso})"
                    >
                        🗑 Eliminar
                    </button>

                </td>

                <td>

                    <button
                        onclick="imprimir(${t.id_traspaso})"
                    >
                        🖨 Imprimir
                    </button>

                </td>

            </tr>
        `;
    });
}



// ======================================
// SUCURSALES
// ======================================
async function cargarSucursales() {

    const res =
    await fetch(API_SUCURSALES);

    const data =
    await res.json();

    const origen =
    document.getElementById(
        "origen"
    );

    const destino =
    document.getElementById(
        "destino"
    );

    origen.innerHTML =
    `<option value="">Sucursal origen</option>`;

    destino.innerHTML =
    `<option value="">Sucursal destino</option>`;


    data.forEach(s => {

        origen.innerHTML += `
            <option value="${s.id_sucursal}">
                ${s.nombre}
            </option>
        `;

        destino.innerHTML += `
            <option value="${s.id_sucursal}">
                ${s.nombre}
            </option>
        `;
    });
}



// ======================================
// AGREGAR PRODUCTO
// ======================================
async function agregarProducto() {

    const res =
    await fetch(API_PRODUCTOS);

    const productos =
    await res.json();

    const div =
    document.createElement("div");

    div.className = "producto";

    let options =
    `<option value="">Producto</option>`;

    productos.forEach(p => {

        options += `
            <option value="${p.id_producto}">
                ${p.nombre}
            </option>
        `;
    });

    div.innerHTML = `

        <select class="productoSelect">
            ${options}
        </select>

        <input
            type="number"
            class="cantidadInput"
            placeholder="Cantidad"
        >

        <button onclick="this.parentNode.remove()">
            ❌
        </button>
    `;

    document.getElementById(
        "productos"
    ).appendChild(div);
}



// ======================================
// GUARDAR
// ======================================
async function guardar() {

    const origen =
    document.getElementById(
        "origen"
    ).value;

    const destino =
    document.getElementById(
        "destino"
    ).value;


    if (
        !origen ||
        !destino
    ) {

        alert(
            "Selecciona origen y destino"
        );

        return;
    }


    if (origen === destino) {

        alert(
            "Origen y destino no pueden ser iguales"
        );

        return;
    }


    // ======================================
    // CREAR TRASPASO
    // ======================================
    const resTraspaso =
    await fetch(API_TRASPASOS, {

        method: "POST",

        headers: {
            "Content-Type":
            "application/json"
        },

        body: JSON.stringify({

            id_sucursal_origen:
            parseInt(origen),

            id_sucursal_destino:
            parseInt(destino)
        })
    });


    const traspaso =
    await resTraspaso.json();


    // ======================================
    // OBTENER ID
    // ======================================
    const traspasosRes =
    await fetch(API_TRASPASOS);

    const traspasos =
    await traspasosRes.json();

    const ultimo =
    traspasos[
        traspasos.length - 1
    ];


    // ======================================
    // PRODUCTOS
    // ======================================
    const productos =
    document.querySelectorAll(
        ".producto"
    );


    for (let p of productos) {

        const id_producto =
        p.querySelector(
            ".productoSelect"
        ).value;

        const cantidad =
        parseInt(
            p.querySelector(
                ".cantidadInput"
            ).value
        );


        if (
            !id_producto ||
            !cantidad
        ) continue;


        // ======================================
        // VALIDAR STOCK
        // ======================================
        const stockRes =
        await fetch(

            `${API_PRODUCTOS_SUCURSAL}/${id_producto}/${origen}`

        );

        const stock =
        await stockRes.json();


        if (!stock) {

            alert(
                "Producto sin inventario"
            );

            return;
        }


        if (
            cantidad >
            stock.existencia
        ) {

            alert(
                "Stock insuficiente"
            );

            return;
        }


        // ======================================
        // RESTAR ORIGEN
        // ======================================
        await fetch(

            `${API_PRODUCTOS_SUCURSAL}/${id_producto}/${origen}`,

            {

                method: "PUT",

                headers: {
                    "Content-Type":
                    "application/json"
                },

                body: JSON.stringify({

                    existencia:
                    stock.existencia - cantidad
                })
            }
        );


        // ======================================
        // DESTINO
        // ======================================
        const destinoRes =
        await fetch(

            `${API_PRODUCTOS_SUCURSAL}/${id_producto}/${destino}`

        );

        const destinoStock =
        await destinoRes.json();


        // EXISTE
        if (
            destinoStock &&
            destinoStock.existencia != null
        ) {

            await fetch(

                `${API_PRODUCTOS_SUCURSAL}/${id_producto}/${destino}`,

                {

                    method: "PUT",

                    headers: {
                        "Content-Type":
                        "application/json"
                    },

                    body: JSON.stringify({

                        existencia:
                        destinoStock.existencia + cantidad
                    })
                }
            );

        }

        // NO EXISTE
        else {

            await fetch(
                API_PRODUCTOS_SUCURSAL,

                {

                    method: "POST",

                    headers: {
                        "Content-Type":
                        "application/json"
                    },

                    body: JSON.stringify({

                        id_producto:
                        parseInt(id_producto),

                        id_sucursal:
                        parseInt(destino),

                        existencia:
                        cantidad
                    })
                }
            );
        }


        // ======================================
        // INSERTAR DETALLE
        // ======================================
        await fetch(
            API_DETALLE,

            {

                method: "POST",

                headers: {
                    "Content-Type":
                    "application/json"
                },

                body: JSON.stringify({

                    id_traspaso:
                    ultimo.id_traspaso,

                    id_producto:
                    parseInt(id_producto),

                    cantidad:
                    cantidad
                })
            }
        );
    }


    alert(
        "Traspaso realizado correctamente"
    );

    cerrarModal();

    cargarTabla();

    limpiarModal();
}



// ======================================
// ELIMINAR
// ======================================
async function eliminar(id) {

    if (
        !confirm(
            "¿Eliminar traspaso?"
        )
    ) return;


    await fetch(

        `${API_TRASPASOS}/${id}`,

        {
            method: "DELETE"
        }
    );

    cargarTabla();
}



// ======================================
// IMPRIMIR
// ======================================
function imprimir(id) {

    window.print();
}



// ======================================
// MODAL
// ======================================
function abrirModal() {

    document.getElementById(
        "modal"
    ).style.display = "flex";
}


function cerrarModal() {

    document.getElementById(
        "modal"
    ).style.display = "none";
}



// ======================================
// LIMPIAR
// ======================================
function limpiarModal() {

    document.getElementById(
        "productos"
    ).innerHTML = "";

    agregarProducto();

    generarFolio();
}



// ======================================
// UTILIDADES
// ======================================
function ir(ruta) {

    window.location.href = ruta;
}


function logout() {

    localStorage.clear();

    window.location.href =
    "../../index.html";
}