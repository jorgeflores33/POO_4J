// 🔥 APIs
const API_FACTURAS =
"http://127.0.0.1:8000/facturas_clientes";

const API_DETALLE =
"http://127.0.0.1:8000/detalle_facturas_clientes";

const API_CLIENTES =
"http://127.0.0.1:8000/clientes";

const API_PRODUCTOS =
"http://127.0.0.1:8000/productos";


// 📄 ELEMENTOS
const tabla =
document.getElementById(
    "tablaFacturas"
);

const detalle =
document.getElementById(
    "detalleFactura"
);

const totalSpan =
document.getElementById(
    "total"
);


// 📦 LISTA GLOBAL
let facturas = [];

let productos = [];

let clientes = [];


// 🔐 LOGIN
if (!localStorage.getItem("rol")) {

    window.location.href =
    "index.html";
}


// 🔓 LOGOUT
function logout() {

    localStorage.clear();

    window.location.href =
    "index.html";
}


// 🚀 CARGAR FACTURAS
async function cargarFacturas() {

    try {

        const [
            resFacturas,
            resClientes,
            resProductos
        ] = await Promise.all([

            fetch(API_FACTURAS),
            fetch(API_CLIENTES),
            fetch(API_PRODUCTOS)
        ]);


        facturas =
        await resFacturas.json();

        clientes =
        await resClientes.json();

        productos =
        await resProductos.json();


        renderTabla();

        cargarClientes();

    }

    catch (error) {

        console.error(error);

        alert(
            "Error al cargar facturas"
        );
    }
}


// 📄 MODAL
function abrirModal() {

    document.getElementById(
        "modalFactura"
    ).style.display =
    "block";


    limpiarModal();
}


// ❌ CERRAR
function cerrarModal() {

    document.getElementById(
        "modalFactura"
    ).style.display =
    "none";
}


// 🧹 LIMPIAR
function limpiarModal() {

    detalle.innerHTML = "";

    totalSpan.innerText = "0";

    document.getElementById(
        "folio"
    ).value = "";

    document.getElementById(
        "fecha"
    ).value = "";
}


// 👥 CLIENTES
function cargarClientes() {

    let html = `
        <option value="">
            Seleccionar cliente
        </option>
    `;


    clientes.forEach(c => {

        html += `

            <option value="${c.id_cliente}">

                ${c.nombre}

            </option>
        `;
    });


    document.getElementById(
        "proveedor"
    ).innerHTML = html;
}


// ➕ FILAS
function agregarFila() {

    let opciones = `
        <option value="">
            Producto
        </option>
    `;


    productos.forEach(p => {

        opciones += `

            <option value="${p.id_producto}">

                ${p.codigo} - ${p.nombre}

            </option>
        `;
    });


    const fila =
    document.createElement("tr");


    fila.innerHTML = `

        <td>

            <select onchange="calcularTotal()">

                ${opciones}

            </select>

        </td>

        <td>

            <input
                type="number"
                value="1"
                min="1"
                onchange="calcularTotal()"
            >

        </td>

        <td>

            <input
                type="number"
                value="0"
                min="0"
                onchange="calcularTotal()"
            >

        </td>

        <td class="subtotal">

            0

        </td>

        <td>

            <button
                onclick="eliminarFila(this)"
            >
                ❌
            </button>

        </td>
    `;


    detalle.appendChild(
        fila
    );
}


// ❌ ELIMINAR FILA
function eliminarFila(btn) {

    btn.parentElement
    .parentElement
    .remove();

    calcularTotal();
}


// 🧮 TOTAL
function calcularTotal() {

    let total = 0;


    document.querySelectorAll(
        "#detalleFactura tr"
    ).forEach(fila => {

        const cantidad =

            parseFloat(
                fila.children[1]
                .children[0]
                .value
            )

            ||

            0;


        const precio =

            parseFloat(
                fila.children[2]
                .children[0]
                .value
            )

            ||

            0;


        const subtotal =
        cantidad * precio;


        fila.children[3]
        .innerText =
        subtotal.toFixed(2);


        total += subtotal;
    });


    totalSpan.innerText =
    total.toFixed(2);
}


// 💾 GUARDAR
async function guardarFactura() {

    const folio =
    document.getElementById(
        "folio"
    ).value;

    const fecha =
    document.getElementById(
        "fecha"
    ).value;

    const id_cliente =
    document.getElementById(
        "proveedor"
    ).value;

    const total =
    parseFloat(
        totalSpan.innerText
    );


    // 🔥 VALIDACIÓN
    if (
        !folio
        ||
        !fecha
        ||
        !id_cliente
    ) {

        alert(
            "Completa todos los campos"
        );

        return;
    }


    try {

        // 🔥 FACTURA
        const facturaRes =
        await fetch(API_FACTURAS, {

            method: "POST",

            headers: {
                "Content-Type":
                "application/json"
            },

            body: JSON.stringify({

                folio,

                fecha,

                id_cliente:
                parseInt(id_cliente),

                total
            })
        });


        const factura =
        await facturaRes.json();


        // 🔥 DETALLE
        const filas =
        document.querySelectorAll(
            "#detalleFactura tr"
        );


        for (const fila of filas) {

            const select =
            fila.children[0]
            .children[0];

            const cantidad =
            parseFloat(
                fila.children[1]
                .children[0]
                .value
            );

            const precio =
            parseFloat(
                fila.children[2]
                .children[0]
                .value
            );

            const subtotal =
            cantidad * precio;


            await fetch(API_DETALLE, {

                method: "POST",

                headers: {
                    "Content-Type":
                    "application/json"
                },

                body: JSON.stringify({

                    id_factura:
                    factura.id_factura,

                    id_producto:
                    parseInt(
                        select.value
                    ),

                    cantidad,

                    precio_unitario:
                    precio,

                    subtotal
                })
            });
        }


        alert(
            "Factura guardada"
        );

        cerrarModal();

        cargarFacturas();

    }

    catch (error) {

        console.error(error);

        alert(
            "Error al guardar factura"
        );
    }
}


// 🧠 RENDER TABLA
function renderTabla() {

    tabla.innerHTML = "";


    // ❌ SIN FACTURAS
    if (!facturas.length) {

        tabla.innerHTML = `

            <tr>

                <td colspan="5">

                    Sin facturas

                </td>

            </tr>
        `;

        return;
    }


    // ✅ CON DATOS
    facturas.forEach(f => {

        const cliente =
        clientes.find(c =>
            c.id_cliente === f.id_cliente
        );


        tabla.innerHTML += `

            <tr>

                <td>
                    ${f.folio}
                </td>

                <td>
                    ${
                        cliente
                        ?
                        cliente.nombre
                        :
                        "Cliente"
                    }
                </td>

                <td>
                    ${formatearFecha(f.fecha)}
                </td>

                <td>
                    $${f.total}
                </td>

                <td>

                    <button
                        onclick="eliminarFactura(${f.id_factura})"
                    >
                        ❌
                    </button>

                </td>

            </tr>
        `;
    });
}


// 🗑 DELETE
async function eliminarFactura(id) {

    if (
        !confirm(
            "¿Eliminar factura?"
        )
    ) {
        return;
    }


    try {

        await fetch(

            `${API_FACTURAS}/${id}`,

            {
                method: "DELETE"
            }
        );

        cargarFacturas();

    }

    catch (error) {

        console.error(error);

        alert(
            "Error al eliminar factura"
        );
    }
}


// 📅 FECHA
function formatearFecha(fecha) {

    if (!fecha) {

        return "";
    }

    return new Date(
        fecha
    ).toLocaleString();
}


// 🚀 INIT
window.onload =
cargarFacturas;