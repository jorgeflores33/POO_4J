const API = "http://127.0.0.1:8000/api/clientes";

let idEditar = null;

// 🔐 VALIDAR
const rol = localStorage.getItem("rol");
if (!rol) {
    window.location.href = "../html/index.html";
}

// 🔓 LOGOUT
function logout() {
    localStorage.removeItem("rol");
    window.location.href = "../html/index.html";
}

// 🚀 CARGAR CLIENTES
function cargarClientes() {

    fetch(API)
        .then(res => res.json())
        .then(data => {

            window.listaClientes = data;
            pintarTabla(data);
        });
}

// 🎨 TABLA
function pintarTabla(data) {

    let filas = "";

    data.forEach(c => {

        filas += `
            <tr>
                <td>${c.id_cliente}</td>
                <td>${c.nombre}</td>
                <td>${c.telefono || ""}</td>
                <td>${c.correo || ""}</td>
                <td>${c.direccion || ""}</td>
                <td>${c.rfc || ""}</td>
                <td>${c.codigo_postal || ""}</td>
                <td>${c.entidad || ""}</td>
                <td>${c.ciudad || ""}</td>
                <td>${c.folio || ""}</td>
                <td>
                    <button onclick="editar(${c.id_cliente})">✏️</button>
                    <button onclick="eliminar(${c.id_cliente})">🗑</button>
                </td>
            </tr>
        `;
    });

    document.getElementById("tablaClientes").innerHTML =
        filas || `<tr><td colspan="11">Sin registros</td></tr>`;
}

// 🔍 BUSCADOR
document.getElementById("buscadorCliente").addEventListener("input", function () {

    const texto = this.value.toLowerCase();

    const filtrados = listaClientes.filter(c =>
        c.nombre.toLowerCase().includes(texto) ||
        (c.correo || "").toLowerCase().includes(texto) ||
        (c.telefono || "").includes(texto)
    );

    pintarTabla(filtrados);
});

// 🔥 MODAL
function abrirModal() {
    idEditar = null;
    limpiar();
    document.getElementById("tituloModal").innerText = "Nuevo Cliente";
    document.getElementById("modalCliente").style.display = "flex";
}

function cerrarModal() {
    document.getElementById("modalCliente").style.display = "none";
}

// 🧹 LIMPIAR
function limpiar() {
    document.querySelectorAll(".modal-box input").forEach(i => i.value = "");
}

// 💾 GUARDAR
function guardarCliente() {

    const data = {
        nombre: document.getElementById("nombre").value,
        telefono: document.getElementById("telefono").value,
        correo: document.getElementById("correo").value,
        direccion: document.getElementById("direccion").value,
        rfc: document.getElementById("rfc").value,
        codigo_postal: document.getElementById("cp").value,
        entidad: document.getElementById("estado").value,
        ciudad: document.getElementById("ciudad").value,
        folio: document.getElementById("folio")?.value || ""
    };

    if (!data.nombre) {
        alert("El nombre es obligatorio");
        return;
    }

    const url = idEditar ? `${API}/${idEditar}` : API;
    const method = idEditar ? "PUT" : "POST";

    fetch(url, {
        method: method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
    }).then(() => {
        cerrarModal();
        cargarClientes();
    });
}

// ✏️ EDITAR
function editar(id) {

    idEditar = id;

    fetch(`${API}/${id}`)
        .then(res => res.json())
        .then(c => {

            document.getElementById("nombre").value = c.nombre;
            document.getElementById("telefono").value = c.telefono;
            document.getElementById("correo").value = c.correo;
            document.getElementById("direccion").value = c.direccion;
            document.getElementById("rfc").value = c.rfc;
            document.getElementById("cp").value = c.codigo_postal;
            document.getElementById("estado").value = c.entidad;
            document.getElementById("ciudad").value = c.ciudad;

            document.getElementById("tituloModal").innerText = "Editar Cliente";

            document.getElementById("modalCliente").style.display = "flex";
        });
}

// 🗑 ELIMINAR
function eliminar(id) {

    if (!confirm("¿Eliminar cliente?")) return;

    fetch(`${API}/${id}`, {
        method: "DELETE"
    }).then(() => cargarClientes());
}

// 🚀 INICIO
window.onload = cargarClientes;