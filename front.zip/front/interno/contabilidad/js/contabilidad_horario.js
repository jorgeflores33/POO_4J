// 🔥 API
const API =
"http://127.0.0.1:8000";


// ✏️ EDITAR
let idEditar = null;


// 🔐 VALIDAR LOGIN
if (!localStorage.getItem("rol")) {

    window.location.href =
    "index.html";
}


// 🔓 LOGOUT
function logout() {

    localStorage.removeItem("rol");

    window.location.href =
    "index.html";
}


// 🔥 ABRIR MODAL
function abrirModal() {

    idEditar = null;

    limpiar();

    document.getElementById(
        "modalHorario"
    ).style.display =
    "flex";

    cargarTrabajadores();
}


// 🔥 CERRAR MODAL
function cerrarModal() {

    document.getElementById(
        "modalHorario"
    ).style.display =
    "none";
}


// 🧹 LIMPIAR
function limpiar() {

    document.getElementById(
        "trabajador"
    ).value = "";

    document.getElementById(
        "sucursal"
    ).value = "";

    document.getElementById(
        "fecha"
    ).value = "";

    document.getElementById(
        "entrada"
    ).value = "";

    document.getElementById(
        "salida"
    ).value = "";
}


// 👷 CARGAR TRABAJADORES
async function cargarTrabajadores() {

    try {

        const res =
        await fetch(
            `${API}/trabajadores`
        );

        const data =
        await res.json();


        const select =
        document.getElementById(
            "trabajador"
        );


        select.innerHTML = `

            <option value="">

                Seleccionar trabajador

            </option>
        `;


        data.forEach(t => {

            select.innerHTML += `

                <option
                    value="${t.id_trabajador}"
                    data-area="${t.area || ''}"
                >

                    ${t.nombre}

                </option>
            `;
        });
    }

    catch (error) {

        console.error(error);

        alert(
            "Error al cargar trabajadores"
        );
    }
}


// 🏢 LLENAR ÁREA
function llenarArea() {

    const select =
    document.getElementById(
        "trabajador"
    );

    const campoArea =
    document.getElementById(
        "sucursal"
    );


    const opcion =
    select.options[
        select.selectedIndex
    ];


    campoArea.value =

        opcion.getAttribute(
            "data-area"
        )

        ||

        "";
}


// 💾 GUARDAR
async function guardarAsistencia() {

    const data = {

        id_trabajador:
        parseInt(
            document.getElementById(
                "trabajador"
            ).value
        ),

        fecha:
        document.getElementById(
            "fecha"
        ).value,

        hora_entrada:
        document.getElementById(
            "entrada"
        ).value || null,

        hora_salida:
        document.getElementById(
            "salida"
        ).value || null
    };


    // 🔥 VALIDACIÓN
    if (
        !data.id_trabajador
        ||
        !data.fecha
    ) {

        alert(
            "Selecciona trabajador y fecha"
        );

        return;
    }


    try {

        // ✏️ EDITAR
        if (idEditar) {

            await fetch(

                `${API}/asistencia/${idEditar}`,

                {

                    method: "PUT",

                    headers: {
                        "Content-Type":
                        "application/json"
                    },

                    body: JSON.stringify(data)
                }
            );
        }


        // ➕ CREAR
        else {

            await fetch(

                `${API}/asistencia`,

                {

                    method: "POST",

                    headers: {
                        "Content-Type":
                        "application/json"
                    },

                    body: JSON.stringify(data)
                }
            );
        }


        alert(
            "Guardado correctamente"
        );

        cerrarModal();

        cargarAsistencia();

    }

    catch (error) {

        console.error(error);

        alert(
            "Error al guardar asistencia"
        );
    }
}


// 🚀 CARGAR TABLA
async function cargarAsistencia() {

    try {

        const [
            resAsistencia,
            resTrabajadores
        ] = await Promise.all([

            fetch(
                `${API}/asistencia`
            ),

            fetch(
                `${API}/trabajadores`
            )
        ]);


        const asistencia =
        await resAsistencia.json();

        const trabajadores =
        await resTrabajadores.json();


        const tabla =
        document.getElementById(
            "tablaAsistencia"
        );


        tabla.innerHTML = "";


        // ❌ SIN DATOS
        if (!asistencia.length) {

            tabla.innerHTML = `

                <tr>

                    <td colspan="6">

                        Sin asistencia

                    </td>

                </tr>
            `;

            return;
        }


        // ✅ CON DATOS
        asistencia.forEach(a => {

            const trabajador =
            trabajadores.find(t =>
                t.id_trabajador ===
                a.id_trabajador
            );


            tabla.innerHTML += `

                <tr>

                    <td>
                        ${
                            trabajador
                            ?
                            trabajador.nombre
                            :
                            "Trabajador"
                        }
                    </td>

                    <td>
                        ${
                            trabajador?.area
                            ||
                            ""
                        }
                    </td>

                    <td>
                        ${a.fecha || ""}
                    </td>

                    <td>
                        ${a.hora_entrada || ""}
                    </td>

                    <td>
                        ${a.hora_salida || ""}
                    </td>

                    <td>

                        <button
                            onclick="editar(${a.id_asistencia})"
                        >
                            ✏️
                        </button>

                        <button
                            onclick="eliminar(${a.id_asistencia})"
                        >
                            ❌
                        </button>

                    </td>

                </tr>
            `;
        });
    }

    catch (error) {

        console.error(error);

        alert(
            "Error al cargar asistencia"
        );
    }
}


// 🗑 ELIMINAR
async function eliminar(id) {

    if (
        !confirm(
            "¿Eliminar asistencia?"
        )
    ) {
        return;
    }


    try {

        await fetch(

            `${API}/asistencia/${id}`,

            {
                method: "DELETE"
            }
        );


        alert(
            "Eliminado"
        );

        cargarAsistencia();

    }

    catch (error) {

        console.error(error);

        alert(
            "Error al eliminar asistencia"
        );
    }
}


// ✏️ EDITAR
async function editar(id) {

    try {

        idEditar = id;

        abrirModal();


        const res =
        await fetch(

            `${API}/asistencia/${id}`
        );

        const a =
        await res.json();


        document.getElementById(
            "trabajador"
        ).value =
        a.id_trabajador;

        document.getElementById(
            "fecha"
        ).value =
        a.fecha || "";

        document.getElementById(
            "entrada"
        ).value =
        a.hora_entrada || "";

        document.getElementById(
            "salida"
        ).value =
        a.hora_salida || "";


        llenarArea();

    }

    catch (error) {

        console.error(error);

        alert(
            "Error al obtener asistencia"
        );
    }
}


// 🚀 INIT
window.onload =
cargarAsistencia;