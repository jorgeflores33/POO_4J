// 🔥 API
const API =
"http://127.0.0.1:8000/proveedores";


// ✏️ EDITAR
let idEditar = null;


// 🔐 VALIDAR LOGIN
const rol =
localStorage.getItem("rol");

if (!rol) {

    window.location.href =
    "../html/index.html";
}


// 🔓 LOGOUT
function logout() {

    localStorage.removeItem("rol");

    window.location.href =
    "../html/index.html";
}


// 📦 LISTA GLOBAL
let listaProveedores = [];


// 🚀 INIT
document.addEventListener(
    "DOMContentLoaded",
    () => {

        cargarProveedores();


        document.getElementById(
            "buscadorProveedor"
        )?.addEventListener(
            "input",
            (e) => {

                filtrar(
                    e.target.value
                );
            }
        );
    }
);


// 🚀 CARGAR
async function cargarProveedores() {

    try {

        const res =
        await fetch(API);

        const data =
        await res.json();


        listaProveedores =
        data;


        renderTabla(data);

    }

    catch (error) {

        console.error(error);

        alert(
            "Error al cargar proveedores"
        );
    }
}


// 🧠 RENDER
function renderTabla(data) {

    let html = "";


    // ❌ SIN DATOS
    if (!data.length) {

        html = `

            <tr>

                <td colspan="7">

                    Sin proveedores

                </td>

            </tr>
        `;
    }


    // ✅ CON DATOS
    else {

        data.forEach(p => {

            html += `

                <tr>

                    <td>
                        ${p.id_proveedor}
                    </td>

                    <td>
                        ${p.nombre || ""}
                    </td>

                    <td>
                        ${p.telefono || ""}
                    </td>

                    <td>
                        ${p.correo || ""}
                    </td>

                    <td>
                        ${p.direccion || ""}
                    </td>

                    <td>
                        ${p.folio || ""}
                    </td>

                    <td>

                        <button
                            onclick="editar(${p.id_proveedor})"
                        >
                            ✏️
                        </button>

                        <button
                            onclick="eliminar(${p.id_proveedor})"
                        >
                            🗑
                        </button>

                    </td>

                </tr>
            `;
        });
    }


    document.getElementById(
        "tablaProveedores"
    ).innerHTML = html;
}


// 🔍 FILTRO
function filtrar(texto) {

    texto =
    texto.toLowerCase();


    const filtrados =
    listaProveedores.filter(p =>

        (p.nombre || "")
        .toLowerCase()
        .includes(texto)

        ||

        (p.correo || "")
        .toLowerCase()
        .includes(texto)

        ||

        (p.telefono || "")
        .includes(texto)

        ||

        (p.folio || "")
        .toLowerCase()
        .includes(texto)
    );


    renderTabla(
        filtrados
    );
}


// 🔥 MODAL
function abrirModal() {

    idEditar = null;

    limpiar();


    document.getElementById(
        "tituloModal"
    ).innerText =
    "Nuevo Proveedor";


    document.getElementById(
        "modalProveedor"
    ).style.display =
    "flex";
}


// ❌ CERRAR
function cerrarModal() {

    document.getElementById(
        "modalProveedor"
    ).style.display =
    "none";
}


// 🧹 LIMPIAR
function limpiar() {

    document.getElementById(
        "id"
    ).value = "";

    document.getElementById(
        "nombre"
    ).value = "";

    document.getElementById(
        "telefono"
    ).value = "";

    document.getElementById(
        "correo"
    ).value = "";

    document.getElementById(
        "direccion"
    ).value = "";

    document.getElementById(
        "folio"
    ).value = "";
}


// 💾 GUARDAR
async function guardarProveedor() {

    const id =
    document.getElementById(
        "id"
    ).value;


    const data = {

        nombre:
        document.getElementById(
            "nombre"
        ).value,

        telefono:
        document.getElementById(
            "telefono"
        ).value,

        correo:
        document.getElementById(
            "correo"
        ).value,

        direccion:
        document.getElementById(
            "direccion"
        ).value,

        folio:
        document.getElementById(
            "folio"
        ).value
    };


    // 🔥 VALIDACIÓN
    if (!data.nombre) {

        alert(
            "El nombre es obligatorio"
        );

        return;
    }


    const url =

        id

        ?

        `${API}/${id}`

        :

        API;


    const method =

        id

        ?

        "PUT"

        :

        "POST";


    try {

        await fetch(url, {

            method: method,

            headers: {
                "Content-Type":
                "application/json"
            },

            body: JSON.stringify(data)
        });


        cerrarModal();

        cargarProveedores();

    }

    catch (error) {

        console.error(error);

        alert(
            "Error al guardar proveedor"
        );
    }
}


// ✏️ EDITAR
async function editar(id) {

    try {

        idEditar = id;


        const res =
        await fetch(
            `${API}/${id}`
        );

        const p =
        await res.json();


        document.getElementById(
            "id"
        ).value =
        p.id_proveedor;

        document.getElementById(
            "nombre"
        ).value =
        p.nombre || "";

        document.getElementById(
            "telefono"
        ).value =
        p.telefono || "";

        document.getElementById(
            "correo"
        ).value =
        p.correo || "";

        document.getElementById(
            "direccion"
        ).value =
        p.direccion || "";

        document.getElementById(
            "folio"
        ).value =
        p.folio || "";


        document.getElementById(
            "tituloModal"
        ).innerText =
        "Editar Proveedor";


        document.getElementById(
            "modalProveedor"
        ).style.display =
        "flex";
    }

    catch (error) {

        console.error(error);

        alert(
            "Error al obtener proveedor"
        );
    }
}


// 🗑 ELIMINAR
async function eliminar(id) {

    if (
        !confirm(
            "¿Eliminar proveedor?"
        )
    ) {
        return;
    }


    try {

        await fetch(

            `${API}/${id}`,

            {
                method: "DELETE"
            }
        );

        cargarProveedores();

    }

    catch (error) {

        console.error(error);

        alert(
            "Error al eliminar proveedor"
        );
    }
}