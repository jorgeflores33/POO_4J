// 🔐 VALIDAR SESIÓN
const rol = localStorage.getItem("rol");

if (!rol) {
    window.location.href = "../html/index.html";
}

// 🔓 LOGOUT
function logout() {
    localStorage.removeItem("rol");
    window.location.href = "../html/index.html";
}

// 🚀 NAVEGAR ENTRE MÓDULOS
function ir(pagina) {
    window.location.href = pagina;
}