// 🔥 API
const API =
"http://127.0.0.1:8000";


// 🔒 LOGIN
const rol =
localStorage.getItem("rol");

if (!rol) {

    window.location.href =
    "../../index.html";
}


// 🔓 LOGOUT
function logout() {

    localStorage.removeItem("rol");

    window.location.href =
    "../../index.html";
}


// 🚀 CARGAR NÓMINA
async function cargarNomina() {

    const contenedor =
    document.getElementById(
        "contenido-dinamico"
    );


    // 🔥 TABLA BASE
    contenedor.innerHTML = `

        <table>

            <thead>

                <tr>

                    <th>ID</th>

                    <th>Trabajador</th>

                    <th>Sueldo Base</th>

                    <th>Días</th>

                    <th>Total</th>

                    <th>Exportar</th>

                </tr>

            </thead>

            <tbody id="tablaNomina">

                <tr>

                    <td colspan="6"
                        style="text-align:center;"
                    >

                        Cargando...

                    </td>

                </tr>

            </tbody>

        </table>
    `;


    try {

        const [
            resNomina,
            resTrabajadores
        ] = await Promise.all([

            fetch(
                `${API}/nomina`
            ),

            fetch(
                `${API}/trabajadores`
            )
        ]);


        const nomina =
        await resNomina.json();

        const trabajadores =
        await resTrabajadores.json();


        const tabla =
        document.getElementById(
            "tablaNomina"
        );


        // ❌ SIN DATOS
        if (
            !nomina
            ||
            nomina.length === 0
        ) {

            tabla.innerHTML = `

                <tr>

                    <td colspan="6"
                        style="text-align:center;"
                    >

                        No hay nómina registrada

                    </td>

                </tr>
            `;

            return;
        }


        // ✅ FILAS
        let filas = "";


        nomina.forEach(n => {

            // 🔥 TRABAJADOR
            const trabajador =
            trabajadores.find(t =>
                t.id_trabajador ===
                n.id_trabajador
            );


            filas += `

                <tr>

                    <td>
                        ${n.id_nomina}
                    </td>

                    <td>
                        ${
                            trabajador
                            ?
                            trabajador.nombre
                            :
                            "Trabajador"
                        }
                    </td>

                    <td>
                        $${n.sueldo_base || 0}
                    </td>

                    <td>
                        ${n.dias_trabajados || 0}
                    </td>

                    <td>
                        $${n.total_pago || 0}
                    </td>

                    <td>

                        <button
                            class="btn-print"

                            onclick="
                                abrirModal(
                                    '${
                                        trabajador
                                        ?
                                        trabajador.nombre
                                        :
                                        'Trabajador'
                                    }',

                                    '${n.sueldo_base}',

                                    '${n.total_pago}',

                                    '${n.dias_trabajados}'
                                )
                            "
                        >
                            🖨
                        </button>

                    </td>

                </tr>
            `;
        });


        tabla.innerHTML = filas;

    }

    catch (error) {

        console.error(error);

        alert(
            "Error al cargar nómina"
        );
    }
}


// 🔥 ABRIR MODAL
function abrirModal(
    nombre,
    sueldo,
    total,
    dias
) {

    document.getElementById(
        "pdfNombre"
    ).innerText =
    nombre;


    document.getElementById(
        "pdfSueldo"
    ).innerText =
    `$${sueldo}`;


    document.getElementById(
        "pdfDias"
    ).innerText =
    dias;


    document.getElementById(
        "pdfTotal"
    ).innerText =
    `$${total}`;


    document.getElementById(
        "pdfFecha"
    ).innerText =

    new Date()
    .toLocaleDateString();


    document.getElementById(
        "modalNomina"
    ).style.display =
    "flex";
}


// ❌ CERRAR
function cerrarModal() {

    document.getElementById(
        "modalNomina"
    ).style.display =
    "none";
}


// 🖨 IMPRIMIR
function imprimir() {

    const contenido =

        document.getElementById(
            "contenidoPDF"
        ).outerHTML;


    const ventana =

        window.open(
            "",
            "",
            "width=900,height=700"
        );


    ventana.document.write(`

        <html>

        <head>

            <title>

                Recibo de Nómina

            </title>

            <style>

                body {

                    font-family: Arial;
                    padding: 20px;
                }

                table {

                    width: 100%;
                    border-collapse: collapse;
                }

                th, td {

                    border: 1px solid #000;
                    padding: 8px;
                    text-align: center;
                }

                h1, h2 {

                    text-align: center;
                }

                .firma {

                    margin-top: 60px;
                    text-align: center;
                }

            </style>

        </head>

        <body>

            ${contenido}

        </body>

        </html>
    `);


    ventana.document.close();

    ventana.print();
}


// 🚀 INIT
window.onload =
cargarNomina;