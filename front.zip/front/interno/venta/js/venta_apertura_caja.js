// APIs
const API_TRABAJADORES =
"http://127.0.0.1:8000/trabajadores/";

const API_USUARIOS =
"http://127.0.0.1:8000/usuarios/";

const API_SUCURSALES =
"http://127.0.0.1:8000/sucursales/";

const API_APERTURA_CAJA =
"http://127.0.0.1:8000/apertura-caja/";


// LISTAS
let listaTrabajadores = [];
let listaUsuarios = [];
let listaSucursales = [];


// LOGIN
const rol = localStorage.getItem("rol");

if (!rol) {

    window.location.href =
    "../../index.html";
}


// LOGOUT
function logout() {

    localStorage.clear();

    window.location.href =
    "../../index.html";
}


// NAVEGAR
function ir(pagina) {

    window.location.href = pagina;
}


// CARGAR DATOS
async function cargarDatos() {

    try {

        // FETCH
        const resTrabajadores =
        await fetch(API_TRABAJADORES);

        const resUsuarios =
        await fetch(API_USUARIOS);

        const resSucursales =
        await fetch(API_SUCURSALES);


        // JSON
        listaTrabajadores =
        await resTrabajadores.json();

        listaUsuarios =
        await resUsuarios.json();

        listaSucursales =
        await resSucursales.json();


        // CARGAR
        cargarTrabajadores();

        cargarUsuarios();

        cargarSucursales();

    }

    catch (error) {

        console.error(error);

        alert(
            "Error cargando datos"
        );
    }
}


// TRABAJADORES
function cargarTrabajadores() {

    let html = `

        <option value="">
            Seleccionar trabajador
        </option>
    `;


    listaTrabajadores.forEach(t => {

        html += `

            <option value="${t.id_trabajador}">
                ${t.nombre}
            </option>
        `;
    });


    document.getElementById(
        "trabajador"
    ).innerHTML = html;
}


// USUARIOS
function cargarUsuarios() {

    let html = `

        <option value="">
            Seleccionar usuario
        </option>
    `;


    listaUsuarios.forEach(u => {

        html += `

            <option value="${u.id_usuario}">
                ${u.usuario}
            </option>
        `;
    });


    document.getElementById(
        "usuario"
    ).innerHTML = html;
}


// SUCURSALES
function cargarSucursales() {

    let html = `

        <option value="">
            Seleccionar sucursal
        </option>
    `;


    listaSucursales.forEach(s => {

        html += `

            <option value="${s.id_sucursal}">
                ${s.nombre}
            </option>
        `;
    });


    document.getElementById(
        "sucursal"
    ).innerHTML = html;
}


// ABRIR MODAL
function abrirModal() {

    limpiar();

    document.getElementById(
        "modalCaja"
    ).style.display = "flex";
}


// CERRAR MODAL
function cerrarModal() {

    document.getElementById(
        "modalCaja"
    ).style.display = "none";
}


// LIMPIAR
function limpiar() {

    document.getElementById(
        "trabajador"
    ).value = "";

    document.getElementById(
        "usuario"
    ).value = "";

    document.getElementById(
        "sucursal"
    ).value = "";

    document.getElementById(
        "monto"
    ).value = "";
}


// GUARDAR
async function guardar() {

    try {

        const id_trabajador =
        parseInt(
            document.getElementById(
                "trabajador"
            ).value
        );


        const id_usuario =
        parseInt(
            document.getElementById(
                "usuario"
            ).value
        );


        const id_sucursal =
        parseInt(
            document.getElementById(
                "sucursal"
            ).value
        );


        const monto_inicial =
        Number(
            document.getElementById(
                "monto"
            ).value
        );


        // VALIDAR
        if (

            !id_trabajador
            ||
            !id_usuario
            ||
            !id_sucursal
            ||
            monto_inicial < 0
        ) {

            alert(
                "Completa los datos"
            );

            return;
        }


        // DATA
        const data = {

            id_trabajador:
            id_trabajador,

            id_usuario:
            id_usuario,

            id_sucursal:
            id_sucursal,

            monto_inicial:
            monto_inicial
        };


        // POST
        const res =
        await fetch(
            API_APERTURA_CAJA,
            {

                method: "POST",

                headers: {
                    "Content-Type":
                    "application/json"
                },

                body:
                JSON.stringify(data)
            }
        );


        // ERROR
        if (!res.ok) {

            const error =
            await res.text();

            console.error(error);

            alert(error);

            return;
        }


        alert(
            "Caja abierta correctamente"
        );


        cerrarModal();

    }

    catch (error) {

        console.error(error);

        alert(
            "Error al guardar"
        );
    }
}


// INICIO
window.onload =
cargarDatos;