// 🔥 APIs
const API_COTIZACIONES =
"http://127.0.0.1:8000/cotizaciones";

const API_DETALLE =
"http://127.0.0.1:8000/detalle_cotizaciones";

const API_CLIENTES =
"http://127.0.0.1:8000/clientes";

const API_PRODUCTOS =
"http://127.0.0.1:8000/productos";

const API_VENTAS =
"http://127.0.0.1:8000/ventas";


// 📦 LISTAS
let clientes = [];

let productos = [];


// 🔐 LOGIN
if (!localStorage.getItem("rol")) {

    window.location.href =
    "../html/index.html";
}


// 🔓 LOGOUT
function logout() {

    localStorage.clear();

    window.location.href =
    "../html/index.html";
}


// 🚀 CARGAR COTIZACIONES
async function cargarCotizaciones() {

    try {

        const [
            resCotizaciones,
            resClientes,
            resProductos
        ] = await Promise.all([

            fetch(API_COTIZACIONES),
            fetch(API_CLIENTES),
            fetch(API_PRODUCTOS)
        ]);


        const cotizaciones =
        await resCotizaciones.json();

        clientes =
        await resClientes.json();

        productos =
        await resProductos.json();


        let html = "";


        // ❌ SIN DATOS
        if (!cotizaciones.length) {

            html = `

                <tr>

                    <td colspan="5">

                        Sin cotizaciones

                    </td>

                </tr>
            `;
        }


        // ✅ CON DATOS
        else {

            cotizaciones.forEach(c => {

                const cliente =
                clientes.find(cli =>
                    cli.id_cliente === c.id_cliente
                );


                html += `

                    <tr>

                        <td>
                            ${c.folio || ""}
                        </td>

                        <td>
                            ${
                                c.fecha
                                ?
                                new Date(c.fecha)
                                .toLocaleString()
                                :
                                ""
                            }
                        </td>

                        <td>
                            ${
                                cliente
                                ?
                                cliente.nombre
                                :
                                "Cliente"
                            }
                        </td>

                        <td>

                            <button
                                onclick="pasarVenta(${c.id_cotizacion})"
                            >
                                ➡️
                            </button>

                        </td>

                        <td>

                            <button
                                onclick="editar(${c.id_cotizacion})"
                            >
                                ✏️
                            </button>

                            <button
                                onclick="eliminar(${c.id_cotizacion})"
                            >
                                🗑
                            </button>

                            <button
                                onclick="imprimir(${c.id_cotizacion})"
                            >
                                🖨
                            </button>

                        </td>

                    </tr>
                `;
            });
        }


        document.getElementById(
            "tablaCotizaciones"
        ).innerHTML = html;


        cargarClientes();

    }

    catch (error) {

        console.error(error);

        alert(
            "Error al cargar cotizaciones"
        );
    }
}


// 👥 CLIENTES
function cargarClientes() {

    let opciones = `
        <option value="">
            Seleccionar cliente
        </option>
    `;


    clientes.forEach(c => {

        opciones += `

            <option value="${c.id_cliente}">

                ${c.nombre}

            </option>
        `;
    });


    document.getElementById(
        "cliente"
    ).innerHTML = opciones;
}


// 🔥 MODAL
function abrirModal() {

    document.getElementById(
        "modal"
    ).style.display =
    "flex";


    document.getElementById(
        "detalle"
    ).innerHTML = "";


    recalcular();
}


// ❌ CERRAR
function cerrarModal() {

    document.getElementById(
        "modal"
    ).style.display =
    "none";
}


// ➕ PRODUCTO
function agregarProducto() {

    let opciones = `
        <option value="">
            Producto
        </option>
    `;


    productos.forEach(p => {

        opciones += `

            <option value="${p.id_producto}">

                ${p.codigo} - ${p.nombre}

            </option>
        `;
    });


    const fila =
    document.createElement("tr");


    fila.innerHTML = `

        <td>

            <select onchange="calcular(this)">

                ${opciones}

            </select>

        </td>

        <td>

            <input
                type="number"
                value="1"
                min="1"
                onchange="calcular(this)"
            >

        </td>

        <td>

            <input
                type="number"
                value="0"
                min="0"
                onchange="calcular(this)"
            >

        </td>

        <td class="subtotal">

            0

        </td>
    `;


    document.getElementById(
        "detalle"
    ).appendChild(fila);
}


// 🧮 CALCULAR
function calcular(input) {

    const fila =
    input.parentElement
    .parentElement;


    const cantidad =

        parseFloat(
            fila.children[1]
            .children[0]
            .value
        )

        ||

        0;


    const precio =

        parseFloat(
            fila.children[2]
            .children[0]
            .value
        )

        ||

        0;


    const subtotal =
    cantidad * precio;


    fila.children[3]
    .innerText =
    subtotal.toFixed(2);


    recalcular();
}


// 🧮 RECALCULAR
function recalcular() {

    let total = 0;


    document.querySelectorAll(
        ".subtotal"
    ).forEach(td => {

        total +=

            parseFloat(
                td.innerText
            )

            ||

            0;
    });


    document.getElementById(
        "total"
    ).innerText =
    total.toFixed(2);
}


// 💾 GUARDAR
async function guardar() {

    try {

        const data = {

            folio:
            document.getElementById(
                "folio"
            ).value,

            id_cliente:
            parseInt(
                document.getElementById(
                    "cliente"
                ).value
            ),

            total:
            parseFloat(
                document.getElementById(
                    "total"
                ).innerText
            )
        };


        // 🔥 VALIDAR
        if (
            !data.folio
            ||
            !data.id_cliente
        ) {

            alert(
                "Completa los campos"
            );

            return;
        }


        // 🔥 COTIZACIÓN
        const res =
        await fetch(
            API_COTIZACIONES,
            {

                method: "POST",

                headers: {
                    "Content-Type":
                    "application/json"
                },

                body: JSON.stringify(data)
            }
        );


        const cotizacion =
        await res.json();


        // 🔥 DETALLE
        const filas =
        document.querySelectorAll(
            "#detalle tr"
        );


        for (const fila of filas) {

            const id_producto =

                parseInt(
                    fila.children[0]
                    .children[0]
                    .value
                );


            const cantidad =

                parseFloat(
                    fila.children[1]
                    .children[0]
                    .value
                );


            const precio =

                parseFloat(
                    fila.children[2]
                    .children[0]
                    .value
                );


            const subtotal =
            cantidad * precio;


            await fetch(API_DETALLE, {

                method: "POST",

                headers: {
                    "Content-Type":
                    "application/json"
                },

                body: JSON.stringify({

                    id_cotizacion:
                    cotizacion.id_cotizacion,

                    id_producto,

                    cantidad,

                    precio_unitario:
                    precio,

                    subtotal
                })
            });
        }


        alert(
            "Cotización guardada"
        );


        cerrarModal();

        cargarCotizaciones();

    }

    catch (error) {

        console.error(error);

        alert(
            "Error al guardar cotización"
        );
    }
}


// 🖨 IMPRIMIR
async function imprimir(id) {

    try {

        const res =
        await fetch(

            `${API_COTIZACIONES}/${id}`
        );

        const c =
        await res.json();


        const win =
        window.open(
            "",
            "",
            "width=600,height=700"
        );


        win.document.write(`

            <h1>

                Cotización

            </h1>

            <p>

                Folio:
                ${c.folio}

            </p>

            <p>

                Cliente:
                ${c.nombre_cliente || ""}

            </p>

            <p>

                Total:
                $${c.total}

            </p>
        `);


        win.print();

    }

    catch (error) {

        console.error(error);
    }
}


// ➡️ PASAR A VENTA
async function pasarVenta(id) {

    try {

        const res =
        await fetch(

            `${API_COTIZACIONES}/${id}`
        );

        const c =
        await res.json();


        await fetch(API_VENTAS, {

            method: "POST",

            headers: {
                "Content-Type":
                "application/json"
            },

            body: JSON.stringify({

                id_cliente:
                c.id_cliente,

                total:
                c.total,

                tipo_venta:
                "cotizacion",

                forma_pago:
                "pendiente"
            })
        });


        alert(
            "Pasado a venta"
        );

    }

    catch (error) {

        console.error(error);

        alert(
            "Error al pasar a venta"
        );
    }
}


// ✏️ EDITAR
async function editar(id) {

    try {

        const res =
        await fetch(

            `${API_COTIZACIONES}/${id}`
        );

        const c =
        await res.json();


        abrirModal();


        document.getElementById(
            "folio"
        ).value =
        c.folio || "";


        document.getElementById(
            "cliente"
        ).value =
        c.id_cliente || "";


        document.getElementById(
            "total"
        ).innerText =
        c.total || "0";

    }

    catch (error) {

        console.error(error);
    }
}


// 🗑 ELIMINAR
async function eliminar(id) {

    if (
        !confirm(
            "¿Eliminar cotización?"
        )
    ) {
        return;
    }


    try {

        await fetch(

            `${API_COTIZACIONES}/${id}`,

            {
                method: "DELETE"
            }
        );


        cargarCotizaciones();

    }

    catch (error) {

        console.error(error);

        alert(
            "Error al eliminar cotización"
        );
    }
}


// 🚀 INIT
window.onload =
cargarCotizaciones;