// =========================================
// API
// =========================================

const API_COTIZACIONES =
"http://127.0.0.1:8000/cotizaciones/";

const API_DETALLE =
"http://127.0.0.1:8000/detalle-cotizaciones/";

const API_PRODUCTOS =
"http://127.0.0.1:8000/productos/";

const API_PEDIDOS =
"http://127.0.0.1:8000/pedidos/";

const API_DETALLE_PEDIDOS =
"http://127.0.0.1:8000/detalle-pedidos/";


// =========================================
// LOGIN
// =========================================

const rol =
localStorage.getItem("rol");

if (!rol) {

    window.location.href =
    "../index.html";
}


// =========================================
// LOGOUT
// =========================================

function logout() {

    localStorage.clear();

    window.location.href =
    "../index.html";
}


// =========================================
// VARIABLES
// =========================================

let cotizaciones = [];

let productos = [];

let detalleCotizacion = [];


// =========================================
// CARGAR PRODUCTOS
// =========================================

async function cargarProductos() {

    try {

        const response =
        await fetch(
            API_PRODUCTOS
        );

        productos =
        await response.json();

    }

    catch(error) {

        console.error(error);
    }
}


// =========================================
// CARGAR COTIZACIONES
// =========================================

async function cargarCotizaciones() {

    try {

        const response =
        await fetch(
            API_COTIZACIONES
        );

        cotizaciones =
        await response.json();

        renderTabla(
            cotizaciones
        );

    }

    catch(error) {

        console.error(error);

        alert(
            "Error cargando cotizaciones"
        );
    }
}


// =========================================
// RENDER TABLA
// =========================================

function renderTabla(data) {

    let html = "";


    if (!data.length) {

        html = `

            <tr>

                <td colspan="5">

                    Sin cotizaciones

                </td>

            </tr>
        `;
    }

    else {

        data.forEach(c => {

            html += `

                <tr>

                    <td>

                        ${c.folio || ""}

                    </td>

                    <td>

                        ${formatearFecha(c.fecha)}

                    </td>

                    <td>

                        ${
                            c.nombre_cliente
                            ||
                            "MOSTRADOR"
                        }

                    </td>

                    <td>

                        <button
                            onclick="pasarAPedido(${c.id_cotizacion})"
                        >

                            📦 PASAR A PEDIDO

                        </button>

                    </td>

                    <td>

                        <button
                            onclick="imprimirCotizacion(${c.id_cotizacion})"
                        >

                            🖨️ IMPRIMIR

                        </button>

                    </td>

                </tr>
            `;
        });
    }

    document.getElementById(
        "tablaCotizaciones"
    ).innerHTML = html;
}


// =========================================
// ABRIR MODAL
// =========================================

async function abrirModal() {

    detalleCotizacion = [];

    document.getElementById(
        "modal"
    ).style.display =
    "flex";


    document.getElementById(
        "folio"
    ).value =

        "COT-" + Date.now();


    document.getElementById(
        "fecha"
    ).value =

        new Date()
        .toISOString()
        .split("T")[0];


    document.getElementById(
        "cliente"
    ).value = "";


    renderDetalle();
}


// =========================================
// CERRAR MODAL
// =========================================

function cerrarModal() {

    document.getElementById(
        "modal"
    ).style.display =
    "none";
}


// =========================================
// AGREGAR PRODUCTO
// =========================================

function agregarProducto() {

    let options = "";

    productos.forEach(p => {

        options += `

            <option value="${p.id_producto}">

                ${p.codigo}
                -
                ${p.nombre}

            </option>
        `;
    });


    detalleCotizacion.push({

        id_producto: "",

        descripcion: "",

        cantidad: 1,

        precio: 0,

        subtotal: 0
    });


    renderDetalle();
}


// =========================================
// RENDER DETALLE
// =========================================

function renderDetalle() {

    let html = "";

    let total = 0;


    detalleCotizacion.forEach((d, index) => {

        total += Number(
            d.subtotal || 0
        );


        let options = "";

        productos.forEach(p => {

            options += `

                <option
                    value="${p.id_producto}"

                    ${
                        Number(p.id_producto)
                        ===
                        Number(d.id_producto)

                        ?

                        "selected"

                        :

                        ""
                    }
                >

                    ${p.codigo}
                    -
                    ${p.nombre}

                </option>
            `;
        });


        html += `

            <tr>

                <td>

                    <select
                        onchange="
                            seleccionarProducto(
                                ${index},
                                this.value
                            )
                        "
                    >

                        <option value="">

                            Seleccionar

                        </option>

                        ${options}

                    </select>

                </td>

                <td>

                    <input
                        type="number"
                        value="${d.cantidad}"
                        min="1"

                        onchange="
                            cambiarCantidad(
                                ${index},
                                this.value
                            )
                        "
                    >

                </td>

                <td>

                    <input
                        type="number"
                        value="${d.precio}"
                        step="0.01"

                        onchange="
                            cambiarPrecio(
                                ${index},
                                this.value
                            )
                        "
                    >

                </td>

                <td>

                    $${Number(
                        d.subtotal
                    ).toFixed(2)}

                </td>

            </tr>
        `;
    });


    document.getElementById(
        "detalle"
    ).innerHTML = html;


    document.getElementById(
        "total"
    ).innerText =
    total.toFixed(2);
}


// =========================================
// SELECCIONAR PRODUCTO
// =========================================

function seleccionarProducto(
    index,
    id_producto
) {

    const producto =
    productos.find(p =>

        Number(p.id_producto)
        ===
        Number(id_producto)
    );


    if (!producto) {

        return;
    }


    detalleCotizacion[index]
    .id_producto =

        producto.id_producto;


    detalleCotizacion[index]
    .descripcion =

        producto.nombre;


    detalleCotizacion[index]
    .precio =

        Number(
            producto.precio || 0
        );


    detalleCotizacion[index]
    .subtotal =

        Number(
            producto.precio || 0
        )
        *
        Number(
            detalleCotizacion[index]
            .cantidad
        );


    renderDetalle();
}


// =========================================
// CAMBIAR CANTIDAD
// =========================================

function cambiarCantidad(
    index,
    cantidad
) {

    detalleCotizacion[index]
    .cantidad =

        Number(cantidad);


    detalleCotizacion[index]
    .subtotal =

        Number(
            detalleCotizacion[index]
            .cantidad
        )
        *
        Number(
            detalleCotizacion[index]
            .precio
        );


    renderDetalle();
}


// =========================================
// CAMBIAR PRECIO
// =========================================

function cambiarPrecio(
    index,
    precio
) {

    detalleCotizacion[index]
    .precio =

        Number(precio);


    detalleCotizacion[index]
    .subtotal =

        Number(
            detalleCotizacion[index]
            .cantidad
        )
        *
        Number(precio);


    renderDetalle();
}


// =========================================
// GUARDAR
// =========================================

async function guardar() {

    try {

        const cotizacion = {

            folio:
            document.getElementById(
                "folio"
            ).value
        };


        // =====================================
        // CREAR COTIZACION
        // =====================================

        const response =
        await fetch(

            API_COTIZACIONES,

            {

                method: "POST",

                headers: {

                    "Content-Type":
                    "application/json"
                },

                body:
                JSON.stringify(
                    cotizacion
                )
            }
        );


        const result =
        await response.json();


        const id_cotizacion =

            result.id_cotizacion
            ||
            result.insertId
            ||
            result.id;


        // =====================================
        // INSERTAR DETALLE
        // =====================================

        for (const p of detalleCotizacion) {

            await fetch(

                API_DETALLE,

                {

                    method: "POST",

                    headers: {

                        "Content-Type":
                        "application/json"
                    },

                    body:
                    JSON.stringify({

                        id_cotizacion,

                        id_producto:
                        p.id_producto,

                        cantidad:
                        p.cantidad,

                        precio:
                        p.precio
                    })
                }
            );
        }


        alert(
            "Cotización creada"
        );

        cerrarModal();

        cargarCotizaciones();

    }

    catch(error) {

        console.error(error);

        alert(
            "Error creando cotización"
        );
    }
}


// =========================================
// PASAR A PEDIDO
// =========================================

async function pasarAPedido(
    id_cotizacion
) {

    try {

        // =====================================
        // OBTENER COTIZACION
        // =====================================

        const responseCot =
        await fetch(

            API_COTIZACIONES
            +
            id_cotizacion
        );

        const cotizacion =
        await responseCot.json();


        // =====================================
        // OBTENER DETALLE
        // =====================================

        const responseDetalle =
        await fetch(
            API_DETALLE
        );

        const detalles =
        await responseDetalle.json();


        const detalleFiltrado =
        detalles.filter(d =>

            Number(
                d.id_cotizacion
            )
            ===
            Number(id_cotizacion)
        );


        // =====================================
        // CREAR PEDIDO
        // =====================================

        const pedidoResponse =
        await fetch(

            API_PEDIDOS,

            {

                method: "POST",

                headers: {

                    "Content-Type":
                    "application/json"
                },

                body:
                JSON.stringify({

                    id_cliente:
                    cotizacion.id_cliente,

                    folio:
                    "PED-" + cotizacion.folio,

                    direccion:
                    "PENDIENTE",

                    telefono:
                    "PENDIENTE"
                })
            }
        );


        const pedido =
        await pedidoResponse.json();


        const id_pedido =

            pedido.id_pedido
            ||
            pedido.insertId
            ||
            pedido.id;


        // =====================================
        // INSERTAR DETALLE PEDIDO
        // =====================================

        for (const d of detalleFiltrado) {

            await fetch(

                API_DETALLE_PEDIDOS,

                {

                    method: "POST",

                    headers: {

                        "Content-Type":
                        "application/json"
                    },

                    body:
                    JSON.stringify({

                        id_pedido,

                        id_producto:
                        d.id_producto,

                        cantidad:
                        d.cantidad,

                        precio_unitario:
                        d.precio
                    })
                }
            );
        }


        alert(
            "Pedido generado correctamente"
        );

    }

    catch(error) {

        console.error(error);

        alert(
            "Error pasando a pedido"
        );
    }
}


// =========================================
// IMPRIMIR
// =========================================

function imprimirCotizacion(
    id_cotizacion
) {

    window.print();
}


// =========================================
// FORMATEAR FECHA
// =========================================

function formatearFecha(
    fecha
) {

    if (!fecha) {

        return "";
    }

    const f =
    new Date(fecha);

    return (

        f.toLocaleDateString()

        +

        " "

        +

        f.toLocaleTimeString()
    );
}


// =========================================
// BUSCADOR
// =========================================

document.getElementById(
    "buscador"
).addEventListener(
    "keyup",
    function() {

        const texto =
        this.value.toLowerCase();


        const filtrados =
        cotizaciones.filter(c =>

            (c.folio || "")
            .toLowerCase()
            .includes(texto)
        );


        renderTabla(
            filtrados
        );
    }
);


// =========================================
// FILTRO FECHA
// =========================================

document.getElementById(
    "filtroFecha"
).addEventListener(
    "change",
    function() {

        const fecha =
        this.value;


        if (!fecha) {

            renderTabla(
                cotizaciones
            );

            return;
        }


        const filtrados =
        cotizaciones.filter(c =>

            c.fecha
            &&
            c.fecha
            .split("T")[0]
            ===
            fecha
        );


        renderTabla(
            filtrados
        );
    }
);


// =========================================
// INIT
// =========================================

window.onload = async function () {

    await cargarProductos();

    cargarCotizaciones();
};