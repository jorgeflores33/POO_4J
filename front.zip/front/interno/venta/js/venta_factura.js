// 🔥 API
const API =
"http://127.0.0.1:8000/facturas_clientes";


// 🔐 VALIDAR LOGIN
const rol =
localStorage.getItem("rol");

if (!rol) {

    window.location.href =
    "../../index.html";
}


// 🔓 LOGOUT
function logout() {

    localStorage.removeItem("rol");

    window.location.href =
    "../../index.html";
}


// 📦 VARIABLES
let facturas = [];


// 🚀 CARGAR FACTURAS
async function cargarFacturas() {

    try {

        const res =
        await fetch(API);

        const data =
        await res.json();


        facturas = data;


        renderTabla(data);

    }

    catch (error) {

        console.error(error);

        alert(
            "Error al cargar facturas"
        );
    }
}


// 🎯 RENDER TABLA
function renderTabla(data) {

    let html = "";


    // ❌ SIN DATOS
    if (!data.length) {

        html = `

            <tr>

                <td colspan="5">

                    Sin facturas

                </td>

            </tr>
        `;
    }


    // ✅ CON DATOS
    else {

        data.forEach(f => {

            html += `

                <tr>

                    <td>
                        ${f.folio || ""}
                    </td>

                    <td>
                        ${formatearFecha(f.fecha)}
                    </td>

                    <td>
                        ${
                            f.nombre_cliente
                            ||
                            "Cliente"
                        }
                    </td>

                    <td>

                        <button
                            class="btn-delete"
                            onclick="eliminar(${f.id_factura})"
                        >
                            🗑
                        </button>

                    </td>

                    <td>

                        <button
                            class="btn-pdf"
                            onclick="imprimir(${f.id_factura})"
                        >
                            📄
                        </button>

                    </td>

                </tr>
            `;
        });
    }


    document.getElementById(
        "tablaFacturas"
    ).innerHTML = html;
}


// 🔍 BUSCADOR
document.getElementById(
    "buscador"
).addEventListener(
    "keyup",
    function () {

        const texto =
        this.value.toLowerCase();


        const filtrados =
        facturas.filter(f =>

            (f.folio || "")
            .toLowerCase()
            .includes(texto)

            ||

            (f.nombre_cliente || "")
            .toLowerCase()
            .includes(texto)
        );


        renderTabla(
            filtrados
        );
    }
);


// 📅 FILTRO FECHA
document.getElementById(
    "filtroFecha"
).addEventListener(
    "change",
    function () {

        const fecha =
        this.value;


        // 🔥 SIN FECHA
        if (!fecha) {

            renderTabla(
                facturas
            );

            return;
        }


        const filtrados =
        facturas.filter(f => {

            if (!f.fecha) {

                return false;
            }


            return (
                f.fecha
                .split("T")[0]
                ===
                fecha
            );
        });


        renderTabla(
            filtrados
        );
    }
);


// 🗑 ELIMINAR
async function eliminar(id) {

    if (
        !confirm(
            "¿Eliminar factura?"
        )
    ) {
        return;
    }


    try {

        await fetch(

            `${API}/${id}`,

            {
                method: "DELETE"
            }
        );


        alert(
            "Factura eliminada"
        );

        cargarFacturas();

    }

    catch (error) {

        console.error(error);

        alert(
            "Error al eliminar factura"
        );
    }
}


// 🖨 IMPRIMIR PDF
function imprimir(id) {

    window.open(

        `${API}/${id}/pdf`,

        "_blank"
    );
}


// 📅 FORMATEAR FECHA
function formatearFecha(fecha) {

    if (!fecha) {

        return "";
    }


    const f =
    new Date(fecha);


    return (

        f.toLocaleDateString()

        +

        " "

        +

        f.toLocaleTimeString()
    );
}


// 🚀 INIT
window.onload =
cargarFacturas;