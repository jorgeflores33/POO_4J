// 🔐 VALIDAR LOGIN
const rol = localStorage.getItem("rol");

if (!rol) {
    window.location.href = "C:/papeleria/papeleria/front/index.html";
}

// 🔓 LOGOUT
function logout() {
    localStorage.removeItem("rol");
    window.location.href = "C:/papeleria/papeleria/front/index.html";
}

// 🔁 NAVEGACIÓN
function ir(pagina) {
    window.location.href = pagina;
}