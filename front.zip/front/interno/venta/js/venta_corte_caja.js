const API = "http://localhost:3000";

// 🔐 VALIDAR LOGIN
if (!localStorage.getItem("rol")) {
    window.location.href = "../html/index.html";
}

// 🔓 LOGOUT
function logout() {
    localStorage.clear();
    window.location.href = "../html/index.html";
}

// 🔥 OBTENER APERTURA ACTIVA
async function obtenerApertura() {
    const res = await fetch(`${API}/apertura/activa`);
    return await res.json();
}

// 🚀 CARGAR CORTES
async function cargarCortes() {

    const res = await fetch(`${API}/cortes`);
    const data = await res.json();

    let html = "";

    data.forEach(c => {

        html += `
            <tr>
                <td>${c.usuario}</td>
                <td>${c.trabajador}</td>
                <td>${c.sucursal}</td>
                <td>${new Date(c.fecha).toLocaleString()}</td>

                <td>
                    💵 ${c.efectivo}<br>
                    💳 ${c.debito}<br>
                    🏦 ${c.credito}<br>
                    🔄 ${c.transferencia}
                </td>

                <td>
                    <button onclick="eliminar(${c.id_corte})">🗑</button>
                    <button onclick="pdfCorte(${c.id_corte})">🧾 PDF</button>
                </td>
            </tr>
        `;
    });

    document.getElementById("tablaCortes").innerHTML = html;
}

// 🔥 ABRIR MODAL
async function abrirModal() {

    const apertura = await obtenerApertura();

    if (!apertura) {
        alert("⚠️ No hay caja abierta");
        return;
    }

    document.getElementById("modalCorte").style.display = "flex";

    document.getElementById("usuario").value = apertura.usuario;
    document.getElementById("trabajador").value = apertura.trabajador;
    document.getElementById("sucursal").value = apertura.sucursal;
}

// ❌ CERRAR MODAL
function cerrarModal() {
    document.getElementById("modalCorte").style.display = "none";
}

// 💾 GUARDAR CORTE + GENERAR PDF
async function guardarCorte() {

    const apertura = await obtenerApertura();

    const data = {
        id_apertura: apertura.id_apertura,
        usuario: apertura.usuario,
        trabajador: apertura.trabajador,
        sucursal: apertura.sucursal,

        efectivo: document.getElementById("efectivo").value || 0,
        debito: document.getElementById("debito").value || 0,
        credito: document.getElementById("credito").value || 0,
        transferencia: document.getElementById("transferencia").value || 0
    };

    const res = await fetch(`${API}/cortes`, {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify(data)
    });

    const corte = await res.json();

    // 🔥 GENERAR PDF EN BACKEND
    await fetch(`${API}/cortes/${corte.id_corte}/pdf`, {
        method: "POST"
    });

    alert("Corte registrado y PDF generado");

    cerrarModal();
    cargarCortes();
}

// 🧾 PDF MANUAL (REVISAR / DESCARGAR)
function pdfCorte(id) {

    window.open(`${API}/cortes/${id}/pdf`, "_blank");
}

// 🗑 ELIMINAR
function eliminar(id) {

    if (!confirm("¿Eliminar corte?")) return;

    fetch(`${API}/cortes/${id}`, {
        method: "DELETE"
    }).then(() => cargarCortes());
}

// 🚀 INICIO
window.onload = cargarCortes;