// ==============================
// APIs
// ==============================

const API_PRODUCTOS =
"http://127.0.0.1:8000/productos/";

const API_PRODUCTOS_SUCURSAL =
"http://127.0.0.1:8000/productos-sucursal/";

const API_SUCURSALES =
"http://127.0.0.1:8000/sucursales/";

const API_VENTAS =
"http://127.0.0.1:8000/ventas/";


// ==============================
// LISTAS
// ==============================

let listaProductos = [];
let listaInventario = [];
let listaSucursales = [];
let listaVentas = [];


// ==============================
// CARRITO
// ==============================

let carrito = [];


// ==============================
// SUCURSAL ACTIVA
// ==============================

let idSucursalActiva = null;


// ==============================
// LOGIN
// ==============================

const rol = localStorage.getItem("rol");

if (!rol) {

    window.location.href =
    "C:/papeleria/papeleria/front/index.html";
}


// ==============================
// LOGOUT
// ==============================

function logout() {

    localStorage.clear();

    window.location.href =
    "C:/papeleria/papeleria/front/index.html";
}


// ==============================
// NAVEGAR
// ==============================

function ir(pagina) {

    window.location.href = pagina;
}


// ==============================
// CARGAR DATOS
// ==============================

async function cargarDatos() {

    try {

        // FETCH
        const resProductos =
        await fetch(API_PRODUCTOS);

        const resInventario =
        await fetch(API_PRODUCTOS_SUCURSAL);

        const resSucursales =
        await fetch(API_SUCURSALES);

        const resVentas =
        await fetch(API_VENTAS);


        // JSON
        listaProductos =
        await resProductos.json();

        listaInventario =
        await resInventario.json();

        listaSucursales =
        await resSucursales.json();

        listaVentas =
        await resVentas.json();


        // ==========================
        // SELECT SUCURSALES
        // ==========================

        let htmlSucursales = `

            <option value="">
                Seleccionar opción
            </option>
        `;


        listaSucursales.forEach(s => {

            htmlSucursales += `

                <option value="${s.id_sucursal}">
                    ${s.nombre}
                </option>
            `;
        });


        document.getElementById(
            "sucursalActivaSelect"
        ).innerHTML =
        htmlSucursales;


        // ==========================
        // SUCURSAL GUARDADA
        // ==========================

        const sucursalGuardada =
        localStorage.getItem(
            "id_sucursal"
        );


        if (sucursalGuardada) {

            idSucursalActiva =
            sucursalGuardada;


            document.getElementById(
                "sucursalActivaSelect"
            ).value =
            sucursalGuardada;
        }


        // ==========================
        // EVENTO CAMBIO SUCURSAL
        // ==========================

        document.getElementById(
            "sucursalActivaSelect"
        ).onchange = function () {

            idSucursalActiva =
            this.value;


            localStorage.setItem(

                "id_sucursal",

                this.value
            );
        };


        // HISTORIAL
        cargarHistorial();

    }

    catch (error) {

        console.error(error);

        alert(
            "Error cargando datos"
        );
    }
}


// ==============================
// ABRIR MODAL
// ==============================

function abrirModal() {

    // VALIDAR SUCURSAL
    if (!idSucursalActiva) {

        alert(
            "Selecciona una sucursal"
        );

        return;
    }


    carrito = [];

    renderCarrito();


    document.getElementById(
        "buscarProducto"
    ).value = "";


    document.getElementById(
        "resultados"
    ).innerHTML = "";


    // 🔥 MOSTRAR MODAL
    document.getElementById(
        "modalVenta"
    ).style.display = "flex";
}


// ==============================
// CERRAR MODAL
// ==============================

function cerrarModal() {

    document.getElementById(
        "modalVenta"
    ).style.display = "none";
}


// ==============================
// BUSCAR PRODUCTO
// ==============================

function buscarProducto() {

    const texto =
    document.getElementById(
        "buscarProducto"
    ).value.toLowerCase();


    let html = "";


    listaInventario.forEach(i => {

        // 🔥 SOLO SUCURSAL ACTIVA
        if (

            Number(i.id_sucursal)
            !==
            Number(idSucursalActiva)

        ) {

            return;
        }


        const producto =
        listaProductos.find(p =>

            Number(p.id_producto)
            ===
            Number(i.id_producto)
        );


        if (!producto) return;


        // 🔥 BUSCAR POR NOMBRE O CODIGO
        const coincide =

            (
                producto.nombre
                &&
                producto.nombre
                .toLowerCase()
                .includes(texto)
            )

            ||

            (

                producto.codigo
                &&

                producto.codigo
                .toLowerCase()
                .includes(texto)
            );


        if (coincide) {

            html += `

                <div
                    class="resultado"

                    onclick="agregarCarrito(

                        ${producto.id_producto},

                        '${producto.nombre}',

                        ${producto.precio},

                        ${i.existencia}

                    )"
                >

                    <strong>
                        ${producto.nombre}
                    </strong>

                    <br>

                    Código:
                    ${producto.codigo || "N/A"}

                    <br>

                    Existencia:
                    ${i.existencia}

                    |
                    Precio:
                    $${producto.precio}

                </div>
            `;
        }
    });


    document.getElementById(
        "resultados"
    ).innerHTML = html;
}


// ==============================
// AGREGAR CARRITO
// ==============================

function agregarCarrito(
    id_producto,
    nombre,
    precio,
    stock
) {

    const existe =
    carrito.find(c =>

        Number(c.id_producto)
        ===
        Number(id_producto)
    );


    // EXISTE
    if (existe) {

        // VALIDAR STOCK
        if (

            existe.cantidad + 1
            >
            stock

        ) {

            alert(
                "Stock insuficiente"
            );

            return;
        }


        existe.cantidad += 1;

        existe.total =
        existe.cantidad * existe.precio;
    }

    // NUEVO
    else {

        carrito.push({

            id_producto:
            id_producto,

            nombre:
            nombre,

            cantidad:
            1,

            precio:
            precio,

            total:
            precio,

            stock:
            stock
        });
    }


    renderCarrito();
}


// ==============================
// RENDER CARRITO
// ==============================

function renderCarrito() {

    let html = "";

    let total = 0;


    carrito.forEach(c => {

        total += c.total;


        html += `

            <tr>

                <td>
                    ${c.nombre}
                </td>

                <td>
                    ${c.cantidad}
                </td>

                <td>
                    $${c.precio}
                </td>

                <td>
                    $${c.total}
                </td>

            </tr>
        `;
    });


    document.getElementById(
        "tablaCarrito"
    ).innerHTML = html;


    document.getElementById(
        "totalVenta"
    ).innerText =
    total.toFixed(2);
}


// ==============================
// GUARDAR VENTA
// ==============================

async function guardarVenta() {

    try {

        // VALIDAR
        if (!carrito.length) {

            alert(
                "Agrega productos"
            );

            return;
        }


        // TOTAL
        let total = 0;


        carrito.forEach(c => {

            total += c.total;
        });


        // FOLIO
        const folio =

            "VTA-" +
            Date.now();


        // DATA
        const data = {

            folio:
            folio,

            total:
            total,

            id_sucursal:
            parseInt(
                idSucursalActiva
            )
        };


        // ==========================
        // POST VENTA
        // ==========================

        const resVenta =
        await fetch(
            API_VENTAS,
            {

                method: "POST",

                headers: {
                    "Content-Type":
                    "application/json"
                },

                body:
                JSON.stringify(data)
            }
        );


        // ERROR
        if (!resVenta.ok) {

            const error =
            await resVenta.text();

            console.error(error);

            alert(
                "Error registrando venta"
            );

            return;
        }


        // ==========================
        // ACTUALIZAR INVENTARIO
        // ==========================

        for (const c of carrito) {

            const inventario =
            listaInventario.find(i =>

                Number(i.id_producto)
                ===
                Number(c.id_producto)

                &&

                Number(i.id_sucursal)
                ===
                Number(idSucursalActiva)
            );


            if (!inventario) {

                continue;
            }


            const nuevaExistencia =

                Number(inventario.existencia)
                -
                Number(c.cantidad);


            // PUT
            await fetch(

                `${API_PRODUCTOS_SUCURSAL}${c.id_producto}/${idSucursalActiva}`,

                {

                    method: "PUT",

                    headers: {
                        "Content-Type":
                        "application/json"
                    },

                    body:
                    JSON.stringify({

                        existencia:
                        nuevaExistencia
                    })
                }
            );
        }


        alert(
            "Venta registrada correctamente"
        );


        // IMPRIMIR
        imprimirTicket();


        // LIMPIAR
        carrito = [];

        renderCarrito();

        cerrarModal();


        // RECARGAR
        cargarDatos();

    }

    catch (error) {

        console.error(error);

        alert(
            "Error al guardar venta"
        );
    }
}


// ==============================
// IMPRIMIR
// ==============================

function imprimirTicket() {

    window.print();
}


// ==============================
// HISTORIAL
// ==============================

function cargarHistorial() {

    let html = "";


    // FECHA HOY
    const hoy =
    new Date()
    .toISOString()
    .split("T")[0];


    listaVentas.forEach(v => {

        // VALIDAR FECHA
        if (

            v.fecha
            &&
            v.fecha.startsWith(hoy)

        ) {

            html += `

                <tr>

                    <td>
                        ${v.folio}
                    </td>

                    <td>
                        $${v.total}
                    </td>

                </tr>
            `;
        }
    });


    document.getElementById(
        "tablaVentas"
    ).innerHTML = html;
}


// ==============================
// INICIO
// ==============================

window.onload =
cargarDatos;