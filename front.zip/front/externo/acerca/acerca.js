function irInicio() {
    window.location.href = "../../index.html";
}