const API = "http://127.0.0.1:8000/api";

let productos = [];
let categoriaURL = null;

// 🔥 OBTENER CATEGORÍA URL
function obtenerCategoria() {
    const params = new URLSearchParams(window.location.search);
    categoriaURL = params.get("categoria");
}

// 🚀 CARGAR
function cargarProductos() {

    fetch(`${API}/productos`)
        .then(res => res.json())
        .then(data => {
            productos = data;
            aplicarFiltros();
        })
        .catch(() => {
            document.getElementById("gridProductos").innerHTML =
                "<p>Error al cargar productos</p>";
        });
}

// 🎨 RENDER
function renderProductos(lista) {

    let html = "";

    if (!lista.length) {
        html = `<p>No hay productos disponibles</p>`;
    } else {

        lista.forEach(p => {

            html += `
                <div class="card-producto">

                    <img src="${p.imagen_url || 'https://via.placeholder.com/150'}">

                    <h3>${p.nombre}</h3>

                    <p><b>Código:</b> ${p.codigo}</p>

                    <p><b>Precio:</b> $${p.precio}</p>

                    <p><b>Categoría:</b> ${p.categoria_nombre || "Sin categoría"}</p>

                    <button onclick="agregarCarrito(${p.id_producto})">
                        🛒 Agregar
                    </button>

                </div>
            `;
        });
    }

    document.getElementById("gridProductos").innerHTML = html;
}

// 🔍 FILTROS
function aplicarFiltros() {

    let lista = [...productos];

    const texto = document.getElementById("buscador")?.value.toLowerCase() || "";
    const categoriaSelect = document.getElementById("filtroCategoria")?.value;
    const precio = document.getElementById("filtroPrecio")?.value;

    // 🔥 FILTRO URL
    if (categoriaURL) {
        lista = lista.filter(p =>
            (p.categoria_nombre || "").toLowerCase() === categoriaURL.toLowerCase()
        );
    }

    // 🔥 FILTRO SELECT
    if (categoriaSelect) {
        lista = lista.filter(p =>
            (p.categoria_nombre || "").toLowerCase() === categoriaSelect.toLowerCase()
        );
    }

    // 🔍 BUSCADOR
    if (texto) {
        lista = lista.filter(p =>
            (p.nombre || "").toLowerCase().includes(texto) ||
            (p.codigo || "").toLowerCase().includes(texto)
        );
    }

    // 💰 PRECIO
    if (precio) {

        if (precio === "500+") {
            lista = lista.filter(p => p.precio > 500);
        } else {
            const [min, max] = precio.split("-").map(Number);
            lista = lista.filter(p => p.precio >= min && p.precio <= max);
        }
    }

    renderProductos(lista);
}

// 🛒 CARRITO (LOCAL STORAGE REAL)
function agregarCarrito(id_producto) {

    let carrito = JSON.parse(localStorage.getItem("carrito")) || [];

    const producto = productos.find(p => p.id_producto === id_producto);

    if (!producto) return;

    carrito.push(producto);

    localStorage.setItem("carrito", JSON.stringify(carrito));

    alert("Producto agregado al carrito");
}

// 🔗 EVENTOS
window.onload = function () {

    obtenerCategoria();
    cargarProductos();

    document.getElementById("buscador")?.addEventListener("input", aplicarFiltros);
    document.getElementById("filtroCategoria")?.addEventListener("change", aplicarFiltros);
    document.getElementById("filtroPrecio")?.addEventListener("change", aplicarFiltros);
};