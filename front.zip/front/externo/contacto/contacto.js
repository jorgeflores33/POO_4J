// Por ahora vacío, pero listo para futuro uso
console.log("Página de contacto cargada");
// 🔥 NAVEGACIÓN PRINCIPAL

document.getElementById("btnInicio").addEventListener("click", function () {
    window.location.href = "index.html";
});

document.getElementById("btnProductos").addEventListener("click", function () {
    window.location.href = "productos.html";
});

document.getElementById("btnAcerca").addEventListener("click", function () {
    window.location.href = "acerca.html";
});
document.getElementById("btnContacto")?.addEventListener("click", function () {
    window.location.href = "contacto.html";
});
function verDetalleSucursal() {
    window.location.href = "detalle_sucursal.html";
}